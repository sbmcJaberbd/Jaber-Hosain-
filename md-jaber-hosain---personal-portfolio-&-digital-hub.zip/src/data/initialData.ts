import {
  Project,
  SkillItem,
  RoadmapItem,
  ExperienceItem,
  EducationItem,
  ServiceItem,
  AchievementItem,
  NowPageData,
  GardenNote,
  BlogPost,
  TestimonialItem,
  GuestbookEntry,
  VisitorAdvice,
  PersonalDashboardState
} from '../types';

export const PROFILE_INFO = {
  name: 'MD JABER HOSAIN',
  nameBn: 'মোঃ জাবের হোসাইন',
  nickname: 'Jaber',
  title: 'Full-Stack Software Engineer & Creative UI/UX Architect',
  titleBn: 'ফুল-স্ট্যাক সফটওয়্যার ইঞ্জিনিয়ার ও ক্রিয়েটিভ ইউআই/ইউএক্স ডিজাইনার',
  tagline: 'Crafting resilient digital products, performant web platforms, and human-centric interfaces.',
  taglineBn: 'দক্ষ ডিজিটাল পণ্য, দ্রুতগতির ওয়েব প্ল্যাটফর্ম ও ব্যবহারকারীকেন্দ্রিক ইন্টারফেস নির্মাণে নিবেদিত।',
  email: 'sbmc.3925@gmail.com',
  secondaryEmail: 'mdjaberhosain.dev@gmail.com',
  phone: '+880 1888-000000',
  whatsapp: '+8801888000000',
  location: 'Dhaka & Barisal, Bangladesh',
  locationBn: 'ঢাকা ও বরিশাল, বাংলাদেশ',
  availability: 'Available for Selected Projects & Full-Time Roles',
  availabilityBn: 'নির্বাচিত প্রজেক্ট ও ফুল-টাইম কাজের জন্য উন্মুক্ত',
  yearsOfLearning: '4+',
  projectsCompleted: '25+',
  technologiesMastered: '18+',
  happyClients: '15+',
  avatar: '/src/assets/images/jaber_portrait_1787840072267.jpg',
  bio: `I am Md Jaber Hosain, a passionate Software Engineer and Web Developer with a strong foundation in modern frontend architectures, scalable backend systems, and thoughtful UI/UX design. I love bridging the gap between elegant visual design and rock-solid code engineering.`,
  bioBn: `আমি মোঃ জাবের হোসাইন, একজন নিবেদিতপ্রাণ সফটওয়্যার প্রকৌশলী ও ওয়েব ডেভেলপার। আধুনিক ফ্রন্টএন্ড আর্কিটেকচার, ব্যাকএন্ড সিস্টেম এবং নান্দনিক ইউআই/ইউএক্স ডিজাইনের সমন্বয়ে কাজ করতে আমি অত্যন্ত আগ্রহী।`,
  philosophy: `“I believe that exceptional digital craft happens at the intersection of unwavering discipline, genuine curiosity, aesthetic sensitivity, and ethical continuous learning.”`,
  philosophyBn: `“আমার বিশ্বাস, অসাধারণ ডিজিটাল সমাধান তৈরি হয় নিষ্ঠা, অদম্য কৌতূহল, নান্দনিকতা এবং নিরবচ্ছিন্ন শিক্ষার সমন্বয়ে।”`,
  mission: `To engineer accessible, lightning-fast, and beautiful software solutions that solve real-world problems for businesses, communities, and individuals globally.`,
  missionBn: `ব্যবহারকারী ও ব্যবসা প্রতিষ্ঠানের বাস্তব সমস্যা সমাধানের জন্য দ্রুতগতির, নিরাপদ ও সুন্দর সফটওয়্যার সমাধান তৈরি করা।`,
  vision: `To lead impactful engineering initiatives, mentor the next wave of creative developers, and build resilient open-source tools that empower digital freedom.`,
  visionBn: `প্রভাবশালী প্রযুক্তিগত উদ্যোগের নেতৃত্ব দেওয়া এবং উন্নতমানের ওপেন-সোর্স প্রযুক্তি নির্মাণ করা।`,
  socialLinks: {
    github: 'https://github.com',
    linkedin: 'https://linkedin.com',
    facebook: 'https://facebook.com',
    twitter: 'https://x.com',
    instagram: 'https://instagram.com',
    youtube: 'https://youtube.com',
    email: 'mailto:sbmc.3925@gmail.com'
  }
};

export const CORE_VALUES = [
  {
    title: 'Integrity',
    titleBn: 'সততা ও নৈতিকতা',
    desc: 'Uncompromising honesty in code quality, transparent communication, and respect for privacy and security.',
    icon: 'ShieldCheck'
  },
  {
    title: 'Creativity',
    titleBn: 'সৃজনশীলতা',
    desc: 'Approaching complex technical roadblocks with innovative problem-solving and clean visual design.',
    icon: 'Sparkles'
  },
  {
    title: 'Discipline',
    titleBn: 'শৃঙ্খলা ও একাগ্রতা',
    desc: 'Consistent daily practice, meticulous attention to detail, and a commitment to writing maintainable code.',
    icon: 'Compass'
  },
  {
    title: 'Continuous Learning',
    titleBn: 'নিরবচ্ছিন্ন শিক্ষা',
    desc: 'Staying ahead of evolving web standards, modern frameworks, and emerging engineering paradigms.',
    icon: 'BookOpen'
  },
  {
    title: 'Quality First',
    titleBn: 'মানসম্মত কাজ',
    desc: 'Designing accessible, high-performance, and scalable systems that delight users.',
    icon: 'CheckCircle2'
  },
  {
    title: 'Responsibility',
    titleBn: 'দায়িত্বশীলতা',
    desc: 'Owning project outcomes from initial wireframe to production deployment and long-term maintenance.',
    icon: 'HeartHandshake'
  }
];

export const INITIAL_PROJECTS: Project[] = [
  {
    id: 'nexus-cloud-hub',
    title: 'Nexus Intelligence Hub & Analytics',
    titleBn: 'নেক্সাস ইন্টেলিজেন্স হাব ও অ্যানালিটিক্স',
    category: 'Web Development',
    shortDesc: 'A high-performance modern analytics platform featuring real-time data streaming, modular widgets, and role-based workspace management.',
    shortDescBn: 'রিয়েল-টাইম ডেটা স্ট্রিমিং ও মডুলার উইজেট সমৃদ্ধ একটি আধুনিক হাই-পারফর্ম্যান্স অ্যানালিটিক্স প্ল্যাটফর্ম।',
    image: 'https://images.unsplash.com/photo-1551288049-bebda4e38f71?auto=format&fit=crop&w=1200&q=80',
    tags: ['React', 'TypeScript', 'Tailwind CSS', 'Node.js', 'PostgreSQL', 'Charts'],
    year: '2025',
    featured: true,
    liveUrl: 'https://example.com/demo/nexus',
    githubUrl: 'https://github.com/mdjaberhosain/nexus-cloud',
    caseStudy: {
      overview: 'Nexus Hub provides high-density analytics, customizable visual dashboards, and automated telemetry alerts for engineering teams.',
      overviewBn: 'নেক্সাস হাব প্রযুক্তি টিমের জন্য বিশদ অ্যানালিটিক্স, কাস্টমাইজযোগ্য ড্যাশবোর্ড এবং রিয়েল-টাইম অ্যালার্ট প্রদান করে।',
      problem: 'Existing client tools were sluggish, lacked unified data filters, and suffered from memory leaks during heavy data polling cycles.',
      problemBn: 'বিদ্যমান সিস্টেমগুলোতে ধীরগতি, অগোছালো ফিল্টারিং এবং অতিরিক্ত মেমরি ব্যবহারের সমস্যা ছিল।',
      solution: 'Architected a modular virtualized frontend with optimistic updates, aggressive indexing, and lightweight WebSocket event queues.',
      solutionBn: 'ভার্চুয়ালাইজড ফ্রন্টএন্ড এবং অপ্টিমাইজড ওয়েবসকেট ইভেন্ট কিউ দিয়ে দ্রুতগতির আর্কিটেকচার তৈরি করেছি।',
      myRole: 'Lead Full-Stack Developer & UI Architect (Architecture, Dashboard UX, API Integration)',
      technologies: ['React 18', 'TypeScript', 'Tailwind CSS', 'Node.js', 'Express', 'PostgreSQL', 'Recharts'],
      challenges: [
        'Handling 10,000+ data points per second with zero UI frame drops',
        'Designing a unified dark/light contrast matrix for dense charts',
        'Implementing strict RBAC security on multi-tenant databases'
      ],
      processSteps: [
        { title: '1. Discovery & Wireframing', desc: 'Analyzed user telemetry workflows and mapped high-priority dashboards in Figma.' },
        { title: '2. Backend API Architecture', desc: 'Built REST & streaming endpoints with rate limiting and Redis caching.' },
        { title: '3. Frontend Optimization', desc: 'Used Web Workers and React windowing to keep interactions buttery smooth.' },
        { title: '4. Testing & Hardening', desc: 'Conducted end-to-end load testing and accessibility WCAG AA compliance passes.' }
      ],
      finalResult: 'Reduced page load time by 64%, increased daily active user retention by 42%, and scaled smoothly to over 50,000 requests per minute.',
      gallery: [
        'https://images.unsplash.com/photo-1551288049-bebda4e38f71?auto=format&fit=crop&w=1200&q=80',
        'https://images.unsplash.com/photo-1460925895917-afdab827c52f?auto=format&fit=crop&w=1200&q=80',
        'https://images.unsplash.com/photo-1504868584819-f8e8b4b6d7e3?auto=format&fit=crop&w=1200&q=80'
      ]
    }
  },
  {
    id: 'aurora-design-system',
    title: 'Aurora Design System & Component Studio',
    titleBn: 'অরোরা ডিজাইন সিস্টেম ও কম্পোনেন্ট স্টুডিও',
    category: 'UI/UX Design',
    shortDesc: 'A comprehensive, accessible design system with 60+ modular tokens, fluid typography scaling, and dark-mode native components.',
    shortDescBn: '৬০+ মডুলার টোকেন, ফ্লুইড টাইপোগ্রাফি এবং অ্যাক্সেসিবল কম্পোনেন্ট সমৃদ্ধ ডিজাইন সিস্টেম।',
    image: 'https://images.unsplash.com/photo-1507238691740-187a5b1d37b8?auto=format&fit=crop&w=1200&q=80',
    tags: ['Figma', 'UI/UX', 'Design Tokens', 'Tailwind CSS', 'Accessibility (a11y)'],
    year: '2024',
    featured: true,
    liveUrl: 'https://example.com/demo/aurora',
    githubUrl: 'https://github.com/mdjaberhosain/aurora-ds',
    caseStudy: {
      overview: 'Aurora is a cohesive design language unifying brand identity, digital products, and design engineering workflows.',
      problem: 'Inconsistent spacing, mismatched brand colors across mobile and web platforms, and poor keyboard accessibility.',
      solution: 'Created an atomic design token system with automated Figma-to-Tailwind pipelines and strict WCAG contrast checks.',
      myRole: 'Principal UI/UX Designer & Frontend Token Specialist',
      technologies: ['Figma', 'Storybook', 'Tailwind CSS', 'TypeScript', 'Radix Primitives'],
      challenges: [
        'Designing a dual-mode token hierarchy with zero visual glare in dark mode',
        'Ensuring 100% keyboard navigability across custom dropdowns and dialogs'
      ],
      processSteps: [
        { title: '1. Token Foundation', desc: 'Defined semantic color palettes, type scales, and elevation layers.' },
        { title: '2. Component Prototyping', desc: 'Built 40+ responsive components in Figma with autolayout and variants.' },
        { title: '3. Code Implementation', desc: 'Exported tokens into Tailwind configs and verified contrast ratios.' }
      ],
      finalResult: 'Shipped to 4 client products, slashing UI development time by 50% while guaranteeing AA accessibility.',
      gallery: [
        'https://images.unsplash.com/photo-1507238691740-187a5b1d37b8?auto=format&fit=crop&w=1200&q=80',
        'https://images.unsplash.com/photo-1581291518857-4e27b48ff24e?auto=format&fit=crop&w=1200&q=80'
      ]
    }
  },
  {
    id: 'medisync-healthcare',
    title: 'MediSync Hospital Patient Portal',
    titleBn: 'মেডিসিংক হসপিটাল পেশেন্ট পোর্টাল',
    category: 'Client Projects',
    shortDesc: 'A secure, HIPAA-conscious medical appointment, lab records, and doctor tele-consultation platform built for a regional healthcare network.',
    shortDescBn: 'ডাক্তারের অ্যাপয়েন্টমেন্ট, ল্যাব রিপোর্ট এবং টেলি-কনসালটেশনের জন্য নিরাপদ স্বাস্থ্যসেবা পোর্টাল।',
    image: 'https://images.unsplash.com/photo-1576091160399-112ba8d25d1d?auto=format&fit=crop&w=1200&q=80',
    tags: ['React', 'Node.js', 'Express', 'MongoDB', 'WebRTC', 'Tailwind'],
    year: '2024',
    featured: true,
    liveUrl: 'https://example.com/demo/medisync',
    caseStudy: {
      overview: 'MediSync bridges doctors and patients through real-time booking, instant lab result viewing, and encrypted video visits.',
      problem: 'Patients faced long waiting queues, lost paper prescriptions, and had no unified platform to manage family health profiles.',
      solution: 'Delivered an intuitive bilingual web application with automated SMS reminders, digital prescription downloads, and instant queue tracking.',
      myRole: 'Full-Stack Developer (Backend APIs, Appointment Engine, Frontend Client)',
      technologies: ['React', 'Node.js', 'Express', 'MongoDB', 'Socket.io', 'Tailwind CSS'],
      challenges: [
        'Ensuring secure data encryption at rest and in transit for sensitive patient records',
        'Optimizing interface readability for elderly patients with large touch targets'
      ],
      processSteps: [
        { title: '1. Healthcare Workflow Research', desc: 'Interviewed clinic staff and doctors to understand pain points.' },
        { title: '2. Architecture & Security', desc: 'Implemented JWT token authentication with automated session timeouts.' },
        { title: '3. Tele-Consultation Engine', desc: 'Integrated WebRTC video conferencing with low latency.' }
      ],
      finalResult: 'Reduced patient wait times by 75% and facilitated over 12,000 successful online appointments in the first 6 months.',
      gallery: [
        'https://images.unsplash.com/photo-1576091160399-112ba8d25d1d?auto=format&fit=crop&w=1200&q=80',
        'https://images.unsplash.com/photo-1584515979956-d9f6e5d09982?auto=format&fit=crop&w=1200&q=80'
      ]
    }
  },
  {
    id: 'bengal-craft-ecommerce',
    title: 'Artisan Heritage — E-Commerce Store',
    titleBn: 'আর্টিজান হেরিটেজ — ই-কমার্স স্টোর',
    category: 'Client Projects',
    shortDesc: 'A modern e-commerce storefront for traditional Bangladeshi handicrafts, handloom sarees, and terracotta home decor.',
    shortDescBn: 'ঐতিহ্যবাহী বাংলাদেশি হস্তশিল্প ও জামদানি পণ্যের জন্য দৃষ্টিনন্দন আধুনিক ই-কমার্স প্ল্যাটফর্ম।',
    image: 'https://images.unsplash.com/photo-1472851294608-062f824d29cc?auto=format&fit=crop&w=1200&q=80',
    tags: ['React', 'Next.js', 'Stripe', 'Tailwind CSS', 'Redux Toolkit'],
    year: '2023',
    featured: false,
    liveUrl: 'https://example.com/demo/artisancraft',
    caseStudy: {
      overview: 'An international shopping portal showcasing authentic handcrafted artisan goods with multi-currency support and live order tracking.',
      problem: 'Artisans lacked a modern digital channel to market their products to international buyers with seamless checkout.',
      solution: 'Created an ultra-fast headless e-commerce store with dynamic currency conversion and localized payment gateway integration.',
      myRole: 'Frontend Lead & Payment Flow Integrator',
      technologies: ['React', 'Tailwind CSS', 'Stripe API', 'bKash/Nagad API', 'Redux Toolkit'],
      challenges: ['Optimizing high-resolution artisan photography without increasing page load times'],
      processSteps: [
        { title: '1. UI Styling', desc: 'Used warm earthy tones and modern clean typography to reflect heritage.' },
        { title: '2. Cart & Checkout', desc: 'Built a 1-page friction-free checkout flow.' }
      ],
      finalResult: 'Boosted conversion rates by 38% and onboarded 40+ rural artisan cooperatives.',
      gallery: [
        'https://images.unsplash.com/photo-1472851294608-062f824d29cc?auto=format&fit=crop&w=1200&q=80'
      ]
    }
  },
  {
    id: 'git-craft-cli',
    title: 'GitCraft — Developer Workflow CLI & GUI',
    titleBn: 'গিটক্রাফট — ডেভেলপার ওয়ার্কফ্লো সিএলআই',
    category: 'Open Source',
    shortDesc: 'An open-source interactive terminal tool and web companion for managing Git staging, semantic commits, and visual branching graphs.',
    shortDescBn: 'গিট কমিট ও ব্রাঞ্চ ব্যবস্থাপনার জন্য ওপেন-সোর্স টার্মিনাল টুল ও ওয়েব কম্প্যানিয়ন।',
    image: 'https://images.unsplash.com/photo-1618401471353-b98afee0b2eb?auto=format&fit=crop&w=1200&q=80',
    tags: ['TypeScript', 'Node.js', 'Open Source', 'CLI', 'WebSockets'],
    year: '2024',
    featured: false,
    githubUrl: 'https://github.com/mdjaberhosain/gitcraft-cli',
    caseStudy: {
      overview: 'GitCraft simplifies messy git histories through guided interactive prompts and visual commit staging.',
      problem: 'Junior developers frequently make unstructured commits and struggle with interactive rebasing.',
      solution: 'Created a zero-dependency CLI with a web visualization bridge for inspecting commits in real-time.',
      myRole: 'Sole Creator & Maintainer',
      technologies: ['TypeScript', 'Node.js', 'Ink', 'Commander.js'],
      challenges: ['Parsing complex git log trees across different operating system shells'],
      processSteps: [
        { title: '1. CLI Engine', desc: 'Built terminal UI with keyboard shortcuts.' },
        { title: '2. Open Source Release', desc: 'Published on npm with comprehensive docs and unit test coverage.' }
      ],
      finalResult: 'Garnered 350+ GitHub stars and 5,000+ monthly downloads on npm.',
      gallery: [
        'https://images.unsplash.com/photo-1618401471353-b98afee0b2eb?auto=format&fit=crop&w=1200&q=80'
      ]
    }
  },
  {
    id: 'neural-canvas-lab',
    title: 'Neural Canvas — Generative Flow Experiment',
    titleBn: 'নিউরাল ক্যানভাস — জেনারেটিভ ভিজ্যুয়াল এক্সপেরিমেন্ট',
    category: 'Experimental Projects',
    shortDesc: 'A WebGL and HTML5 Canvas interactive particle experiment generating mathematical fluid patterns responding to cursor velocity and sound.',
    shortDescBn: 'ওয়েবজিএল এবং ক্যানভাস ভিত্তিক ইন্টারঅ্যাক্টিভ পার্টিকল ও ফ্লুইড সিমুলেশন।',
    image: 'https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?auto=format&fit=crop&w=1200&q=80',
    tags: ['Canvas API', 'WebGL', 'Creative Coding', 'JavaScript', 'Audio API'],
    year: '2025',
    featured: false,
    liveUrl: 'https://example.com/demo/neuralcanvas',
    githubUrl: 'https://github.com/mdjaberhosain/neural-canvas',
    caseStudy: {
      overview: 'An experimental creative computing sandbox exploring generative math, cellular automata, and interactive sound visualizers.',
      problem: 'Exploring performance boundaries of rendering 50,000 interactive particles in pure browser threads.',
      solution: 'Utilized WebGL shaders and spatial grid partitioning to achieve locked 60 FPS.',
      myRole: 'Creative Developer',
      technologies: ['HTML5 Canvas', 'WebGL', 'Web Audio API', 'TypeScript'],
      challenges: ['Optimizing particle spatial lookup to avoid O(n^2) collision bottlenecks'],
      processSteps: [
        { title: '1. Shader Pipeline', desc: 'Engineered vertex and fragment shaders.' },
        { title: '2. Audio Reactive Layer', desc: 'Hooked Web Audio frequency analyser to particle acceleration.' }
      ],
      finalResult: 'Featured in creative coding showcases and viewed by thousands of design technologists.',
      gallery: [
        'https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?auto=format&fit=crop&w=1200&q=80'
      ]
    }
  }
];

export const INITIAL_SKILLS: SkillItem[] = [
  // Frontend
  { name: 'React.js & Next.js', category: 'Frontend', level: 'Expert', years: 4, projectsCount: 20, featured: true },
  { name: 'TypeScript & JavaScript (ESNext)', category: 'Frontend', level: 'Expert', years: 4, projectsCount: 22, featured: true },
  { name: 'Tailwind CSS & CSS Architecture', category: 'Frontend', level: 'Expert', years: 4, projectsCount: 24, featured: true },
  { name: 'HTML5 Semantic & WCAG Accessibility', category: 'Frontend', level: 'Expert', years: 4, projectsCount: 25, featured: true },
  { name: 'State Management (Redux, Zustand, Context)', category: 'Frontend', level: 'Advanced', years: 3, projectsCount: 15 },
  { name: 'Motion & Interactive Animations', category: 'Frontend', level: 'Advanced', years: 3, projectsCount: 14 },
  { name: 'Vue.js & Pinia', category: 'Frontend', level: 'Intermediate', years: 2, projectsCount: 6 },
  
  // Backend
  { name: 'Node.js & Express.js', category: 'Backend', level: 'Advanced', years: 3, projectsCount: 16, featured: true },
  { name: 'PostgreSQL & SQL Schema Design', category: 'Backend', level: 'Advanced', years: 3, projectsCount: 12, featured: true },
  { name: 'MongoDB & Mongoose', category: 'Backend', level: 'Advanced', years: 3, projectsCount: 14 },
  { name: 'RESTful API & GraphQL Architecture', category: 'Backend', level: 'Advanced', years: 3, projectsCount: 18, featured: true },
  { name: 'Firebase & Supabase', category: 'Backend', level: 'Advanced', years: 3, projectsCount: 10 },
  { name: 'Authentication (JWT, OAuth 2.0, RBAC)', category: 'Backend', level: 'Advanced', years: 3, projectsCount: 15 },

  // UI/UX Design
  { name: 'Figma UI/UX & Wireframing', category: 'UI/UX Design', level: 'Advanced', years: 3, projectsCount: 19, featured: true },
  { name: 'Design Systems & Token Standards', category: 'UI/UX Design', level: 'Advanced', years: 3, projectsCount: 11, featured: true },
  { name: 'Responsive & Mobile-First Design', category: 'UI/UX Design', level: 'Expert', years: 4, projectsCount: 25 },
  { name: 'Interactive Prototyping & User Flow', category: 'UI/UX Design', level: 'Advanced', years: 3, projectsCount: 14 },

  // Tools & DevOps
  { name: 'Git & GitHub Workflows', category: 'Tools', level: 'Expert', years: 4, projectsCount: 25, featured: true },
  { name: 'Vite & Webpack Build Systems', category: 'Tools', level: 'Advanced', years: 3, projectsCount: 18 },
  { name: 'Docker & Containerization Basics', category: 'Tools', level: 'Intermediate', years: 2, projectsCount: 7 },
  { name: 'Linux Command Line & Bash Scripting', category: 'Tools', level: 'Advanced', years: 3, projectsCount: 15 },
  { name: 'Postman & API Documentation', category: 'Tools', level: 'Advanced', years: 3, projectsCount: 20 },
  { name: 'Vercel, Netlify & Cloud Run Deployments', category: 'Tools', level: 'Advanced', years: 3, projectsCount: 22 },

  // Other Skills
  { name: 'Technical Writing & Documentation', category: 'Other Skills', level: 'Advanced', years: 3, projectsCount: 12 },
  { name: 'Performance Optimization & SEO Auditing', category: 'Other Skills', level: 'Advanced', years: 3, projectsCount: 16 },
  { name: 'Agile & Scrum Team Collaboration', category: 'Other Skills', level: 'Advanced', years: 3, projectsCount: 14 }
];

export const LEARNING_ROADMAP: RoadmapItem[] = [
  { technology: 'Rust for High-Throughput Web Services', category: 'Systems Programming', targetQuarter: 'Q3 2026', progress: 45, description: 'Mastering memory safety and building lightweight microservices.' },
  { technology: 'Advanced WebGL & Three.js 3D Portals', category: 'Creative Web', targetQuarter: 'Q4 2026', progress: 60, description: 'Integrating interactive 3D product visualizers and shader math.' },
  { technology: 'Distributed Systems & Micro-frontends', category: 'Cloud Architecture', targetQuarter: 'Q1 2027', progress: 30, description: 'Building resilient federated application architectures.' }
];

export const INITIAL_EXPERIENCE: ExperienceItem[] = [
  {
    id: 'exp-1',
    role: 'Senior Frontend & Web Developer',
    roleBn: 'সিনিয়র ফ্রন্টএন্ড ও ওয়েব ডেভেলপার',
    company: 'InnovateX Digital Solutions',
    companyBn: 'ইনোভেশনএক্স ডিজিটাল সলিউশনস',
    period: '2024 — Present',
    location: 'Remote / Dhaka',
    type: 'Full-time',
    responsibilities: [
      'Leading the architecture and development of client-facing SaaS web applications in React and TypeScript.',
      'Designing and maintaining the unified internal UI component library, cutting sprint dev time by 35%.',
      'Collaborating closely with backend engineers to integrate GraphQL and RESTful microservices with optimistic state updates.',
      'Mentoring junior web engineers on clean code practices, PR reviews, and automated testing.'
    ],
    keyAchievements: [
      'Improved Core Web Vitals to a 98+ Lighthouse score across 6 flagship enterprise web portals.',
      'Architected offline-first data synchronization that resolved dropped sessions for field users.'
    ],
    skills: ['React', 'TypeScript', 'Tailwind CSS', 'GraphQL', 'Next.js', 'Figma']
  },
  {
    id: 'exp-2',
    role: 'Full-Stack Web Developer & Consultant',
    roleBn: 'ফুল-স্ট্যাক ওয়েব ডেভেলপার ও কনসালট্যান্ট',
    company: 'Independent Craft & Client Collaborations',
    companyBn: 'স্বতন্ত্র ক্লায়েন্ট প্রজেক্ট ও কনসাল্টিং',
    period: '2022 — 2024',
    location: 'Global / Remote',
    type: 'Freelance',
    responsibilities: [
      'Engineered custom web solutions, bespoke e-commerce stores, and high-conversion landing pages for international clients.',
      'Delivered end-to-end projects from initial UI/UX wireframing in Figma to cloud deployment on Vercel and VPS.',
      'Integrated payment gateways (Stripe, bKash, SSLCommerz), CRM tools, and real-time notification systems.'
    ],
    keyAchievements: [
      'Delivered 18+ client projects with a 100% 5-star satisfaction record and repeat contracts.',
      'Engineered a real-time booking engine that processed $120k+ in quarterly client transactions.'
    ],
    skills: ['Node.js', 'Express', 'React', 'MongoDB', 'PostgreSQL', 'Stripe', 'REST APIs']
  },
  {
    id: 'exp-3',
    role: 'Junior Web Developer & UI Designer',
    roleBn: 'জুনিয়র ওয়েব ডেভেলপার ও ইউআই ডিজাইনার',
    company: 'TechCrafters Studio',
    companyBn: 'টেকক্রাফটার্স স্টুডিও',
    period: '2021 — 2022',
    location: 'Bangladesh',
    type: 'Contract',
    responsibilities: [
      'Converted Figma and Adobe XD prototypes into responsive, pixel-perfect HTML/CSS and JavaScript templates.',
      'Debugged cross-browser rendering inconsistencies and implemented mobile responsive touch layouts.',
      'Maintained version control repositories and assisted in writing technical product documentation.'
    ],
    keyAchievements: [
      'Refactored legacy CSS into modern modular styles, reducing stylesheet payload size by 45%.'
    ],
    skills: ['JavaScript', 'HTML5', 'CSS3', 'Bootstrap', 'Git', 'Figma']
  }
];

export const INITIAL_EDUCATION: EducationItem[] = [
  {
    id: 'edu-1',
    degree: 'B.Sc. in Computer Science & Engineering (CSE)',
    degreeBn: 'বি.এসসি ইন কম্পিউটার সায়েন্স অ্যান্ড ইঞ্জিনিয়ারিং (সিএসই)',
    institution: 'Leading Engineering & Technical Institution',
    institutionBn: 'নামকরা প্রকৌশল ও প্রযুক্তি বিশ্ববিদ্যালয়',
    period: '2020 — 2024',
    major: 'Computer Science, Software Engineering & Algorithms',
    achievements: [
      'Graduated with honors and stellar academic standing.',
      'Led the university coding club workshop on Modern Web Technologies and Open Source.',
      'Final Year Capstone: High-Efficiency Distributed Cloud Storage & Data Synchronization System.'
    ],
    certificates: [
      { title: 'Full Stack Web Development Professional Certificate', issuer: 'Meta / Coursera', date: '2023', verifyUrl: '#' },
      { title: 'Advanced React & TypeScript Architecture', issuer: 'Frontend Masters', date: '2024', verifyUrl: '#' },
      { title: 'PostgreSQL Database Administration & Indexing', issuer: 'Cloud Academy', date: '2024', verifyUrl: '#' }
    ],
    activities: [
      'National Inter-University Hackathon Finalist',
      'Technical Paper Reviewer for Student Engineering Journal',
      'Volunteer Instructor for coding bootcamps for underprivileged youth'
    ]
  },
  {
    id: 'edu-2',
    degree: 'Higher Secondary Certificate (HSC) — Science',
    degreeBn: 'উচ্চ মাধ্যমিক সার্টিফিকেট (এইচএসসি) — বিজ্ঞান বিভাগ',
    institution: 'Prominent College, Barisal Division',
    institutionBn: 'বরিশাল বিভাগের ঐতিহ্যবাহী কলেজ',
    period: '2018 — 2020',
    major: 'Physics, Chemistry, Higher Mathematics, ICT',
    achievements: [
      'Achieved GPA 5.00 (Golden A+) with exceptional performance in ICT and Mathematics.'
    ],
    certificates: [
      { title: 'National Science Olympiad Regional Merit Award', issuer: 'Bangladesh Science Society', date: '2019' }
    ]
  }
];

export const INITIAL_SERVICES: ServiceItem[] = [
  {
    id: 'srv-1',
    title: 'Full-Stack Web Application Development',
    titleBn: 'ফুল-স্ট্যাক ওয়েব অ্যাপ্লিকেশন ডেভেলপমেন্ট',
    shortDesc: 'Engineering modern, high-speed, and secure web applications with React, Next.js, Node.js, and robust databases.',
    shortDescBn: 'আধুনিক, নিরাপদ ও দ্রুতগতির পূর্ণাঙ্গ ওয়েব অ্যাপ্লিকেশন তৈরি।',
    icon: 'Code2',
    popular: true,
    process: [
      'Requirements mapping & architectural blueprint',
      'Figma prototype review & approval',
      'Modular frontend & secure API engineering',
      'Performance audit, SEO tuning & production deployment'
    ],
    deliverables: [
      'Clean, typed TypeScript codebase with zero debt',
      'Responsive, mobile-optimized cross-browser UI',
      'Complete API documentation & automated build pipeline',
      '30-day post-launch technical support & warranty'
    ]
  },
  {
    id: 'srv-2',
    title: 'Custom Portfolio & Personal Branding Site',
    titleBn: 'কাস্টম পোর্টফোলিও ও পার্সোনাল ব্র্যান্ডিং ওয়েবসাইট',
    shortDesc: 'Building one-of-a-kind digital identities with slick interactive storytelling, dark/light themes, and custom visitor hubs.',
    shortDescBn: 'ব্যক্তিগত পরিচিতি ও কাজের জন্য আকর্ষণীয় এবং অনন্য ওয়েবসাইট নির্মাণ।',
    icon: 'Sparkles',
    popular: true,
    process: [
      'Story discovery, resume curation & brand aesthetic design',
      'Interactive wireframe & typography system setup',
      'Custom animations, case studies & interactive visitor modules',
      'Domain setup, SEO indexing & shareable digital cards'
    ],
    deliverables: [
      'Bespoke visual identity & typography matching your persona',
      'Integrated digital garden, blog, and guestbook systems',
      'Interactive command palette (Ctrl+K) & visitor advice portal',
      'Lightning-fast CDN deployment'
    ]
  },
  {
    id: 'srv-3',
    title: 'UI/UX Design & Design System Creation',
    titleBn: 'ইউআই/ইউএক্স ডিজাইন ও ডিজাইন সিস্টেম',
    shortDesc: 'Designing intuitive, modern user interfaces in Figma with atomic design tokens, micro-interactions, and component guidelines.',
    shortDescBn: 'ফিগমায় নান্দনিক ইউজার ইন্টারফেস ও কম্পোনেন্ট লাইব্রেরি তৈরি।',
    icon: 'Palette',
    process: [
      'User journey mapping & low-fidelity wireframing',
      'High-fidelity visual design & tokenization in Figma',
      'Interactive clickable prototypes for user testing',
      'Developer handoff with design tokens & specs'
    ],
    deliverables: [
      'Complete Figma design file with autolayout components',
      'Semantic color, typography, and spacing tokens',
      'Interactive micro-interaction prototypes'
    ]
  },
  {
    id: 'srv-4',
    title: 'Website Redesign & Performance Optimization',
    titleBn: 'ওয়েবসাইট রিডিজাইন ও পারফরম্যান্স অপ্টিমাইজেশন',
    shortDesc: 'Modernizing outdated websites into sleek, 95+ Lighthouse score powerhouses with modern stacks and instant load times.',
    shortDescBn: 'পুরোনো সাইটকে আধুনিক রূপ দেওয়া এবং লোডিং স্পিড বহুগুণ বৃদ্ধি।',
    icon: 'Gauge',
    process: [
      'Comprehensive performance & UX heuristic audit',
      'Code refactoring & bundle size reduction',
      'Asset compression, caching strategy & edge rendering'
    ],
    deliverables: [
      '95+ Lighthouse Score across Performance & Accessibility',
      'Up to 70% reduction in page load latency',
      'Modern, refreshed visual appearance'
    ]
  }
];

export const INITIAL_ACHIEVEMENTS: AchievementItem[] = [
  {
    id: 'ach-1',
    title: 'Meta Certified Professional Web Developer',
    titleBn: 'মেটা সার্টিফাইড প্রফেশনাল ওয়েব ডেভেলপার',
    category: 'Certificate',
    issuer: 'Meta (Facebook)',
    date: '2023',
    description: 'Demonstrated mastery in React, advanced JavaScript algorithms, API architecture, and modern UX patterns.',
    badge: '🏆 Meta Verified'
  },
  {
    id: 'ach-2',
    title: 'National Hackathon Best UI/UX Innovation',
    titleBn: 'জাতীয় হ্যাকাথন সেরা ইউআই/ইউএক্স সম্মাননা',
    category: 'Award',
    issuer: 'National ICT Forum',
    date: '2024',
    description: 'Awarded first prize in the Human-Centered Design track for engineering an accessible healthcare disaster alert portal.',
    badge: '🥇 1st Place'
  },
  {
    id: 'ach-3',
    title: '25+ High-Impact Projects Deployed',
    titleBn: '২৫+ সফল প্রজেক্ট সম্পন্ন ও ডিপ্লয়মেন্ট',
    category: 'Milestone',
    issuer: 'Global Clients & Open Source',
    date: '2025',
    description: 'Successfully deployed over twenty-five production-ready web applications spanning fintech, healthcare, and e-commerce.',
    badge: '🚀 Milestone'
  },
  {
    id: 'ach-4',
    title: 'Open Source Community Contributor',
    titleBn: 'ওপেন সোর্স কমিউনিটি কন্ট্রিবিউটর',
    category: 'Milestone',
    issuer: 'GitHub Ecosystem',
    date: '2025',
    description: 'Authored tools, submitted PRs, and helped over 300+ developers improve their workflow with open-source utilities.',
    badge: '⭐ GitHub Star'
  }
];

export const INITIAL_NOW_DATA: NowPageData = {
  lastUpdated: 'August 27, 2026',
  currentFocus: [
    'Building next-generation full-stack personal digital hubs with high craft typography',
    'Deep-diving into high-performance distributed backend architectures and edge computing',
    'Curating open-source React component primitives and micro-interaction patterns'
  ],
  currentFocusBn: [
    'উন্নতমানের ফুল-স্ট্যাক ওয়েব অ্যাপ্লিকেশন ও পার্সোনাল ডিজিটাল হাব নির্মাণ',
    'উচ্চগতির ডিস্ট্রিবিউটেড ব্যাকএন্ড ও এজ কম্পিউটিং নিয়ে গবেষণা',
    'ওপেন-সোর্স রিঅ্যাক্ট কম্পোনেন্ট ও মাইক্রো-ইন্টারঅ্যাকশন ডিজাইন'
  ],
  currentlyLearning: [
    'Rust for WebAssembly and Systems Engineering',
    'Advanced WebGL Shaders & 3D Canvas Math',
    'PostgreSQL Query Optimization & Deep Indexing'
  ],
  currentlyReading: {
    title: 'Designing Data-Intensive Applications',
    author: 'Martin Kleppmann',
    progress: 72
  },
  activeProjects: [
    { name: 'Nexus Cloud Analytics 2.0', description: 'Real-time telemetry and streaming anomaly detector', status: 'In Progress' },
    { name: 'GitCraft GUI', description: 'Visual interactive commit staging app', status: 'Refining' },
    { name: 'Bengali Typography System', description: 'Optimized web font pairings for bilingual interfaces', status: 'Researching' }
  ],
  thirtyDayGoals: [
    'Ship 3 new open-source technical tutorials in the Digital Garden',
    'Complete the Rust memory model deep-dive course',
    'Collaborate with 2 global design engineers on accessible UI token standards',
    'Read 2 engineering and personal growth books'
  ],
  thirtyDayGoalsBn: [
    'ডিজিটাল গার্ডেনে ৩টি নতুন কারিগরি টিউটোরিয়াল প্রকাশ করা',
    'রাস্ট মেমোরি ম্যানেজমেন্টের অ্যাডভান্সড কোর্স সম্পন্ন করা',
    'বিশ্বমানের ডিজাইন ইঞ্জিনিয়ারদের সাথে অ্যাক্সেসিবল ইউআই নিয়ে কাজ করা',
    '২টি নতুন বই পাঠ সম্পন্ন করা'
  ],
  experiments: [
    'Audio-reactive particle simulations in Canvas 2D',
    'Zero-runtime CSS token compilation scripts',
    'Sub-millisecond state synchronization across browser tabs'
  ]
};

export const INITIAL_GARDEN_NOTES: GardenNote[] = [
  {
    id: 'note-react-patterns',
    title: 'Architecting Scalable React State in 2026',
    titleBn: 'আধুনিক রিঅ্যাক্ট অ্যাপ্লিকেশনে স্কেলেবল স্টেট আর্কিটেকচার',
    category: 'Tutorials',
    tags: ['React', 'Architecture', 'TypeScript', 'Performance'],
    updatedAt: 'Aug 20, 2026',
    readTime: '6 min read',
    growthStage: 'Evergreen',
    summary: 'Why over-centralizing state hurts performance, and how atomic state primitives and URL sync create indestructible UIs.',
    summaryBn: 'স্টেট ম্যানেজমেন্টের সেরা কৌশল এবং পারফরম্যান্স অপ্টিমাইজেশনের উপায়।',
    content: `
### The Core Problem with Giant Global Stores
In modern applications, storing every single input stroke inside a monolithic state store causes unnecessary re-render cascades across unmounted subtrees.

#### 3 Guiding Principles for Clean State:
1. **Colocate by default**: Keep state as close to the UI consumer as possible.
2. **Derive, do not duplicate**: If a value can be computed from existing props or state, compute it inline or with \`useMemo\`.
3. **URL as the Source of Truth**: For filters, pagination, search queries, and open drawers, store state in URL search parameters to make views easily bookmarkable and shareable.
    `
  },
  {
    id: 'note-bilingual-typography',
    title: 'Crafting High-Contrast Bengali & Latin Typography Pairings',
    titleBn: 'ইংরেজি ও বাংলা ফন্টের সমন্বয়ে দৃষ্টিনন্দন টাইপোগ্রাফি',
    category: 'Notes',
    tags: ['Typography', 'UI/UX', 'Bengali', 'Design'],
    updatedAt: 'Aug 15, 2026',
    readTime: '4 min read',
    growthStage: 'Budding',
    summary: 'Techniques for matching x-height, optical weight, and baseline alignment between Noto Sans Bengali and Outfit/Jakarta Sans.',
    content: `
### Balancing Optical Weight in Bilingual Interfaces
Bengali characters naturally possess conjuncts (যুক্তবর্ণ) and upper/lower matras that require slightly more vertical breathing room than standard Latin glyphs.

#### Best Practices:
- Increase line-height to \`1.65 - 1.75\` when rendering Bengali body text.
- Pair geometric Latin sans-serifs like **Outfit** with clean, open counters like **Noto Sans Bengali** or **Hind Siliguri**.
- Avoid squishing Bengali text in fixed-height pills. Always use flexible vertical padding!
    `
  },
  {
    id: 'note-api-security-rules',
    title: 'Defensive API Design: Guardrails Against Spam and Abuse',
    titleBn: 'স্প্যাম ও অপব্যবহার রোধে ডিফেন্সিভ এপিআই ডিজাইন',
    category: 'Things I\'ve Learned',
    tags: ['Security', 'Backend', 'API', 'Best Practices'],
    updatedAt: 'Aug 10, 2026',
    readTime: '5 min read',
    growthStage: 'Evergreen',
    summary: 'Combining rate limiting, mathematical honeypots, email RFC validation, and sanitized inputs to protect visitor endpoints.',
    content: `
### Multi-Layered Protection for Public Forms
When building open feedback or guestbook forms:
1. **Mathematical Challenge / Captcha**: Lightweight client-verified math questions stop 99% of basic automated crawler bots.
2. **Honeypot Hidden Fields**: Add an off-screen field that only bots will fill out. If filled, silently reject the request.
3. **Client & Server Sanitization**: Strip dangerous HTML tags and enforce character bounds before writing to databases or localStorage.
    `
  }
];

export const INITIAL_BLOG_POSTS: BlogPost[] = [
  {
    id: 'blog-future-of-web',
    title: 'The Philosophy of Digital Craftsmanship: Beyond Ordinary Templates',
    titleBn: 'ডিজিটাল ক্রাফটম্যানশিপের দর্শন: সাধারণ টেমপ্লেটের ঊর্ধ্বে',
    coverImage: 'https://images.unsplash.com/photo-1517694712202-14dd9538aa97?auto=format&fit=crop&w=1200&q=80',
    category: 'Technology',
    date: 'August 18, 2026',
    readTime: '5 min read',
    summary: 'Why generic website builders will never replace the bespoke empathy, optical harmony, and engineered speed of custom-crafted digital products.',
    summaryBn: 'কেন কাস্টম কোডিং ও যত্নশীল ডিজাইন সাধারণ টেমপ্লেটের চেয়ে অনেক বেশি কার্যকর।',
    tags: ['Philosophy', 'Web Development', 'Design', 'Craft'],
    likes: 42,
    toc: [
      { id: 'the-template-trap', text: '1. The Template Trap' },
      { id: 'the-four-pillars', text: '2. The Four Pillars of Craft' },
      { id: 'human-centric-code', text: '3. Human-Centric Code' }
    ],
    content: `
### 1. The Template Trap
Modern web users can sense when a website is merely a recycled template within seconds. Generic themes often come bloated with 20 plugins, unused CSS libraries, and sluggish page transitions.

### 2. The Four Pillars of Craft
True craftsmanship in software engineering rests upon four pillars:
1. **Speed & Accessibility**: If a user cannot load your site on a 3G mobile device in 2 seconds, great aesthetics mean very little.
2. **Typographic Rhythm**: Spacing, line heights, and optical contrast establish intuitive hierarchy without relying on loud banner graphics.
3. **Purposeful Animation**: Micro-interactions should confirm user intent, not show off animations for their own sake.
4. **Honest Engineering**: Writing clean, type-safe, resilient code that will remain maintainable for years to come.

### 3. Human-Centric Code
Every button we design and every API route we optimize ultimately touches a human being on the other side of the glass. Striving for excellence is not just a technical goal—it is a mark of respect for our users.
    `
  },
  {
    id: 'blog-performance-deepdive',
    title: 'Achieving a Perfect 100 Lighthouse Score on Heavy React Apps',
    titleBn: 'রিঅ্যাক্ট অ্যাপ্লিকেশনে পারফেক্ট ১০০ লাইটহাউস স্কোর অর্জনের উপায়',
    coverImage: 'https://images.unsplash.com/photo-1460925895917-afdab827c52f?auto=format&fit=crop&w=1200&q=80',
    category: 'Web Development',
    date: 'July 24, 2026',
    readTime: '7 min read',
    summary: 'A step-by-step breakdown of bundle analysis, image format optimizations (WebP/AVIF), font subsetting, and lazy chunk loading.',
    summaryBn: 'ওয়েব পারফরম্যান্স অপ্টিমাইজেশন ও দ্রুত লোডিংয়ের বাস্তবসম্মত গাইড।',
    tags: ['React', 'Performance', 'Vite', 'SEO'],
    likes: 58,
    toc: [
      { id: 'measuring-what-matters', text: '1. Measuring What Matters' },
      { id: 'font-optimization', text: '2. Font & Asset Subsetting' },
      { id: 'code-splitting', text: '3. Dynamic Chunk Loading' }
    ],
    content: `
### 1. Measuring What Matters
Before attempting optimizations, run a synthetic baseline audit with throttled CPU and network speeds. Focus on LCP (Largest Contentful Paint), CLS (Cumulative Layout Shift), and INP (Interaction to Next Paint).

### 2. Font & Asset Subsetting
Always preconnect to font origins and specify \`display=swap\` to avoid invisible text during layout. Ensure modern image formats with explicit width/height ratios prevent layout shifts.

### 3. Dynamic Chunk Loading
Split heavy dialogs, rich code syntax highlighters, and admin panels into lazy dynamic modules.
    `
  }
];

export const INITIAL_TESTIMONIALS: TestimonialItem[] = [
  {
    id: 'test-1',
    name: 'Tariqur Rahman',
    position: 'Chief Technology Officer',
    organization: 'NovaStream Systems',
    image: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=200&q=80',
    content: 'Jaber is one of those rare software engineers who excels equally at high-level system architecture and pixel-perfect design. He delivered our analytics platform ahead of schedule and with zero bugs in production.',
    contentBn: 'জাবের একজন অত্যন্ত প্রতিভাবান সফটওয়্যার ইঞ্জিনিয়ার। তিনি সিস্টেম আর্কিটেকচার এবং পিক্সেল-পারফেক্ট ডিজাইন উভয় ক্ষেত্রেই অসাধারণ পারদর্শী।',
    rating: 5
  },
  {
    id: 'test-2',
    name: 'Sarah Jenkins',
    position: 'Product Director',
    organization: 'FinEdge Global',
    image: 'https://images.unsplash.com/photo-1580489944761-15a19d654956?auto=format&fit=crop&w=200&q=80',
    content: 'Working with Md Jaber Hosain was a breath of fresh air. His attention to UX details, rapid response times, and clear communication made our web platform launch an overwhelming success.',
    contentBn: 'জাবেরের সাথে কাজ করার অভিজ্ঞতা চমৎকার ছিল। তার কাজের মান এবং যোগাযোগের আন্তরিকতা সত্যিই প্রশংসনীয়।',
    rating: 5
  },
  {
    id: 'test-3',
    name: 'Arif Hasan',
    position: 'Managing Partner',
    organization: 'Dhaka Craftworks',
    image: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&w=200&q=80',
    content: 'Jaber took our complex e-commerce requirements and turned them into a fast, elegant, and user-friendly experience. Our online sales increased by 40% within two months of launch!',
    contentBn: 'জাবের আমাদের জটিল ই-কমার্স প্রজেক্টটিকে একটি দ্রুতগতির ও চমৎকার ওয়েবসাইটে রূপান্তর করেছেন।',
    rating: 5
  }
];

export const INITIAL_GUESTBOOK: GuestbookEntry[] = [
  {
    id: 'gb-1',
    name: 'Kazi Mahbub',
    country: 'Bangladesh',
    flag: '🇧🇩',
    message: 'Mashallah! Truly one of the cleanest and most professional personal portfolios I have ever explored. Proud of your dedication, brother Jaber!',
    emoji: '🌟',
    createdAt: 'Aug 25, 2026',
    approved: true,
    likes: 12
  },
  {
    id: 'gb-2',
    name: 'Elena Rostova',
    country: 'Germany',
    flag: '🇩🇪',
    message: 'Stunning attention to typography and subtle animations. Your digital garden notes on React state are already bookmarked in my browser!',
    emoji: '🚀',
    createdAt: 'Aug 24, 2026',
    approved: true,
    likes: 8
  },
  {
    id: 'gb-3',
    name: 'Tanvir Ahmed',
    country: 'Canada',
    flag: '🇨🇦',
    message: 'Love the bilingual English & Bengali support and the interactive visitor advice hub. Keep inspiring the tech community, Jaber!',
    emoji: '💡',
    createdAt: 'Aug 22, 2026',
    approved: true,
    likes: 15
  }
];

export const INITIAL_VISITOR_ADVICE: VisitorAdvice[] = [
  {
    id: 'adv-1',
    fullName: 'Dr. Shahriar Kabir',
    email: 'shahriar.kabir@example.com',
    subject: 'AI & Edge Web Integration',
    category: 'Skill Development',
    message: 'I really love your work ethics and clean code structure. My advice would be to explore on-device WebGPU models alongside Rust Wasm. That combination is going to redefine web capabilities in the coming years!',
    isPublicApprovedByVisitor: true,
    isApprovedByAdmin: true,
    isFeatured: true,
    isRead: true,
    isImportant: true,
    createdAt: 'August 24, 2026',
    replyNote: 'Thank you so much Dr. Kabir! I am currently studying WebGPU shader pipelines and Rust compilation.'
  },
  {
    id: 'adv-2',
    fullName: 'Mahira Chowdhury',
    email: 'mahira.ux@example.com',
    subject: 'Open Source Community Workshops',
    category: 'Career Advice',
    message: 'Consider hosting live YouTube or Discord coding sessions in Bengali for university students. Your teaching clarity in the Digital Garden notes would help thousands of aspiring coders in Bangladesh!',
    isPublicApprovedByVisitor: true,
    isApprovedByAdmin: true,
    isFeatured: true,
    isRead: true,
    isImportant: true,
    createdAt: 'August 22, 2026',
    replyNote: 'That is a wonderful recommendation Mahira! I am setting up recorded video guides for next month.'
  },
  {
    id: 'adv-3',
    fullName: 'David Vance',
    email: 'david.vance@techcorp.io',
    subject: 'Interactive Project Case Studies',
    category: 'Portfolio Feedback',
    message: 'Your project case studies are thorough and highlight business impact really well. Adding quick architecture diagrams alongside the challenges section makes it even punchier for hiring managers!',
    isPublicApprovedByVisitor: true,
    isApprovedByAdmin: true,
    isFeatured: false,
    isRead: true,
    isImportant: false,
    createdAt: 'August 19, 2026'
  }
];

export const INITIAL_DASHBOARD_STATE: PersonalDashboardState = {
  currentFocus: 'Building Next-Gen Full-Stack Web Portals & Mastering Distributed Systems',
  status: 'Available',
  currentlyListening: {
    title: 'Code Symphony & Lo-Fi Focus Beats',
    artist: 'Ambient Dev Flow',
    streamingLink: '#'
  },
  readingList: [
    { title: 'Designing Data-Intensive Applications', author: 'Martin Kleppmann', status: 'Reading' },
    { title: 'Clean Architecture in TypeScript', author: 'Robert C. Martin', status: 'Completed' },
    { title: 'Atomic Habits', author: 'James Clear', status: 'Completed' },
    { title: 'Refactoring UI', author: 'Adam Wathan & Steve Schoger', status: 'Completed' }
  ],
  personalGoals: [
    { goal: 'Publish 5 high-impact open source modules', category: 'Engineering', completed: false },
    { goal: 'Complete Rust memory architecture deep-dive', category: 'Learning', completed: false },
    { goal: 'Maintain 98+ Lighthouse scores across all client deliveries', category: 'Quality', completed: true },
    { goal: 'Read 12 technical and self-growth books this year', category: 'Personal', completed: true }
  ],
  projectPipeline: [
    { title: 'Nexus Intelligence Platform 2.0', category: 'Web Development', status: 'In Progress', progress: 75 },
    { title: 'Bengali Typography Design Tokens', category: 'UI/UX Design', status: 'In Progress', progress: 85 },
    { title: 'GitCraft Interactive GUI', category: 'Open Source', status: 'Planning', progress: 30 },
    { title: 'MediSync Hospital Portal', category: 'Client Work', status: 'Completed', progress: 100 }
  ],
  dailyQuote: {
    text: '“Excellence is not an accident; it is the progressive result of continuous striving to do better.”',
    author: 'Md Jaber Hosain'
  }
};
