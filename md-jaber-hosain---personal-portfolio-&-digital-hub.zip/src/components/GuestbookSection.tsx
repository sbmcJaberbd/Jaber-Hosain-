import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import {
  MessageSquare,
  Sparkles,
  Send,
  Heart,
  Globe,
  MapPin,
  CheckCircle2
} from 'lucide-react';

export const GuestbookSection: React.FC = () => {
  const { guestbook, addGuestbookEntry, language, t } = useApp();
  const entries = guestbook || [];

  const [name, setName] = useState('');
  const [location, setLocation] = useState('');
  const [avatar, setAvatar] = useState('👋');
  const [message, setMessage] = useState('');
  const [submitted, setSubmitted] = useState(false);

  const emojis = ['👋', '🚀', '☕', '💡', '🔥', '🌟', '💻', '🎨'];

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim() || !message.trim()) return;

    addGuestbookEntry({
      name: name.trim(),
      location: location.trim() || 'Global',
      country: location.trim() || 'Global',
      avatar,
      emoji: avatar,
      flag: '🌐',
      message: message.trim()
    });

    setName('');
    setLocation('');
    setMessage('');
    setSubmitted(true);
    setTimeout(() => setSubmitted(false), 4000);
  };

  return (
    <section id="guestbook" className="py-24 relative">
      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Header */}
        <div className="text-center max-w-3xl mx-auto mb-16 space-y-3">
          <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-emerald-500/10 border border-emerald-500/30 text-emerald-600 dark:text-emerald-400 text-xs font-semibold font-mono">
            <MessageSquare className="w-3.5 h-3.5" />
            <span>{t('Visitor Wall', 'গেস্টবুক ও বার্তা')}</span>
          </div>
          <h2 className="text-3xl sm:text-5xl font-extrabold text-neutral-950 dark:text-white tracking-tight">
            {t('Leave Your Mark on the Guestbook', 'আপনার স্মৃতিচিহ্ন রেখে যান')}
          </h2>
          <p className="text-neutral-600 dark:text-neutral-400 text-base sm:text-lg">
            {t(
              'Sign the guestbook with a quick greeting, warm wishes, or hello from anywhere across the globe.',
              'বিশ্বের যেকোনো প্রান্ত থেকে একটি শুভেচ্ছা বার্তা বা হাই লিখে যান।'
            )}
          </p>
        </div>

        {/* 2-Column Split: Sign Box & Entries Wall */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
          
          {/* Sign Form (5 cols) */}
          <div className="lg:col-span-5 p-7 rounded-3xl bg-white dark:bg-neutral-900/90 border border-neutral-200/80 dark:border-neutral-800 shadow-md space-y-5">
            <div className="space-y-1">
              <h3 className="text-lg font-bold text-neutral-950 dark:text-white">
                {t('Sign the Wall', 'গেস্টবুকে লিখুন')}
              </h3>
              <p className="text-xs text-neutral-500">
                {t('No login strictly required, instant sign-in.', 'সহজেই বার্তা যোগ করুন।')}
              </p>
            </div>

            {submitted && (
              <div className="p-3.5 rounded-2xl bg-emerald-500/15 border border-emerald-500/30 text-emerald-600 dark:text-emerald-400 text-xs flex items-center gap-2">
                <CheckCircle2 className="w-4 h-4" />
                <span>{t('Signed successfully! Thank you.', 'সফলভাবে যুক্ত হয়েছে! ধন্যবাদ।')}</span>
              </div>
            )}

            <form onSubmit={handleSubmit} className="space-y-3.5">
              <div>
                <label className="block text-xs font-bold text-neutral-700 dark:text-neutral-300 mb-1">
                  {t('Your Name', 'নাম')} *
                </label>
                <input
                  type="text"
                  required
                  placeholder="e.g. Shakil Ahmed"
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  className="w-full px-4 py-2.5 rounded-2xl bg-neutral-50 dark:bg-neutral-950 border border-neutral-200 dark:border-neutral-800 text-xs text-neutral-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-emerald-500/50"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-neutral-700 dark:text-neutral-300 mb-1">
                  {t('Location / City', 'শহর বা দেশ')}
                </label>
                <input
                  type="text"
                  placeholder="e.g. Dhaka, Bangladesh"
                  value={location}
                  onChange={(e) => setLocation(e.target.value)}
                  className="w-full px-4 py-2.5 rounded-2xl bg-neutral-50 dark:bg-neutral-950 border border-neutral-200 dark:border-neutral-800 text-xs text-neutral-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-emerald-500/50"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-neutral-700 dark:text-neutral-300 mb-1">
                  {t('Choose Avatar Icon', 'আইকন নির্বাচন করুন')}
                </label>
                <div className="flex gap-2">
                  {emojis.map((e) => (
                    <button
                      type="button"
                      key={e}
                      onClick={() => setAvatar(e)}
                      className={`p-2 rounded-xl text-sm border transition-all ${
                        avatar === e
                          ? 'bg-emerald-500/20 border-emerald-500 scale-110'
                          : 'bg-neutral-100 dark:bg-neutral-800 border-neutral-200 dark:border-neutral-700'
                      }`}
                    >
                      {e}
                    </button>
                  ))}
                </div>
              </div>

              <div>
                <label className="block text-xs font-bold text-neutral-700 dark:text-neutral-300 mb-1">
                  {t('Short Greeting or Message', 'বার্তা')} *
                </label>
                <textarea
                  required
                  rows={3}
                  placeholder={t('Great portfolio Jaber! Keep building!', 'দারুণ পোর্টফোলিও জাবের! এগিয়ে যাও!')}
                  value={message}
                  onChange={(e) => setMessage(e.target.value)}
                  className="w-full px-4 py-2.5 rounded-2xl bg-neutral-50 dark:bg-neutral-950 border border-neutral-200 dark:border-neutral-800 text-xs text-neutral-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-emerald-500/50 resize-none"
                />
              </div>

              <button
                type="submit"
                id="submit-guestbook-btn"
                className="w-full py-2.5 px-4 rounded-2xl bg-neutral-950 dark:bg-white text-white dark:text-neutral-950 font-bold text-xs flex items-center justify-center gap-2 hover:opacity-90 transition-opacity"
              >
                <Send className="w-3.5 h-3.5" />
                <span>{t('Post to Guestbook', 'গেস্টবুকে পোস্ট করুন')}</span>
              </button>
            </form>
          </div>

          {/* Entries (7 cols) */}
          <div className="lg:col-span-7 space-y-3.5 max-h-[500px] overflow-y-auto pr-1">
            {entries.map((entry) => (
              <div
                key={entry.id}
                className="p-5 rounded-3xl bg-white dark:bg-neutral-900/80 border border-neutral-200/80 dark:border-neutral-800 shadow-sm flex items-start gap-4"
              >
                <div className="w-10 h-10 rounded-2xl bg-neutral-100 dark:bg-neutral-800 flex items-center justify-center text-lg shrink-0">
                  {entry.avatar || entry.emoji || '👋'}
                </div>

                <div className="flex-1 space-y-1.5">
                  <div className="flex items-center justify-between">
                    <div className="font-bold text-xs text-neutral-950 dark:text-white">
                      {entry.name}
                    </div>
                    <div className="text-[10px] font-mono text-neutral-400">
                      {entry.createdAt}
                    </div>
                  </div>

                  <div className="flex items-center gap-1 text-[11px] font-mono text-neutral-400">
                    <MapPin className="w-3 h-3 text-emerald-500" />
                    <span>{entry.location || entry.country || (entry.flag ? `${entry.flag} Global` : 'Global')}</span>
                  </div>

                  <p className="text-xs text-neutral-700 dark:text-neutral-300 leading-relaxed pt-1">
                    {entry.message}
                  </p>
                </div>
              </div>
            ))}
          </div>

        </div>

      </div>
    </section>
  );
};
