import React, { useState, useEffect } from 'react';
import { useApp } from '../context/AppContext';
import { PROFILE_INFO } from '../data/initialData';
import {
  Sparkles,
  ArrowDown,
  ArrowRight,
  Send,
  MapPin,
  Clock,
  Briefcase,
  CheckCircle2,
  Code,
  Layers,
  Github,
  Linkedin,
  Facebook,
  Twitter,
  Mail,
  Camera
} from 'lucide-react';

export const Hero: React.FC = () => {
  const { language, customAvatar, updateCustomAvatar, setDigitalCardOpen, t } = useApp();

  // Dynamic Typewriter / Rotating Title
  const titles = [
    'Full-Stack Software Engineer',
    'Creative UI/UX Designer',
    'Modern Web Architect',
    'Problem Solver & Builder',
    'Digital Experience Artisan'
  ];

  const titlesBn = [
    'ফুল-স্ট্যাক সফটওয়্যার ইঞ্জিনিয়ার',
    'ক্রিয়েটিভ ইউআই/ইউএক্স ডিজাইনার',
    'মডার্ন ওয়েব আর্কিটেক্ট',
    'প্রবলেম সলভার ও ক্রিয়েটর',
    'ডিজিটাল এক্সপেরিয়েন্স কারিগর'
  ];

  const [currentTitleIndex, setCurrentTitleIndex] = useState(0);
  const [displayText, setDisplayText] = useState('');
  const [isDeleting, setIsDeleting] = useState(false);
  const [typingSpeed, setTypingSpeed] = useState(100);

  // Local Time Clock for Bangladesh (UTC+6)
  const [localTime, setLocalTime] = useState('');

  useEffect(() => {
    const updateTime = () => {
      const now = new Date();
      // Format to BD Time
      const timeStr = now.toLocaleTimeString('en-US', {
        timeZone: 'Asia/Dhaka',
        hour: '2-digit',
        minute: '2-digit',
        second: '2-digit',
        hour12: true
      });
      setLocalTime(timeStr);
    };
    updateTime();
    const interval = setInterval(updateTime, 1000);
    return () => clearInterval(interval);
  }, []);

  // Typing Effect Loop
  useEffect(() => {
    const fullText = language === 'bn' ? titlesBn[currentTitleIndex] : titles[currentTitleIndex];

    const timer = setTimeout(() => {
      if (!isDeleting) {
        setDisplayText(fullText.substring(0, displayText.length + 1));
        if (displayText.length + 1 === fullText.length) {
          setTimeout(() => setIsDeleting(true), 2000);
        }
      } else {
        setDisplayText(fullText.substring(0, displayText.length - 1));
        if (displayText.length === 0) {
          setIsDeleting(false);
          setCurrentTitleIndex((prev) => (prev + 1) % titles.length);
        }
      }
    }, isDeleting ? 40 : typingSpeed);

    return () => clearTimeout(timer);
  }, [displayText, isDeleting, currentTitleIndex, language]);

  // Image Upload handler
  const handlePhotoUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = (event) => {
        if (event.target?.result) {
          updateCustomAvatar(event.target.result as string);
        }
      };
      reader.readAsDataURL(file);
    }
  };

  const scrollToSection = (id: string) => {
    const el = document.getElementById(id);
    if (el) {
      el.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <section
      id="home"
      className="relative min-h-screen pt-28 pb-16 flex flex-col justify-between overflow-hidden"
    >
      {/* Subtle Ambient Background Gradients */}
      <div className="absolute top-1/4 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[600px] h-[600px] bg-emerald-500/10 dark:bg-emerald-500/15 rounded-full blur-[140px] pointer-events-none -z-10 animate-ambient" />
      <div className="absolute top-1/3 right-10 w-[400px] h-[400px] bg-indigo-500/10 dark:bg-indigo-500/10 rounded-full blur-[120px] pointer-events-none -z-10 animate-ambient delay-1000" />
      
      {/* Decorative Grid Mesh */}
      <div className="absolute inset-0 bg-[linear-gradient(to_right,#8882_1px,transparent_1px),linear-gradient(to_bottom,#8882_1px,transparent_1px)] bg-[size:4rem_4rem] [mask-image:radial-gradient(ellipse_60%_50%_at_50%_40%,#000_70%,transparent_100%)] pointer-events-none -z-10 opacity-30" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 w-full my-auto">
        {/* Top Badges: Live Status & Bangladesh Local Time */}
        <div className="flex flex-wrap items-center justify-center gap-3 mb-8">
          {/* Availability Badge */}
          <div
            id="hero-availability-badge"
            className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-emerald-500/10 border border-emerald-500/30 text-emerald-600 dark:text-emerald-400 text-xs font-semibold shadow-sm backdrop-blur-md"
          >
            <span className="relative flex h-2.5 w-2.5">
              <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75" />
              <span className="relative inline-flex rounded-full h-2.5 w-2.5 bg-emerald-500" />
            </span>
            <span>{t(PROFILE_INFO.availability, PROFILE_INFO.availabilityBn)}</span>
          </div>

          {/* Location & Real-Time Clock */}
          <div className="inline-flex items-center gap-3 px-3.5 py-1.5 rounded-full bg-neutral-100 dark:bg-neutral-900/80 border border-neutral-200 dark:border-neutral-800 text-xs text-neutral-600 dark:text-neutral-300 font-mono shadow-sm">
            <div className="flex items-center gap-1">
              <MapPin className="w-3.5 h-3.5 text-rose-500" />
              <span>{t('Dhaka & Barisal, BD', 'ঢাকা ও বরিশাল, বাংলাদেশ')}</span>
            </div>
            <span className="text-neutral-300 dark:text-neutral-700">|</span>
            <div className="flex items-center gap-1">
              <Clock className="w-3.5 h-3.5 text-emerald-500" />
              <span>{localTime || 'GMT+6'}</span>
            </div>
          </div>
        </div>

        {/* Center Grid: Visual Profile + Personal Story Showcase */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-10 items-center">
          
          {/* Left Column: Greeting, Big Typography, Typing Role & Bio (7 cols) */}
          <div className="lg:col-span-7 text-center lg:text-left space-y-6">
            
            <div className="space-y-2">
              <div className="inline-flex items-center gap-2 text-sm font-semibold tracking-wide uppercase font-mono text-emerald-600 dark:text-emerald-400">
                <Sparkles className="w-4 h-4" />
                <span>{t("Assalamu Alaikum & Welcome", "আসসালামু আলাইকুম")}</span>
              </div>
              
              <h1 className="text-4xl sm:text-6xl xl:text-7xl font-extrabold tracking-tight text-neutral-950 dark:text-white leading-[1.08]">
                {t("Hello, I'm", "আমি")}{' '}
                <span className="relative inline-block text-transparent bg-clip-text bg-gradient-to-r from-emerald-600 via-teal-500 to-indigo-500 dark:from-emerald-400 dark:via-teal-300 dark:to-indigo-400">
                  {language === 'bn' ? PROFILE_INFO.nameBn : PROFILE_INFO.name}
                </span>
              </h1>
            </div>

            {/* Dynamic Typewriter Role Display */}
            <div className="h-12 sm:h-14 flex items-center justify-center lg:justify-start">
              <div className="text-xl sm:text-2xl lg:text-3xl font-semibold text-neutral-800 dark:text-neutral-200 font-heading">
                <span className="text-neutral-400 mr-2 font-normal font-mono">&gt;</span>
                <span className="border-b-2 border-emerald-500 pb-0.5">{displayText}</span>
                <span className="animate-pulse text-emerald-500 font-bold ml-1">_</span>
              </div>
            </div>

            {/* Tagline / Subtitle */}
            <p className="text-base sm:text-lg text-neutral-600 dark:text-neutral-400 max-w-2xl mx-auto lg:mx-0 leading-relaxed">
              {t(PROFILE_INFO.tagline, PROFILE_INFO.taglineBn)}
            </p>

            {/* CTA Buttons */}
            <div className="flex flex-wrap items-center justify-center lg:justify-start gap-3.5 pt-2">
              <button
                id="hero-view-work-btn"
                onClick={() => scrollToSection('portfolio')}
                className="group px-6 py-3.5 rounded-2xl bg-neutral-950 text-white dark:bg-white dark:text-neutral-950 font-bold text-sm hover:scale-[1.02] active:scale-[0.98] transition-all duration-200 shadow-xl shadow-black/10 flex items-center gap-2"
              >
                <span>{t('View My Work', 'আমার কাজসমূহ')}</span>
                <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
              </button>

              <button
                id="hero-lets-talk-btn"
                onClick={() => scrollToSection('contact')}
                className="px-6 py-3.5 rounded-2xl bg-neutral-100 dark:bg-neutral-900 border border-neutral-200 dark:border-neutral-800 text-neutral-900 dark:text-white font-semibold text-sm hover:bg-neutral-200/70 dark:hover:bg-neutral-800 transition-all flex items-center gap-2"
              >
                <Send className="w-4 h-4 text-emerald-500" />
                <span>{t("Let's Talk", 'কথা বলি')}</span>
              </button>

              <button
                id="hero-give-advice-btn"
                onClick={() => scrollToSection('advice')}
                className="px-5 py-3.5 rounded-2xl bg-emerald-500/10 border border-emerald-500/30 text-emerald-600 dark:text-emerald-400 font-semibold text-sm hover:bg-emerald-500/20 transition-all flex items-center gap-2"
              >
                <Sparkles className="w-4 h-4" />
                <span>{t('Give Advice', 'পরামর্শ দিন')}</span>
              </button>
            </div>

            {/* Social Channels Strip */}
            <div className="flex items-center justify-center lg:justify-start gap-3 pt-3">
              <span className="text-xs font-mono text-neutral-400">{t('Connect:', 'সোশ্যাল:')}</span>
              <div className="flex items-center gap-2">
                <a
                  href={PROFILE_INFO.socialLinks.github}
                  target="_blank"
                  rel="noreferrer"
                  title="GitHub Profile"
                  className="p-2.5 rounded-xl border border-neutral-200 dark:border-neutral-800 text-neutral-600 dark:text-neutral-400 hover:text-neutral-950 dark:hover:text-white hover:bg-neutral-100 dark:hover:bg-neutral-800/80 transition-all"
                >
                  <Github className="w-4 h-4" />
                </a>
                <a
                  href={PROFILE_INFO.socialLinks.linkedin}
                  target="_blank"
                  rel="noreferrer"
                  title="LinkedIn"
                  className="p-2.5 rounded-xl border border-neutral-200 dark:border-neutral-800 text-neutral-600 dark:text-neutral-400 hover:text-[#0077b5] hover:bg-neutral-100 dark:hover:bg-neutral-800/80 transition-all"
                >
                  <Linkedin className="w-4 h-4" />
                </a>
                <a
                  href={PROFILE_INFO.socialLinks.facebook}
                  target="_blank"
                  rel="noreferrer"
                  title="Facebook"
                  className="p-2.5 rounded-xl border border-neutral-200 dark:border-neutral-800 text-neutral-600 dark:text-neutral-400 hover:text-[#1877f2] hover:bg-neutral-100 dark:hover:bg-neutral-800/80 transition-all"
                >
                  <Facebook className="w-4 h-4" />
                </a>
                <a
                  href={PROFILE_INFO.socialLinks.twitter}
                  target="_blank"
                  rel="noreferrer"
                  title="X (Twitter)"
                  className="p-2.5 rounded-xl border border-neutral-200 dark:border-neutral-800 text-neutral-600 dark:text-neutral-400 hover:text-neutral-950 dark:hover:text-white hover:bg-neutral-100 dark:hover:bg-neutral-800/80 transition-all"
                >
                  <Twitter className="w-4 h-4" />
                </a>
                <a
                  href={`mailto:${PROFILE_INFO.email}`}
                  title="Send Email"
                  className="p-2.5 rounded-xl border border-neutral-200 dark:border-neutral-800 text-neutral-600 dark:text-neutral-400 hover:text-emerald-500 hover:bg-neutral-100 dark:hover:bg-neutral-800/80 transition-all"
                >
                  <Mail className="w-4 h-4" />
                </a>
              </div>
            </div>

          </div>

          {/* Right Column: Centerpiece Profile Frame + Interactive Badges (5 cols) */}
          <div className="lg:col-span-5 flex flex-col items-center justify-center">
            <div className="relative group">
              
              {/* Outer Decorative Ring Glow */}
              <div className="absolute -inset-2 bg-gradient-to-r from-emerald-500/30 via-teal-500/20 to-indigo-500/30 rounded-[2.5rem] blur-xl opacity-70 group-hover:opacity-100 transition duration-500 animate-pulse-glow" />
              
              {/* Profile Card Container */}
              <div className="relative w-72 sm:w-80 h-96 sm:h-[430px] rounded-[2.2rem] bg-neutral-900 border-2 border-neutral-800 dark:border-neutral-700/80 overflow-hidden shadow-2xl p-2.5 flex flex-col justify-between">
                
                {/* Profile Photo */}
                <div className="relative w-full h-[82%] rounded-[1.8rem] overflow-hidden bg-neutral-950">
                  <img
                    id="hero-profile-avatar-img"
                    src={customAvatar || PROFILE_INFO.avatar}
                    alt={PROFILE_INFO.name}
                    className="w-full h-full object-cover object-top group-hover:scale-105 transition-transform duration-500"
                    onError={(e) => {
                      (e.target as HTMLImageElement).src = 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=800&q=80';
                    }}
                  />
                  
                  {/* Subtle gradient overlay at base */}
                  <div className="absolute inset-0 bg-gradient-to-t from-neutral-950 via-transparent to-transparent opacity-80" />

                  {/* Photo Customizer / Uploader Trigger Button */}
                  <label
                    htmlFor="photo-upload-input"
                    title={t('Upload / Change Profile Picture', 'ছবি পরিবর্তন করুন')}
                    className="absolute top-3 right-3 p-2.5 rounded-full bg-neutral-950/80 hover:bg-neutral-900 text-white backdrop-blur-md border border-white/20 cursor-pointer opacity-80 hover:opacity-100 transition-all shadow-md"
                  >
                    <Camera className="w-4 h-4 text-emerald-400" />
                    <input
                      id="photo-upload-input"
                      type="file"
                      accept="image/*"
                      onChange={handlePhotoUpload}
                      className="hidden"
                    />
                  </label>

                  {/* On-Image Name Pill */}
                  <div className="absolute bottom-3 left-3 right-3 p-3 rounded-2xl bg-neutral-950/85 backdrop-blur-md border border-neutral-800/80 text-left">
                    <div className="text-sm font-bold text-white tracking-tight flex items-center justify-between">
                      <span>{PROFILE_INFO.name}</span>
                      <span className="text-[10px] font-mono px-2 py-0.5 rounded-full bg-emerald-500/20 text-emerald-400 border border-emerald-500/30">
                        {t('Verified Dev', 'ভেরিফাইড')}
                      </span>
                    </div>
                    <p className="text-[11px] text-neutral-400 truncate mt-0.5">
                      {PROFILE_INFO.email}
                    </p>
                  </div>
                </div>

                {/* Card Base Strip */}
                <div className="h-[15%] flex items-center justify-between px-2 pt-1">
                  <div className="flex items-center gap-2">
                    <span className="w-2 h-2 rounded-full bg-emerald-500" />
                    <span className="text-xs font-mono text-neutral-300">
                      {t('Full-Stack Artisan', 'ফুল-স্ট্যাক কারিগর')}
                    </span>
                  </div>
                  <button
                    onClick={() => setDigitalCardOpen(true)}
                    className="text-xs font-semibold text-emerald-400 hover:text-emerald-300 transition-colors"
                  >
                    {t('Digital Card →', 'কার্ড →')}
                  </button>
                </div>
              </div>

              {/* Floating Orbiting Badges */}
              <div className="absolute -top-4 -left-6 px-3.5 py-2 rounded-2xl bg-white dark:bg-neutral-900 border border-neutral-200 dark:border-neutral-800 shadow-xl flex items-center gap-2 backdrop-blur-md">
                <Code className="w-4 h-4 text-emerald-500" />
                <span className="text-xs font-bold text-neutral-900 dark:text-white">React & TypeScript</span>
              </div>

              <div className="absolute -bottom-4 -right-6 px-3.5 py-2 rounded-2xl bg-white dark:bg-neutral-900 border border-neutral-200 dark:border-neutral-800 shadow-xl flex items-center gap-2 backdrop-blur-md">
                <Layers className="w-4 h-4 text-indigo-500" />
                <span className="text-xs font-bold text-neutral-900 dark:text-white">UI/UX Architecture</span>
              </div>
            </div>
          </div>

        </div>

        {/* Quick Statistics Bar */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mt-16 pt-8 border-t border-neutral-200/60 dark:border-neutral-800/80">
          <div className="p-4 rounded-2xl bg-neutral-100/60 dark:bg-neutral-900/60 border border-neutral-200/50 dark:border-neutral-800/60 text-center">
            <div className="text-2xl sm:text-3xl font-extrabold text-neutral-950 dark:text-white font-heading">
              {PROFILE_INFO.projectsCompleted}
            </div>
            <div className="text-xs text-neutral-500 dark:text-neutral-400 font-medium mt-1">
              {t('Projects Completed', 'প্রজেক্ট সম্পন্ন')}
            </div>
          </div>

          <div className="p-4 rounded-2xl bg-neutral-100/60 dark:bg-neutral-900/60 border border-neutral-200/50 dark:border-neutral-800/60 text-center">
            <div className="text-2xl sm:text-3xl font-extrabold text-emerald-600 dark:text-emerald-400 font-heading">
              {PROFILE_INFO.technologiesMastered}
            </div>
            <div className="text-xs text-neutral-500 dark:text-neutral-400 font-medium mt-1">
              {t('Core Technologies', 'প্রযুক্তি দক্ষতা')}
            </div>
          </div>

          <div className="p-4 rounded-2xl bg-neutral-100/60 dark:bg-neutral-900/60 border border-neutral-200/50 dark:border-neutral-800/60 text-center">
            <div className="text-2xl sm:text-3xl font-extrabold text-indigo-600 dark:text-indigo-400 font-heading">
              {PROFILE_INFO.yearsOfLearning}
            </div>
            <div className="text-xs text-neutral-500 dark:text-neutral-400 font-medium mt-1">
              {t('Years of Learning & Craft', 'অভিজ্ঞতা ও শিখন')}
            </div>
          </div>

          <div className="p-4 rounded-2xl bg-neutral-100/60 dark:bg-neutral-900/60 border border-neutral-200/50 dark:border-neutral-800/60 text-center">
            <div className="text-2xl sm:text-3xl font-extrabold text-amber-500 font-heading">
              100%
            </div>
            <div className="text-xs text-neutral-500 dark:text-neutral-400 font-medium mt-1">
              {t('Client Dedication', 'ক্লায়েন্ট সন্তুষ্টি')}
            </div>
          </div>
        </div>

        {/* Scroll Indicator */}
        <div className="flex justify-center mt-10">
          <button
            onClick={() => scrollToSection('about')}
            title="Scroll to next section"
            className="flex flex-col items-center gap-1.5 text-xs text-neutral-400 hover:text-emerald-500 transition-colors animate-bounce"
          >
            <span>{t('Explore Portfolio', 'বিস্তারিত দেখুন')}</span>
            <ArrowDown className="w-4 h-4" />
          </button>
        </div>
      </div>
    </section>
  );
};
