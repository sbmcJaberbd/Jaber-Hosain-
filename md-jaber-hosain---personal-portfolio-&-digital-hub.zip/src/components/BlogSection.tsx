import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { BlogPost } from '../types';
import {
  BookOpen,
  Calendar,
  Clock,
  Heart,
  Share2,
  X,
  Search,
  ArrowRight,
  Sparkles,
  Check,
  Bookmark
} from 'lucide-react';

export const BlogSection: React.FC = () => {
  const {
    blogPosts,
    activeBlogModal,
    openBlogModal,
    closeBlogModal,
    likeBlogPost,
    language,
    t
  } = useApp();

  const [selectedCategory, setSelectedCategory] = useState<string>('All');
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [copied, setCopied] = useState(false);

  const categories = ['All', 'Architecture', 'UI/UX', 'Engineering', 'Career'];

  const filteredPosts = blogPosts.filter((post) => {
    const catMatch = selectedCategory === 'All' || post.category === selectedCategory;
    const searchMatch =
      !searchQuery ||
      post.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      post.excerpt.toLowerCase().includes(searchQuery.toLowerCase()) ||
      post.tags.some((tag) => tag.toLowerCase().includes(searchQuery.toLowerCase()));
    return catMatch && searchMatch;
  });

  const handleShare = () => {
    navigator.clipboard.writeText(window.location.href);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <section id="blog" className="py-24 relative bg-neutral-100/30 dark:bg-neutral-900/20">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Header */}
        <div className="text-center max-w-3xl mx-auto mb-14 space-y-3">
          <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-indigo-500/10 border border-indigo-500/30 text-indigo-600 dark:text-indigo-400 text-xs font-semibold font-mono">
            <BookOpen className="w-3.5 h-3.5" />
            <span>{t('Writings & Articles', 'ব্লগ ও প্রযুক্তিগত প্রবন্ধ')}</span>
          </div>
          <h2 className="text-3xl sm:text-5xl font-extrabold text-neutral-950 dark:text-white tracking-tight">
            {t('Insights on Code, Design & Systems', 'সফটওয়্যার ও আর্কিটেকচার ব্লগ')}
          </h2>
          <p className="text-neutral-600 dark:text-neutral-400 text-base sm:text-lg">
            {t(
              'Deep explorations of frontend performance, UI craft, scalable system design, and engineering habits.',
              'আধুনিক ওয়েব ডেভেলপমেন্ট, ইউআই ইঞ্জিনিয়ারিং এবং প্রফেশনাল ক্যারিয়ার সম্পর্কিত চিন্তাভাবনা।'
            )}
          </p>
        </div>

        {/* Filter & Search */}
        <div className="flex flex-col md:flex-row items-center justify-between gap-4 mb-10">
          <div className="flex items-center gap-1.5 overflow-x-auto w-full md:w-auto pb-2 md:pb-0 scrollbar-none">
            {categories.map((cat) => (
              <button
                key={cat}
                onClick={() => setSelectedCategory(cat)}
                className={`px-3.5 py-2 rounded-2xl text-xs font-semibold transition-all whitespace-nowrap ${
                  selectedCategory === cat
                    ? 'bg-neutral-950 text-white dark:bg-white dark:text-neutral-950 shadow-md'
                    : 'bg-white dark:bg-neutral-900 text-neutral-600 dark:text-neutral-400 hover:text-neutral-950 dark:hover:text-white border border-neutral-200 dark:border-neutral-800'
                }`}
              >
                {cat}
              </button>
            ))}
          </div>

          <div className="relative w-full md:w-64">
            <Search className="w-4 h-4 text-neutral-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              placeholder={t('Search articles...', 'প্রবন্ধ খুঁজুন...')}
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full pl-10 pr-4 py-2 rounded-2xl bg-white dark:bg-neutral-900 border border-neutral-200 dark:border-neutral-800 text-xs text-neutral-900 dark:text-white placeholder-neutral-400 focus:outline-none focus:ring-2 focus:ring-emerald-500/50"
            />
          </div>
        </div>

        {/* Blog Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-7">
          {filteredPosts.map((post) => (
            <div
              key={post.id}
              onClick={() => openBlogModal(post)}
              className="group rounded-3xl bg-white dark:bg-neutral-900/90 border border-neutral-200/80 dark:border-neutral-800 hover:border-emerald-500/50 dark:hover:border-emerald-500/40 shadow-sm hover:shadow-xl transition-all duration-300 overflow-hidden flex flex-col justify-between cursor-pointer"
            >
              {/* Cover Image */}
              <div className="relative h-48 overflow-hidden bg-neutral-950">
                <img
                  src={post.coverImage}
                  alt={post.title}
                  className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-neutral-950/80 via-transparent to-transparent" />
                <div className="absolute top-3 left-3">
                  <span className="px-3 py-1 rounded-full text-[11px] font-mono font-bold bg-neutral-950/80 text-white backdrop-blur-md border border-white/20">
                    {post.category}
                  </span>
                </div>
              </div>

              {/* Card Body */}
              <div className="p-6 flex-1 flex flex-col justify-between space-y-4">
                <div className="space-y-2">
                  <div className="flex items-center gap-3 text-[11px] font-mono text-neutral-400">
                    <span className="flex items-center gap-1">
                      <Calendar className="w-3 h-3" />
                      {post.date}
                    </span>
                    <span>•</span>
                    <span className="flex items-center gap-1">
                      <Clock className="w-3 h-3" />
                      {post.readTime}
                    </span>
                  </div>

                  <h3 className="text-lg font-bold text-neutral-950 dark:text-white group-hover:text-emerald-600 dark:group-hover:text-emerald-400 transition-colors">
                    {language === 'bn' ? post.titleBn || post.title : post.title}
                  </h3>

                  <p className="text-xs text-neutral-600 dark:text-neutral-400 line-clamp-2 leading-relaxed">
                    {language === 'bn' ? post.excerptBn || post.excerpt : post.excerpt}
                  </p>
                </div>

                <div className="pt-4 border-t border-neutral-100 dark:border-neutral-800 flex items-center justify-between">
                  <span className="text-xs font-bold text-emerald-600 dark:text-emerald-400 flex items-center gap-1 group-hover:translate-x-1 transition-transform">
                    {t('Read Full Article', 'পুরো লেখা পড়ুন')}
                    <ArrowRight className="w-3.5 h-3.5" />
                  </span>

                  <button
                    onClick={(e) => {
                      e.stopPropagation();
                      likeBlogPost(post.id);
                    }}
                    className="flex items-center gap-1.5 text-xs text-neutral-500 hover:text-rose-500 transition-colors"
                  >
                    <Heart className="w-4 h-4 text-rose-500 fill-rose-500/20 hover:fill-rose-500" />
                    <span>{post.likes}</span>
                  </button>
                </div>
              </div>
            </div>
          ))}
        </div>

      </div>

      {/* Blog Article Reader Modal */}
      {activeBlogModal && (
        <div
          className="fixed inset-0 z-50 overflow-y-auto bg-neutral-950/80 backdrop-blur-md flex items-center justify-center p-4 sm:p-6 md:p-10 animate-in fade-in duration-200"
          onClick={(e) => {
            if (e.target === e.currentTarget) closeBlogModal();
          }}
        >
          <div className="relative w-full max-w-3xl bg-white dark:bg-neutral-900 border border-neutral-200 dark:border-neutral-800 rounded-[2rem] shadow-2xl overflow-hidden max-h-[90vh] flex flex-col">
            
            {/* Modal Top Bar */}
            <div className="flex items-center justify-between px-6 py-4 border-b border-neutral-200 dark:border-neutral-800 sticky top-0 bg-white/95 dark:bg-neutral-900/95 backdrop-blur-md z-20">
              <div className="flex items-center gap-2">
                <span className="px-3 py-1 rounded-full text-xs font-mono font-bold bg-indigo-500/10 text-indigo-600 dark:text-indigo-400">
                  {activeBlogModal.category}
                </span>
                <span className="text-xs font-mono text-neutral-400">
                  {activeBlogModal.readTime}
                </span>
              </div>

              <div className="flex items-center gap-2">
                <button
                  onClick={handleShare}
                  className="p-2 rounded-full hover:bg-neutral-100 dark:hover:bg-neutral-800 text-neutral-500"
                  title="Share"
                >
                  {copied ? <Check className="w-4 h-4 text-emerald-500" /> : <Share2 className="w-4 h-4" />}
                </button>
                <button
                  onClick={closeBlogModal}
                  className="p-2 rounded-full hover:bg-neutral-100 dark:hover:bg-neutral-800 text-neutral-500"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>
            </div>

            {/* Scrollable Article Body */}
            <div className="overflow-y-auto p-6 sm:p-8 space-y-6">
              <div className="relative h-64 rounded-3xl overflow-hidden">
                <img
                  src={activeBlogModal.coverImage}
                  alt={activeBlogModal.title}
                  className="w-full h-full object-cover"
                />
              </div>

              <div className="space-y-2">
                <div className="flex items-center gap-3 text-xs font-mono text-neutral-400">
                  <span>{activeBlogModal.date}</span>
                  <span>•</span>
                  <span>by Md Jaber Hosain</span>
                </div>

                <h1 className="text-2xl sm:text-4xl font-extrabold text-neutral-950 dark:text-white tracking-tight">
                  {language === 'bn' ? activeBlogModal.titleBn || activeBlogModal.title : activeBlogModal.title}
                </h1>
              </div>

              <div className="prose dark:prose-invert max-w-none text-sm sm:text-base leading-relaxed text-neutral-800 dark:text-neutral-200 whitespace-pre-line border-t border-neutral-100 dark:border-neutral-800 pt-6">
                {activeBlogModal.content}
              </div>

              {/* Tags & Action Bar */}
              <div className="flex flex-wrap items-center justify-between gap-4 pt-6 border-t border-neutral-100 dark:border-neutral-800">
                <div className="flex flex-wrap gap-2">
                  {activeBlogModal.tags.map((tag, tIdx) => (
                    <span
                      key={tIdx}
                      className="text-xs font-mono px-3 py-1 rounded-xl bg-neutral-100 dark:bg-neutral-800 text-neutral-700 dark:text-neutral-300"
                    >
                      #{tag}
                    </span>
                  ))}
                </div>

                <button
                  onClick={() => likeBlogPost(activeBlogModal.id)}
                  className="px-4 py-2 rounded-2xl bg-rose-500/10 text-rose-600 dark:text-rose-400 border border-rose-500/20 font-bold text-xs flex items-center gap-2 hover:bg-rose-500 hover:text-white transition-all"
                >
                  <Heart className="w-4 h-4 fill-current" />
                  <span>{t('Applaud / Like', 'লাইক দিন')} ({activeBlogModal.likes})</span>
                </button>
              </div>
            </div>

          </div>
        </div>
      )}
    </section>
  );
};
