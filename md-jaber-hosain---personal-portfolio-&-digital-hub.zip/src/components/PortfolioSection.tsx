import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { Project } from '../types';
import {
  Briefcase,
  ExternalLink,
  Github,
  Sparkles,
  ArrowRight,
  Search,
  Filter,
  Layers
} from 'lucide-react';

export const PortfolioSection: React.FC = () => {
  const { projects, openProjectModal, language, t } = useApp();
  const [selectedCategory, setSelectedCategory] = useState<string>('All Projects');
  const [searchQuery, setSearchQuery] = useState<string>('');

  const categories = [
    { id: 'All Projects', label: 'All Projects', labelBn: 'সকল প্রজেক্ট' },
    { id: 'Featured Projects', label: 'Featured', labelBn: 'সেরা প্রজেক্ট' },
    { id: 'Web Development', label: 'Web Dev', labelBn: 'ওয়েব ডেভেলপমেন্ট' },
    { id: 'UI/UX Design', label: 'UI/UX Design', labelBn: 'ইউআই/ইউএক্স ডিজাইন' },
    { id: 'Client Projects', label: 'Client Work', labelBn: 'ক্লায়েন্ট প্রজেক্ট' },
    { id: 'Open Source', label: 'Open Source', labelBn: 'ওপেন সোর্স' },
    { id: 'Experimental Projects', label: 'Experiments', labelBn: 'এক্সপেরিমেন্টাল' }
  ];

  // Filtering Logic
  const filteredProjects = projects.filter((project) => {
    // Category match
    const categoryMatches =
      selectedCategory === 'All Projects' ||
      (selectedCategory === 'Featured Projects' && project.featured) ||
      project.category === selectedCategory;

    // Search query match
    const searchLower = searchQuery.toLowerCase();
    const searchMatches =
      !searchQuery ||
      project.title.toLowerCase().includes(searchLower) ||
      (project.titleBn && project.titleBn.toLowerCase().includes(searchLower)) ||
      project.shortDesc.toLowerCase().includes(searchLower) ||
      project.tags.some((tag) => tag.toLowerCase().includes(searchLower));

    return categoryMatches && searchMatches;
  });

  return (
    <section id="portfolio" className="py-24 relative">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Header */}
        <div className="text-center max-w-3xl mx-auto mb-14 space-y-3">
          <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-emerald-500/10 border border-emerald-500/30 text-emerald-600 dark:text-emerald-400 text-xs font-semibold font-mono">
            <Briefcase className="w-3.5 h-3.5" />
            <span>{t('Selected Works', 'কাজের পোর্টফোলিও')}</span>
          </div>
          <h2 className="text-3xl sm:text-5xl font-extrabold text-neutral-950 dark:text-white tracking-tight">
            {t('Crafted With Precision & Purpose', 'বাস্তবায়িত প্রজেক্ট ও কেস স্টাডি')}
          </h2>
          <p className="text-neutral-600 dark:text-neutral-400 text-base sm:text-lg">
            {t(
              'A curated collection of full-stack platforms, design systems, and client deployments.',
              'বাস্তব সমস্যা সমাধান ও ব্যবসায়িক সাফল্য এনে দেওয়া উল্লেখযোগ্য প্রজেক্ট।'
            )}
          </p>
        </div>

        {/* Filter Toolbar & Search Bar */}
        <div className="flex flex-col md:flex-row items-center justify-between gap-4 mb-10">
          
          {/* Category Pills */}
          <div className="flex items-center gap-1.5 overflow-x-auto w-full md:w-auto pb-2 md:pb-0 scrollbar-none">
            {categories.map((cat) => (
              <button
                key={cat.id}
                id={`filter-tab-${cat.id.replace(/\s+/g, '-').toLowerCase()}`}
                onClick={() => setSelectedCategory(cat.id)}
                className={`px-3.5 py-2 rounded-2xl text-xs font-semibold transition-all whitespace-nowrap ${
                  selectedCategory === cat.id
                    ? 'bg-neutral-950 text-white dark:bg-white dark:text-neutral-950 shadow-md'
                    : 'bg-neutral-100 dark:bg-neutral-900 text-neutral-600 dark:text-neutral-400 hover:text-neutral-950 dark:hover:text-white border border-neutral-200/60 dark:border-neutral-800'
                }`}
              >
                {language === 'bn' ? cat.labelBn : cat.label}
              </button>
            ))}
          </div>

          {/* Search Field */}
          <div className="relative w-full md:w-64">
            <Search className="w-4 h-4 text-neutral-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
            <input
              id="portfolio-search-input"
              type="text"
              placeholder={t('Search projects or tech...', 'প্রজেক্ট খুঁজুন...')}
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full pl-10 pr-4 py-2 rounded-2xl bg-neutral-100/70 dark:bg-neutral-900/70 border border-neutral-200 dark:border-neutral-800 text-xs text-neutral-900 dark:text-white placeholder-neutral-400 focus:outline-none focus:ring-2 focus:ring-emerald-500/50"
            />
          </div>
        </div>

        {/* Project Cards Grid */}
        {filteredProjects.length === 0 ? (
          <div className="text-center py-16 bg-neutral-100/50 dark:bg-neutral-900/40 rounded-3xl border border-neutral-200 dark:border-neutral-800 space-y-3">
            <Layers className="w-10 h-10 text-neutral-400 mx-auto" />
            <div className="text-base font-bold text-neutral-800 dark:text-neutral-200">
              {t('No projects found', 'কোনো প্রজেক্ট পাওয়া যায়নি')}
            </div>
            <p className="text-xs text-neutral-500 max-w-sm mx-auto">
              {t('Try clearing the search query or selecting a different category filter.', 'অন্য ক্যাটাগরি বেছে নিন অথবা সার্চ ক্লিয়ার করুন।')}
            </p>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-7">
            {filteredProjects.map((project) => (
              <div
                key={project.id}
                id={`project-card-${project.id}`}
                className="group relative rounded-3xl bg-white dark:bg-neutral-900/80 border border-neutral-200/80 dark:border-neutral-800 overflow-hidden hover:border-emerald-500/50 dark:hover:border-emerald-500/40 transition-all duration-300 shadow-sm hover:shadow-xl flex flex-col justify-between"
              >
                {/* Project Image Header */}
                <div className="relative h-52 overflow-hidden bg-neutral-950">
                  <img
                    src={project.image}
                    alt={project.title}
                    className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-neutral-950/80 via-neutral-950/20 to-transparent" />

                  {/* Top Badges */}
                  <div className="absolute top-3.5 left-3.5 right-3.5 flex items-center justify-between">
                    <span className="px-3 py-1 rounded-full text-[11px] font-mono font-bold bg-neutral-950/80 text-white backdrop-blur-md border border-white/20">
                      {project.category}
                    </span>
                    {project.featured && (
                      <span className="px-2.5 py-1 rounded-full text-[10px] font-bold bg-emerald-500 text-neutral-950 flex items-center gap-1 shadow-sm">
                        <Sparkles className="w-3 h-3" />
                        <span>Featured</span>
                      </span>
                    )}
                  </div>

                  <div className="absolute bottom-3 right-3 text-[11px] font-mono text-neutral-300 bg-neutral-900/80 px-2 py-0.5 rounded-md backdrop-blur-sm">
                    {project.year}
                  </div>
                </div>

                {/* Card Body */}
                <div className="p-6 flex-1 flex flex-col justify-between space-y-4">
                  <div className="space-y-2">
                    <h3 className="text-lg font-bold text-neutral-950 dark:text-white group-hover:text-emerald-600 dark:group-hover:text-emerald-400 transition-colors">
                      {language === 'bn' ? project.titleBn || project.title : project.title}
                    </h3>
                    <p className="text-xs text-neutral-600 dark:text-neutral-400 line-clamp-2 leading-relaxed">
                      {language === 'bn' ? project.shortDescBn || project.shortDesc : project.shortDesc}
                    </p>
                  </div>

                  {/* Technology Tags */}
                  <div className="flex flex-wrap gap-1.5 pt-1">
                    {project.tags.slice(0, 4).map((tag, tIdx) => (
                      <span
                        key={tIdx}
                        className="text-[10px] font-mono px-2 py-0.5 rounded-lg bg-neutral-100 dark:bg-neutral-800 text-neutral-700 dark:text-neutral-300"
                      >
                        {tag}
                      </span>
                    ))}
                    {project.tags.length > 4 && (
                      <span className="text-[10px] font-mono px-1.5 py-0.5 rounded-lg bg-neutral-100 dark:bg-neutral-800 text-neutral-400">
                        +{project.tags.length - 4}
                      </span>
                    )}
                  </div>

                  {/* Card Actions */}
                  <div className="pt-4 border-t border-neutral-100 dark:border-neutral-800 flex items-center justify-between">
                    <button
                      id={`view-case-study-${project.id}`}
                      onClick={() => openProjectModal(project)}
                      className="text-xs font-bold text-emerald-600 dark:text-emerald-400 hover:text-emerald-500 flex items-center gap-1.5 group/btn"
                    >
                      <span>{t('View Case Study', 'কেস স্টাডি দেখুন')}</span>
                      <ArrowRight className="w-3.5 h-3.5 group-hover/btn:translate-x-1 transition-transform" />
                    </button>

                    <div className="flex items-center gap-1">
                      {project.liveUrl && (
                        <a
                          href={project.liveUrl}
                          target="_blank"
                          rel="noreferrer"
                          title="Live Demo"
                          className="p-2 rounded-xl text-neutral-400 hover:text-neutral-900 dark:hover:text-white hover:bg-neutral-100 dark:hover:bg-neutral-800 transition-colors"
                        >
                          <ExternalLink className="w-3.5 h-3.5" />
                        </a>
                      )}
                      {project.githubUrl && (
                        <a
                          href={project.githubUrl}
                          target="_blank"
                          rel="noreferrer"
                          title="GitHub Source"
                          className="p-2 rounded-xl text-neutral-400 hover:text-neutral-900 dark:hover:text-white hover:bg-neutral-100 dark:hover:bg-neutral-800 transition-colors"
                        >
                          <Github className="w-3.5 h-3.5" />
                        </a>
                      )}
                    </div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}

      </div>
    </section>
  );
};
