import React, { useState, useEffect } from 'react';
import { useApp } from '../context/AppContext';
import { PROFILE_INFO } from '../data/initialData';
import {
  Sparkles,
  Command,
  Sun,
  Moon,
  Laptop,
  Languages,
  Music2,
  VolumeX,
  CreditCard,
  User,
  ShieldCheck,
  Menu,
  X,
  ArrowUpRight
} from 'lucide-react';

interface NavbarProps {
  activeTab: string;
  setActiveTab: (tab: string) => void;
}

export const Navbar: React.FC<NavbarProps> = ({ activeTab, setActiveTab }) => {
  const {
    language,
    setLanguage,
    theme,
    setTheme,
    resolvedTheme,
    auth,
    setAuthModalOpen,
    setAdminDrawerOpen,
    setCommandPaletteOpen,
    setDigitalCardOpen,
    isPlayingAmbient,
    toggleAmbientAudio,
    customAvatar,
    t
  } = useApp();

  const [isScrolled, setIsScrolled] = useState(false);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [themeDropdownOpen, setThemeDropdownOpen] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 20);
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const navItems = [
    { id: 'home', label: 'Home', labelBn: 'হোম' },
    { id: 'about', label: 'About', labelBn: 'পরিচিতি' },
    { id: 'portfolio', label: 'Portfolio', labelBn: 'পোর্টফোলিও' },
    { id: 'skills', label: 'Skills', labelBn: 'দক্ষতা' },
    { id: 'experience', label: 'Journey', labelBn: 'অভিজ্ঞতা' },
    { id: 'services', label: 'Services', labelBn: 'সেবা' },
    { id: 'now', label: 'Now', labelBn: 'এখন' },
    { id: 'garden', label: 'Garden', labelBn: 'নলেজ হাব' },
    { id: 'blog', label: 'Blog', labelBn: 'ব্লগ' },
    { id: 'advice', label: 'Advice', labelBn: 'পরামর্শ দিন', highlight: true },
    { id: 'contact', label: 'Contact', labelBn: 'যোগাযোগ' }
  ];

  const handleNavClick = (id: string) => {
    setActiveTab(id);
    setMobileMenuOpen(false);
    const element = document.getElementById(id);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <header
      id="main-navbar"
      className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${
        isScrolled
          ? 'py-3 bg-neutral-950/80 dark:bg-neutral-950/85 bg-white/85 backdrop-blur-xl border-b border-neutral-200/20 dark:border-neutral-800/80 shadow-lg shadow-black/5'
          : 'py-5 bg-transparent'
      }`}
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex items-center justify-between">
        {/* Brand / Logo */}
        <button
          id="navbar-brand-button"
          onClick={() => handleNavClick('home')}
          className="flex items-center gap-3 group text-left focus:outline-none"
        >
          <div className="relative w-10 h-10 rounded-xl overflow-hidden ring-2 ring-emerald-500/30 group-hover:ring-emerald-500 transition-all duration-300">
            <img
              src={customAvatar || PROFILE_INFO.avatar}
              alt={PROFILE_INFO.name}
              className="w-full h-full object-cover object-top"
              onError={(e) => {
                // Fallback to placeholder if not found
                (e.target as HTMLImageElement).src = 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=200&q=80';
              }}
            />
            <div className="absolute inset-0 bg-emerald-500/10 group-hover:bg-transparent transition-colors" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <span className="font-heading font-extrabold text-lg tracking-tight text-neutral-900 dark:text-white group-hover:text-emerald-500 dark:group-hover:text-emerald-400 transition-colors">
                {language === 'bn' ? PROFILE_INFO.nameBn : PROFILE_INFO.name}
              </span>
              <span className="w-2 h-2 rounded-full bg-emerald-500 animate-ping inline-block" />
            </div>
            <span className="text-xs text-neutral-500 dark:text-neutral-400 font-mono block">
              {t('Software Engineer', 'সফটওয়্যার প্রকৌশলী')}
            </span>
          </div>
        </button>

        {/* Desktop Nav Links */}
        <nav className="hidden lg:flex items-center gap-1 bg-neutral-100/70 dark:bg-neutral-900/70 p-1.5 rounded-full border border-neutral-200/50 dark:border-neutral-800/80 backdrop-blur-md">
          {navItems.map((item) => (
            <button
              key={item.id}
              id={`nav-link-${item.id}`}
              onClick={() => handleNavClick(item.id)}
              className={`px-3.5 py-1.5 text-xs font-medium rounded-full transition-all duration-200 relative ${
                activeTab === item.id
                  ? 'bg-neutral-900 text-white dark:bg-neutral-100 dark:text-neutral-950 shadow-sm'
                  : item.highlight
                  ? 'text-emerald-600 dark:text-emerald-400 hover:bg-emerald-500/10 font-semibold'
                  : 'text-neutral-600 dark:text-neutral-400 hover:text-neutral-950 dark:hover:text-white hover:bg-neutral-200/50 dark:hover:bg-neutral-800/50'
              }`}
            >
              {language === 'bn' ? item.labelBn : item.label}
              {item.highlight && (
                <span className="inline-block ml-1 w-1.5 h-1.5 rounded-full bg-emerald-500" />
              )}
            </button>
          ))}
        </nav>

        {/* Action Controls */}
        <div className="flex items-center gap-2">
          {/* Ambient Sound Lo-Fi Toggle */}
          <button
            id="ambient-sound-toggle-btn"
            onClick={toggleAmbientAudio}
            title={isPlayingAmbient ? t('Mute ambient flow sound', 'শব্দ বন্ধ করুন') : t('Play ambient focus flow sound', 'ফোকাস সাউন্ড চালু করুন')}
            className={`p-2 rounded-xl border transition-all duration-200 flex items-center justify-center ${
              isPlayingAmbient
                ? 'bg-emerald-500/20 text-emerald-400 border-emerald-500/40 shadow-sm shadow-emerald-500/20'
                : 'text-neutral-500 hover:text-neutral-900 dark:hover:text-white border-neutral-200/60 dark:border-neutral-800 hover:bg-neutral-100 dark:hover:bg-neutral-900'
            }`}
          >
            {isPlayingAmbient ? (
              <div className="flex items-center gap-1">
                <Music2 className="w-4 h-4 text-emerald-400 animate-bounce" />
                <span className="flex gap-0.5 items-end h-3">
                  <span className="w-0.5 h-full bg-emerald-400 animate-pulse" />
                  <span className="w-0.5 h-2 bg-emerald-400 animate-pulse delay-75" />
                  <span className="w-0.5 h-3 bg-emerald-400 animate-pulse delay-150" />
                </span>
              </div>
            ) : (
              <VolumeX className="w-4 h-4" />
            )}
          </button>

          {/* Command Palette Trigger */}
          <button
            id="command-palette-btn"
            onClick={() => setCommandPaletteOpen(true)}
            title={t('Search & Commands (Ctrl+K)', 'সার্চ ও কমান্ড (Ctrl+K)')}
            className="hidden sm:flex items-center gap-2 px-3 py-1.5 rounded-xl border border-neutral-200/80 dark:border-neutral-800 text-xs text-neutral-500 dark:text-neutral-400 hover:text-neutral-900 dark:hover:text-white hover:bg-neutral-100 dark:hover:bg-neutral-900 transition-colors"
          >
            <Command className="w-3.5 h-3.5" />
            <span className="font-mono text-[11px] bg-neutral-200/80 dark:bg-neutral-800 px-1.5 py-0.5 rounded text-neutral-600 dark:text-neutral-300">
              Ctrl K
            </span>
          </button>

          {/* Language Switcher */}
          <button
            id="language-switcher-btn"
            onClick={() => setLanguage(language === 'en' ? 'bn' : 'en')}
            title={t('Switch to Bengali', 'ইংরেজিতে পরিবর্তন করুন')}
            className="flex items-center gap-1 px-2.5 py-1.5 rounded-xl border border-neutral-200/80 dark:border-neutral-800 text-xs font-semibold text-neutral-700 dark:text-neutral-300 hover:bg-neutral-100 dark:hover:bg-neutral-900 transition-colors"
          >
            <Languages className="w-3.5 h-3.5 text-emerald-500" />
            <span>{language === 'en' ? 'বাংলা' : 'ENG'}</span>
          </button>

          {/* Theme Dropdown Toggle */}
          <div className="relative">
            <button
              id="theme-dropdown-btn"
              onClick={() => setThemeDropdownOpen(!themeDropdownOpen)}
              title={t('Switch Theme', 'থিম পরিবর্তন')}
              className="p-2 rounded-xl border border-neutral-200/80 dark:border-neutral-800 text-neutral-700 dark:text-neutral-300 hover:bg-neutral-100 dark:hover:bg-neutral-900 transition-colors"
            >
              {resolvedTheme === 'dark' ? (
                <Moon className="w-4 h-4 text-indigo-400" />
              ) : (
                <Sun className="w-4 h-4 text-amber-500" />
              )}
            </button>

            {themeDropdownOpen && (
              <div className="absolute right-0 mt-2 w-32 bg-white dark:bg-neutral-900 rounded-2xl shadow-xl border border-neutral-200 dark:border-neutral-800 p-1.5 z-50">
                <button
                  id="theme-light-btn"
                  onClick={() => { setTheme('light'); setThemeDropdownOpen(false); }}
                  className={`w-full flex items-center gap-2 px-2.5 py-1.5 rounded-xl text-xs ${
                    theme === 'light' ? 'bg-amber-500/10 text-amber-500 font-semibold' : 'text-neutral-600 dark:text-neutral-400 hover:bg-neutral-100 dark:hover:bg-neutral-800'
                  }`}
                >
                  <Sun className="w-3.5 h-3.5" />
                  <span>Light</span>
                </button>
                <button
                  id="theme-dark-btn"
                  onClick={() => { setTheme('dark'); setThemeDropdownOpen(false); }}
                  className={`w-full flex items-center gap-2 px-2.5 py-1.5 rounded-xl text-xs ${
                    theme === 'dark' ? 'bg-indigo-500/10 text-indigo-400 font-semibold' : 'text-neutral-600 dark:text-neutral-400 hover:bg-neutral-100 dark:hover:bg-neutral-800'
                  }`}
                >
                  <Moon className="w-3.5 h-3.5" />
                  <span>Dark</span>
                </button>
                <button
                  id="theme-system-btn"
                  onClick={() => { setTheme('system'); setThemeDropdownOpen(false); }}
                  className={`w-full flex items-center gap-2 px-2.5 py-1.5 rounded-xl text-xs ${
                    theme === 'system' ? 'bg-emerald-500/10 text-emerald-400 font-semibold' : 'text-neutral-600 dark:text-neutral-400 hover:bg-neutral-100 dark:hover:bg-neutral-800'
                  }`}
                >
                  <Laptop className="w-3.5 h-3.5" />
                  <span>System</span>
                </button>
              </div>
            )}
          </div>

          {/* Digital Business Card Modal Trigger */}
          <button
            id="open-digital-card-btn"
            onClick={() => setDigitalCardOpen(true)}
            title={t('Digital Business Card & vCard', 'ডিজিটাল ভিজিটিং কার্ড')}
            className="hidden md:flex p-2 rounded-xl border border-neutral-200/80 dark:border-neutral-800 text-neutral-700 dark:text-neutral-300 hover:text-emerald-500 dark:hover:text-emerald-400 hover:bg-neutral-100 dark:hover:bg-neutral-900 transition-colors"
          >
            <CreditCard className="w-4 h-4" />
          </button>

          {/* Auth / Admin Trigger */}
          {auth.isLoggedIn ? (
            <button
              id="admin-drawer-open-btn"
              onClick={() => setAdminDrawerOpen(true)}
              className="flex items-center gap-2 pl-2 pr-3 py-1.5 rounded-full bg-emerald-500/10 border border-emerald-500/30 text-emerald-600 dark:text-emerald-400 hover:bg-emerald-500/20 transition-colors"
            >
              {auth.isAdmin ? (
                <ShieldCheck className="w-4 h-4 text-emerald-500" />
              ) : (
                <User className="w-4 h-4 text-emerald-500" />
              )}
              <span className="text-xs font-semibold max-w-[80px] truncate">
                {auth.isAdmin ? 'Admin Hub' : auth.user?.name}
              </span>
            </button>
          ) : (
            <button
              id="login-modal-open-btn"
              onClick={() => setAuthModalOpen(true)}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-neutral-900 dark:bg-white text-white dark:text-neutral-950 text-xs font-semibold hover:opacity-90 transition-opacity shadow-sm"
            >
              <User className="w-3.5 h-3.5" />
              <span>{t('Sign In', 'লগইন')}</span>
            </button>
          )}

          {/* Mobile Menu Hamburger */}
          <button
            id="mobile-menu-hamburger-btn"
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
            className="lg:hidden p-2 rounded-xl border border-neutral-200 dark:border-neutral-800 text-neutral-700 dark:text-neutral-300 hover:bg-neutral-100 dark:hover:bg-neutral-900"
          >
            {mobileMenuOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
          </button>
        </div>
      </div>

      {/* Mobile Drawer Menu */}
      {mobileMenuOpen && (
        <div className="lg:hidden border-b border-neutral-200 dark:border-neutral-800 bg-neutral-950/95 dark:bg-neutral-950/95 backdrop-blur-2xl px-6 py-6 transition-all duration-300">
          <div className="grid grid-cols-2 gap-2 mb-6">
            {navItems.map((item) => (
              <button
                key={item.id}
                id={`mobile-nav-${item.id}`}
                onClick={() => handleNavClick(item.id)}
                className={`flex items-center justify-between px-4 py-2.5 rounded-xl text-sm font-medium text-left ${
                  activeTab === item.id
                    ? 'bg-emerald-500 text-white font-semibold'
                    : 'text-neutral-300 hover:bg-neutral-900 hover:text-white'
                }`}
              >
                <span>{language === 'bn' ? item.labelBn : item.label}</span>
                {item.highlight && <Sparkles className="w-3.5 h-3.5 text-emerald-400" />}
              </button>
            ))}
          </div>

          <div className="flex flex-col gap-3 pt-4 border-t border-neutral-800">
            <button
              onClick={() => { setDigitalCardOpen(true); setMobileMenuOpen(false); }}
              className="flex items-center justify-center gap-2 w-full py-2.5 rounded-xl border border-neutral-800 text-neutral-200 text-sm font-medium hover:bg-neutral-900"
            >
              <CreditCard className="w-4 h-4 text-emerald-400" />
              <span>{t('View Digital Business Card', 'ডিজিটাল কার্ড দেখুন')}</span>
            </button>
            <a
              href={`mailto:${PROFILE_INFO.email}`}
              className="flex items-center justify-center gap-2 w-full py-2.5 rounded-xl bg-emerald-500 text-neutral-950 font-bold text-sm shadow-md shadow-emerald-500/20"
            >
              <span>{t("Let's Collaborate", 'যোগাযোগ করুন')}</span>
              <ArrowUpRight className="w-4 h-4" />
            </a>
          </div>
        </div>
      )}
    </header>
  );
};
