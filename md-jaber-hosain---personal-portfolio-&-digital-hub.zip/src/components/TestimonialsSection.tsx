import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { INITIAL_TESTIMONIALS } from '../data/initialData';
import {
  MessageSquareQuote,
  Star,
  Quote,
  ChevronLeft,
  ChevronRight
} from 'lucide-react';

export const TestimonialsSection: React.FC = () => {
  const { language, t } = useApp();
  const [currentIndex, setCurrentIndex] = useState(0);

  const prev = () => {
    setCurrentIndex((prev) => (prev === 0 ? INITIAL_TESTIMONIALS.length - 1 : prev - 1));
  };

  const next = () => {
    setCurrentIndex((prev) => (prev === INITIAL_TESTIMONIALS.length - 1 ? 0 : prev + 1));
  };

  const current = INITIAL_TESTIMONIALS[currentIndex];

  return (
    <section id="testimonials" className="py-24 relative">
      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Header */}
        <div className="text-center max-w-3xl mx-auto mb-16 space-y-3">
          <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-emerald-500/10 border border-emerald-500/30 text-emerald-600 dark:text-emerald-400 text-xs font-semibold font-mono">
            <MessageSquareQuote className="w-3.5 h-3.5" />
            <span>{t('Client & Colleague Endorsements', 'ক্লায়েন্ট ও সহকর্মীদের মতামত')}</span>
          </div>
          <h2 className="text-3xl sm:text-5xl font-extrabold text-neutral-950 dark:text-white tracking-tight">
            {t('Trusted by Founders & Engineering Leads', 'কাজের অভিজ্ঞতা নিয়ে ক্লায়েন্ট রিভিউ')}
          </h2>
          <p className="text-neutral-600 dark:text-neutral-400 text-base sm:text-lg">
            {t(
              'Real words from individuals and teams I have had the privilege to collaborate with.',
              'যাদের সাথে কাজ করার সৌভাগ্য হয়েছে, তাদের মূল্যবান প্রতিক্রিয়া।'
            )}
          </p>
        </div>

        {/* Testimonials Carousel */}
        <div className="relative">
          <div className="p-8 sm:p-12 rounded-[2.5rem] bg-white dark:bg-neutral-900/90 border border-neutral-200/80 dark:border-neutral-800 shadow-xl relative overflow-hidden">
            
            <div className="absolute top-6 right-8 text-neutral-100 dark:text-neutral-800 pointer-events-none">
              <Quote className="w-24 h-24" />
            </div>

            <div className="relative z-10 space-y-6">
              {/* Star Rating */}
              <div className="flex items-center gap-1">
                {[...Array(current.rating)].map((_, i) => (
                  <Star key={i} className="w-4 h-4 fill-amber-400 text-amber-400" />
                ))}
              </div>

              {/* Quote Content */}
              <p className="text-base sm:text-xl font-medium text-neutral-800 dark:text-neutral-200 leading-relaxed italic">
                “{language === 'bn' && current.contentBn ? current.contentBn : current.content}”
              </p>

              {/* Author Info */}
              <div className="flex items-center gap-4 pt-4 border-t border-neutral-100 dark:border-neutral-800">
                <img
                  src={current.image}
                  alt={current.name}
                  className="w-14 h-14 rounded-2xl object-cover border-2 border-emerald-500/30"
                />
                <div>
                  <div className="font-bold text-base text-neutral-950 dark:text-white">
                    {current.name}
                  </div>
                  <div className="text-xs text-neutral-500 dark:text-neutral-400 font-mono">
                    {current.position} • {current.organization}
                  </div>
                </div>
              </div>
            </div>

          </div>

          {/* Nav Controls */}
          <div className="flex items-center justify-between mt-8">
            <div className="flex items-center gap-2">
              {INITIAL_TESTIMONIALS.map((_, i) => (
                <button
                  key={i}
                  onClick={() => setCurrentIndex(i)}
                  className={`h-2 rounded-full transition-all ${
                    currentIndex === i ? 'w-8 bg-emerald-500' : 'w-2 bg-neutral-300 dark:bg-neutral-700'
                  }`}
                />
              ))}
            </div>

            <div className="flex items-center gap-2">
              <button
                onClick={prev}
                className="p-3 rounded-2xl bg-white dark:bg-neutral-900 border border-neutral-200 dark:border-neutral-800 text-neutral-700 dark:text-neutral-300 hover:bg-neutral-100 dark:hover:bg-neutral-800 transition-colors shadow-sm"
              >
                <ChevronLeft className="w-5 h-5" />
              </button>
              <button
                onClick={next}
                className="p-3 rounded-2xl bg-white dark:bg-neutral-900 border border-neutral-200 dark:border-neutral-800 text-neutral-700 dark:text-neutral-300 hover:bg-neutral-100 dark:hover:bg-neutral-800 transition-colors shadow-sm"
              >
                <ChevronRight className="w-5 h-5" />
              </button>
            </div>
          </div>
        </div>

      </div>
    </section>
  );
};
