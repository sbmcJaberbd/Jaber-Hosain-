import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { PROFILE_INFO } from '../data/initialData';
import {
  X,
  Copy,
  Check,
  Download,
  Mail,
  Phone,
  MapPin,
  Globe,
  Sparkles
} from 'lucide-react';

export const BusinessCardModal: React.FC = () => {
  const { isDigitalCardOpen, setDigitalCardOpen, language, t } = useApp();
  const [copied, setCopied] = useState(false);

  if (!isDigitalCardOpen) return null;

  const handleCopyEmail = () => {
    navigator.clipboard.writeText(PROFILE_INFO.email);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleDownloadVCard = () => {
    const vCardData = `BEGIN:VCARD
VERSION:3.0
FN:${PROFILE_INFO.name}
TITLE:${PROFILE_INFO.title}
EMAIL:${PROFILE_INFO.email}
TEL:${PROFILE_INFO.phone}
ADR:;;${PROFILE_INFO.location};;;;
URL:${PROFILE_INFO.socialLinks.github}
END:VCARD`;

    const blob = new Blob([vCardData], { type: 'text/vcard' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `${PROFILE_INFO.name.replace(/\s+/g, '_')}.vcf`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
  };

  return (
    <div
      className="fixed inset-0 z-50 overflow-y-auto bg-neutral-950/80 backdrop-blur-md flex items-center justify-center p-4 animate-in fade-in duration-200"
      onClick={(e) => {
        if (e.target === e.currentTarget) setDigitalCardOpen(false);
      }}
    >
      <div className="relative w-full max-w-md bg-white dark:bg-neutral-900 border border-neutral-200 dark:border-neutral-800 rounded-[2.5rem] shadow-2xl p-6 sm:p-8 space-y-6">
        
        {/* Header Bar */}
        <div className="flex items-center justify-between">
          <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-emerald-500/10 text-emerald-600 dark:text-emerald-400 border border-emerald-500/20 text-xs font-mono font-bold">
            <Sparkles className="w-3.5 h-3.5" />
            <span>{t('Digital Business Card', 'ডিজিটাল বিজনেস কার্ড')}</span>
          </div>

          <button
            onClick={() => setDigitalCardOpen(false)}
            className="p-2 rounded-full text-neutral-400 hover:text-neutral-900 dark:hover:text-white"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* The Card Itself (Luxury Metallic Design) */}
        <div className="p-6 sm:p-7 rounded-3xl bg-gradient-to-br from-neutral-900 via-neutral-950 to-neutral-900 border border-emerald-500/30 text-white shadow-2xl space-y-6 relative overflow-hidden">
          <div className="absolute top-0 right-0 w-32 h-32 bg-emerald-500/10 rounded-full blur-2xl pointer-events-none" />

          {/* Card Top: Avatar & Name */}
          <div className="flex items-center gap-4 relative z-10">
            <img
              src={PROFILE_INFO.avatar}
              alt={PROFILE_INFO.name}
              className="w-16 h-16 rounded-2xl object-cover border-2 border-emerald-400/40 shadow-md"
            />
            <div>
              <h3 className="text-lg font-extrabold text-white">
                {language === 'bn' ? PROFILE_INFO.nameBn : PROFILE_INFO.name}
              </h3>
              <p className="text-xs text-emerald-400 font-mono">
                {language === 'bn' ? PROFILE_INFO.titleBn : PROFILE_INFO.title}
              </p>
              <div className="text-[11px] text-neutral-400 flex items-center gap-1 mt-0.5">
                <MapPin className="w-3 h-3 text-rose-400" />
                <span>{PROFILE_INFO.location}</span>
              </div>
            </div>
          </div>

          {/* Contact Details on Card */}
          <div className="space-y-2 pt-2 border-t border-neutral-800 relative z-10 text-xs font-mono text-neutral-300">
            <div className="flex items-center gap-2">
              <Mail className="w-3.5 h-3.5 text-emerald-400" />
              <span>{PROFILE_INFO.email}</span>
            </div>
            <div className="flex items-center gap-2">
              <Phone className="w-3.5 h-3.5 text-indigo-400" />
              <span>{PROFILE_INFO.phone}</span>
            </div>
            <div className="flex items-center gap-2">
              <Globe className="w-3.5 h-3.5 text-cyan-400" />
              <span>mdjaberhosain.dev</span>
            </div>
          </div>

          {/* Card Bottom QR Graphic & Verification */}
          <div className="pt-2 flex items-center justify-between text-[10px] font-mono text-neutral-400 relative z-10">
            <span className="text-emerald-400 font-bold">VERIFIED IDENTITY</span>
            <span>ID: JH-2026-ENG</span>
          </div>
        </div>

        {/* Action Buttons */}
        <div className="grid grid-cols-2 gap-3">
          <button
            onClick={handleCopyEmail}
            className="py-3 px-4 rounded-2xl bg-neutral-100 dark:bg-neutral-800 text-neutral-900 dark:text-white font-bold text-xs flex items-center justify-center gap-2 hover:bg-neutral-200 dark:hover:bg-neutral-700 transition-colors"
          >
            {copied ? <Check className="w-4 h-4 text-emerald-500" /> : <Copy className="w-4 h-4" />}
            <span>{copied ? t('Copied!', 'কপি হয়েছে!') : t('Copy Email', 'ইমেইল কপি')}</span>
          </button>

          <button
            onClick={handleDownloadVCard}
            className="py-3 px-4 rounded-2xl bg-emerald-500 hover:bg-emerald-400 text-neutral-950 font-bold text-xs flex items-center justify-center gap-2 shadow-md transition-colors"
          >
            <Download className="w-4 h-4" />
            <span>{t('Save Contact (.vcf)', 'কন্টাক্ট সেভ (.vcf)')}</span>
          </button>
        </div>

      </div>
    </div>
  );
};
