import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { VisitorAdvice, AdviceCategory } from '../types';
import {
  MessageSquare,
  Sparkles,
  Send,
  Pin,
  CheckCircle2,
  Filter,
  User,
  ShieldCheck,
  Star,
  Trash2,
  Eye,
  Check
} from 'lucide-react';

export const VisitorAdviceSection: React.FC = () => {
  const {
    visitorAdvices,
    addVisitorAdvice,
    toggleAdviceFeature,
    deleteAdvice,
    auth,
    language,
    t
  } = useApp();

  const [fullName, setFullName] = useState('');
  const [email, setEmail] = useState('');
  const [subject, setSubject] = useState('');
  const [category, setCategory] = useState<AdviceCategory>('Portfolio Improvement');
  const [message, setMessage] = useState('');
  const [isPublicApprovedByVisitor, setIsPublicApprovedByVisitor] = useState(true);
  const [submittedSuccess, setSubmittedSuccess] = useState(false);
  const [selectedFilter, setSelectedFilter] = useState<string>('All');

  const categories: AdviceCategory[] = [
    'Portfolio Improvement',
    'Career Advice',
    'Technology & Code',
    'Life & Motivation',
    'General Suggestion',
    'Other'
  ];

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!fullName.trim() || !message.trim() || !email.trim()) return;

    addVisitorAdvice({
      fullName: fullName.trim(),
      email: email.trim(),
      subject: subject.trim() || 'Valuable Guidance for Jaber',
      category,
      message: message.trim(),
      isPublicApprovedByVisitor
    });

    setFullName('');
    setEmail('');
    setSubject('');
    setMessage('');
    setSubmittedSuccess(true);
    setTimeout(() => setSubmittedSuccess(false), 5000);
  };

  // Filter public advice items (or all items if admin)
  const displayAdvices = visitorAdvices.filter((adv) => {
    if (!auth.isAdmin && !adv.isPublicApprovedByVisitor) return false;
    if (selectedFilter !== 'All' && adv.category !== selectedFilter) return false;
    return true;
  });

  return (
    <section id="advice-wall" className="py-24 relative bg-neutral-100/50 dark:bg-neutral-900/40 border-y border-neutral-200/80 dark:border-neutral-800/80">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-16">
        
        {/* Section 31 Heading */}
        <div className="text-center max-w-3xl mx-auto space-y-3">
          <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-emerald-500/10 border border-emerald-500/30 text-emerald-600 dark:text-emerald-400 text-xs font-semibold font-mono">
            <Sparkles className="w-3.5 h-3.5" />
            <span>{t('Section 31: Wisdom & Community Hub', 'সেকশন ৩১: ভিজিটর পরামর্শ ও উপদেশ হাব')}</span>
          </div>
          <h2 className="text-3xl sm:text-5xl font-extrabold text-neutral-950 dark:text-white tracking-tight">
            {t('Leave Advice, Wisdom or Suggestions for Jaber', 'জাবেরের জন্য আপনার পরামর্শ ও উপদেশ')}
          </h2>
          <p className="text-neutral-600 dark:text-neutral-400 text-base sm:text-lg">
            {t(
              'Whether it’s career guidance, technical book recommendations, life lessons, or constructive portfolio feedback — every piece of wisdom shapes my continuous growth.',
              'ক্যারিয়ার দিকনির্দেশনা, নতুন প্রযুক্তি শেখা, বইয়ের পরামর্শ বা জীবনের অভিজ্ঞতা—আপনার প্রতিটি পরামর্শ আমার জন্য মূল্যবান।'
            )}
          </p>
        </div>

        {/* 2-Column Grid: Left is Form, Right is Community Wall */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-10">
          
          {/* Advice Submission Form (5 Cols) */}
          <div className="lg:col-span-5 p-8 rounded-[2.5rem] bg-white dark:bg-neutral-900 border border-neutral-200/80 dark:border-neutral-800 shadow-xl space-y-6">
            <div className="space-y-1">
              <h3 className="text-xl font-bold text-neutral-950 dark:text-white flex items-center gap-2">
                <MessageSquare className="w-5 h-5 text-emerald-500" />
                <span>{t('Share Your Wisdom', 'পরামর্শ বা উপদেশ লিখুন')}</span>
              </h3>
              <p className="text-xs text-neutral-500">
                {t('Your constructive advice will be reviewed and personally valued.', 'আপনার পরামর্শ সরাসরি জাবেরের নিকট পৌঁছাবে।')}
              </p>
            </div>

            {submittedSuccess && (
              <div className="p-4 rounded-2xl bg-emerald-500/15 border border-emerald-500/30 text-emerald-600 dark:text-emerald-400 text-xs flex items-center gap-2 animate-in fade-in">
                <CheckCircle2 className="w-5 h-5 shrink-0" />
                <span>{t('Thank you wholeheartedly! Your advice has been recorded.', 'আন্তরিক ধন্যবাদ! আপনার পরামর্শটি সংরক্ষিত হয়েছে।')}</span>
              </div>
            )}

            <form onSubmit={handleSubmit} className="space-y-4">
              <div>
                <label className="block text-xs font-bold text-neutral-700 dark:text-neutral-300 mb-1">
                  {t('Your Name *', 'আপনার নাম *')}
                </label>
                <input
                  type="text"
                  required
                  placeholder="e.g. Dr. Shahriar Kabir / Mahira Khan"
                  value={fullName}
                  onChange={(e) => setFullName(e.target.value)}
                  className="w-full px-4 py-2.5 rounded-2xl bg-neutral-50 dark:bg-neutral-950 border border-neutral-200 dark:border-neutral-800 text-xs text-neutral-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-emerald-500/50"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-neutral-700 dark:text-neutral-300 mb-1">
                  {t('Your Email (kept private) *', 'আপনার ইমেইল *')}
                </label>
                <input
                  type="email"
                  required
                  placeholder="name@example.com"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  className="w-full px-4 py-2.5 rounded-2xl bg-neutral-50 dark:bg-neutral-950 border border-neutral-200 dark:border-neutral-800 text-xs text-neutral-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-emerald-500/50"
                />
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-bold text-neutral-700 dark:text-neutral-300 mb-1">
                    {t('Category', 'ক্যাটাগরি')}
                  </label>
                  <select
                    value={category}
                    onChange={(e) => setCategory(e.target.value as AdviceCategory)}
                    className="w-full px-4 py-2.5 rounded-2xl bg-neutral-50 dark:bg-neutral-950 border border-neutral-200 dark:border-neutral-800 text-xs text-neutral-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-emerald-500/50"
                  >
                    {categories.map((c) => (
                      <option key={c} value={c}>
                        {c}
                      </option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-bold text-neutral-700 dark:text-neutral-300 mb-1">
                    {t('Subject', 'বিষয়')}
                  </label>
                  <input
                    type="text"
                    placeholder="e.g. Distributed Systems Path"
                    value={subject}
                    onChange={(e) => setSubject(e.target.value)}
                    className="w-full px-4 py-2.5 rounded-2xl bg-neutral-50 dark:bg-neutral-950 border border-neutral-200 dark:border-neutral-800 text-xs text-neutral-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-emerald-500/50"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-bold text-neutral-700 dark:text-neutral-300 mb-1">
                  {t('Your Advice, Lesson, or Suggestion *', 'আপনার উপদেশ বা পরামর্শ *')}
                </label>
                <textarea
                  required
                  rows={4}
                  placeholder={t(
                    'Share what you think Jaber should learn next, habits to maintain, or thoughts on this portfolio...',
                    'জাবেরের জন্য আপনার মূল্যবান পরামর্শ, কোন বিষয়ে আরো দক্ষতা বাড়ানো উচিত ইত্যাদি লিখুন...'
                  )}
                  value={message}
                  onChange={(e) => setMessage(e.target.value)}
                  className="w-full px-4 py-2.5 rounded-2xl bg-neutral-50 dark:bg-neutral-950 border border-neutral-200 dark:border-neutral-800 text-xs text-neutral-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-emerald-500/50 resize-none"
                />
              </div>

              {/* Privacy Checkbox */}
              <label className="flex items-center gap-2 text-xs text-neutral-600 dark:text-neutral-400 cursor-pointer pt-1">
                <input
                  type="checkbox"
                  checked={isPublicApprovedByVisitor}
                  onChange={(e) => setIsPublicApprovedByVisitor(e.target.checked)}
                  className="rounded border-neutral-300 text-emerald-500 focus:ring-emerald-500"
                />
                <span>{t('Allow this advice to be displayed publicly on this wall', 'এই পরামর্শটি সবার জন্য দৃশ্যমান করতে সম্মতি দিচ্ছি')}</span>
              </label>

              <button
                type="submit"
                id="submit-advice-btn"
                className="w-full py-3.5 px-6 rounded-2xl bg-emerald-500 hover:bg-emerald-400 text-neutral-950 font-bold text-xs flex items-center justify-center gap-2 shadow-md shadow-emerald-500/20 transition-all"
              >
                <Send className="w-4 h-4" />
                <span>{t('Submit Advice for Jaber', 'পরামর্শ পাঠান')}</span>
              </button>
            </form>
          </div>

          {/* Advice Community Board (7 Cols) */}
          <div className="lg:col-span-7 space-y-6">
            
            {/* Filter Tabs */}
            <div className="flex items-center justify-between flex-wrap gap-2">
              <div className="flex items-center gap-1.5 overflow-x-auto pb-2 sm:pb-0">
                <button
                  onClick={() => setSelectedFilter('All')}
                  className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all ${
                    selectedFilter === 'All'
                      ? 'bg-emerald-500 text-neutral-950 shadow-sm'
                      : 'bg-white dark:bg-neutral-900 text-neutral-600 dark:text-neutral-400 hover:bg-neutral-100 dark:hover:bg-neutral-800'
                  }`}
                >
                  {t('All Advice', 'সকল')} ({visitorAdvices.length})
                </button>
                {categories.slice(0, 3).map((cat) => (
                  <button
                    key={cat}
                    onClick={() => setSelectedFilter(cat)}
                    className={`px-3 py-1.5 rounded-xl text-xs font-bold whitespace-nowrap transition-all ${
                      selectedFilter === cat
                        ? 'bg-emerald-500 text-neutral-950 shadow-sm'
                        : 'bg-white dark:bg-neutral-900 text-neutral-600 dark:text-neutral-400 hover:bg-neutral-100 dark:hover:bg-neutral-800'
                    }`}
                  >
                    {cat}
                  </button>
                ))}
              </div>

              {auth.isAdmin && (
                <span className="text-[11px] font-mono text-emerald-500 bg-emerald-500/10 px-2.5 py-1 rounded-full font-bold">
                  ✓ Admin Moderation Mode Active
                </span>
              )}
            </div>

            {/* Advice Cards List */}
            <div className="space-y-4 max-h-[600px] overflow-y-auto pr-1">
              {displayAdvices.length === 0 ? (
                <div className="p-12 text-center rounded-3xl bg-white dark:bg-neutral-900 border border-dashed border-neutral-300 dark:border-neutral-800 text-neutral-400 text-xs space-y-2">
                  <MessageSquare className="w-8 h-8 mx-auto text-neutral-300 dark:text-neutral-700" />
                  <p>{t('No advice items in this category yet. Be the first to share one!', 'এই ক্যাটাগরিতে এখনো কোনো পরামর্শ নেই। প্রথম পরামর্শটি আপনিই দিন!')}</p>
                </div>
              ) : (
                displayAdvices.map((item) => (
                  <div
                    key={item.id}
                    className={`p-6 rounded-3xl bg-white dark:bg-neutral-900 border transition-all ${
                      item.isFeatured
                        ? 'border-amber-500/40 shadow-lg shadow-amber-500/5 bg-amber-500/[0.02]'
                        : 'border-neutral-200/80 dark:border-neutral-800 shadow-sm'
                    } space-y-4`}
                  >
                    {/* Top Row: Author & Category */}
                    <div className="flex items-center justify-between gap-2">
                      <div className="flex items-center gap-3">
                        <div className="w-10 h-10 rounded-2xl bg-emerald-500/10 text-emerald-600 dark:text-emerald-400 flex items-center justify-center font-bold font-heading">
                          {item.fullName.charAt(0)}
                        </div>
                        <div>
                          <div className="font-bold text-sm text-neutral-950 dark:text-white flex items-center gap-1.5">
                            <span>{item.fullName}</span>
                            {item.isFeatured && (
                              <span className="px-2 py-0.5 rounded-md bg-amber-500/20 text-amber-600 dark:text-amber-400 text-[10px] font-mono font-bold flex items-center gap-0.5">
                                <Star className="w-3 h-3 fill-amber-400" />
                                {t('Featured Advice', 'নির্বাচিত')}
                              </span>
                            )}
                          </div>
                          <div className="text-[11px] text-neutral-400 font-mono">
                            {item.createdAt}
                          </div>
                        </div>
                      </div>

                      <span className="px-3 py-1 rounded-full bg-neutral-100 dark:bg-neutral-800 text-neutral-700 dark:text-neutral-300 text-[10px] font-mono font-semibold">
                        {item.category}
                      </span>
                    </div>

                    {/* Subject & Message */}
                    <div className="space-y-1.5">
                      {item.subject && (
                        <h4 className="text-xs font-bold text-neutral-900 dark:text-neutral-100 font-mono">
                          {item.subject}
                        </h4>
                      )}
                      <p className="text-xs sm:text-sm text-neutral-700 dark:text-neutral-300 leading-relaxed">
                        “{item.message}”
                      </p>
                    </div>

                    {/* Jaber's Response Note if available */}
                    {item.replyNote && (
                      <div className="p-4 rounded-2xl bg-emerald-500/10 border border-emerald-500/20 space-y-1">
                        <div className="text-[11px] font-mono font-bold text-emerald-600 dark:text-emerald-400 flex items-center gap-1">
                          <ShieldCheck className="w-3.5 h-3.5" />
                          <span>{t('Md Jaber Hosain’s Note:', 'জাবেরের প্রতিক্রিয়া:')}</span>
                        </div>
                        <p className="text-xs text-neutral-800 dark:text-neutral-200 italic">
                          {item.replyNote}
                        </p>
                      </div>
                    )}

                    {/* Admin Moderation Actions */}
                    {auth.isAdmin && (
                      <div className="pt-2 border-t border-neutral-100 dark:border-neutral-800 flex items-center justify-end gap-2 text-xs">
                        <button
                          onClick={() => toggleAdviceFeature(item.id)}
                          className="px-2.5 py-1 rounded-lg bg-amber-500/10 text-amber-600 dark:text-amber-400 hover:bg-amber-500/20 transition-colors"
                        >
                          {item.isFeatured ? 'Unfeature' : 'Feature on Wall'}
                        </button>
                        <button
                          onClick={() => deleteAdvice(item.id)}
                          className="p-1.5 rounded-lg bg-rose-500/10 text-rose-500 hover:bg-rose-500/20 transition-colors"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    )}
                  </div>
                ))
              )}
            </div>

          </div>

        </div>

      </div>
    </section>
  );
};
