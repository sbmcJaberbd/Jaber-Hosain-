import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { INITIAL_EXPERIENCE, INITIAL_EDUCATION } from '../data/initialData';
import {
  Briefcase,
  GraduationCap,
  Award,
  Calendar,
  MapPin,
  CheckCircle2,
  ExternalLink,
  Sparkles
} from 'lucide-react';

export const ExperienceEducationSection: React.FC = () => {
  const { language, t } = useApp();
  const [activeTab, setActiveTab] = useState<'experience' | 'education'>('experience');

  return (
    <section id="education-experience" className="py-24 relative">
      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Header */}
        <div className="text-center max-w-3xl mx-auto mb-14 space-y-3">
          <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-emerald-500/10 border border-emerald-500/30 text-emerald-600 dark:text-emerald-400 text-xs font-semibold font-mono">
            <GraduationCap className="w-3.5 h-3.5" />
            <span>{t('Credentials & Track Record', 'পেশাগত ও শিক্ষাগত যোগ্যতা')}</span>
          </div>
          <h2 className="text-3xl sm:text-5xl font-extrabold text-neutral-950 dark:text-white tracking-tight">
            {t('Experience & Academic Background', 'কাজের অভিজ্ঞতা ও প্রাতিষ্ঠানিক শিক্ষা')}
          </h2>
          <p className="text-neutral-600 dark:text-neutral-400 text-base sm:text-lg">
            {t(
              'A formal background in Computer Science combined with hands-on software engineering leadership.',
              'কম্পিউটার সায়েন্স অ্যান্ড ইঞ্জিনিয়ারিংয়ের প্রাতিষ্ঠানিক শিক্ষা এবং বাস্তব সফটওয়্যার লিডারশিপ।'
            )}
          </p>
        </div>

        {/* Tab Switcher */}
        <div className="flex justify-center mb-12">
          <div className="inline-flex p-1.5 rounded-2xl bg-neutral-100 dark:bg-neutral-900 border border-neutral-200 dark:border-neutral-800">
            <button
              id="tab-btn-experience"
              onClick={() => setActiveTab('experience')}
              className={`flex items-center gap-2 px-6 py-2.5 rounded-xl text-xs font-bold transition-all ${
                activeTab === 'experience'
                  ? 'bg-white dark:bg-neutral-800 text-neutral-950 dark:text-white shadow-sm'
                  : 'text-neutral-600 dark:text-neutral-400 hover:text-neutral-950 dark:hover:text-white'
              }`}
            >
              <Briefcase className="w-4 h-4 text-emerald-500" />
              <span>{t('Work Experience', 'কাজের অভিজ্ঞতা')}</span>
            </button>

            <button
              id="tab-btn-education"
              onClick={() => setActiveTab('education')}
              className={`flex items-center gap-2 px-6 py-2.5 rounded-xl text-xs font-bold transition-all ${
                activeTab === 'education'
                  ? 'bg-white dark:bg-neutral-800 text-neutral-950 dark:text-white shadow-sm'
                  : 'text-neutral-600 dark:text-neutral-400 hover:text-neutral-950 dark:hover:text-white'
              }`}
            >
              <GraduationCap className="w-4 h-4 text-indigo-500" />
              <span>{t('Academic Journey & Certifications', 'শিক্ষা ও সার্টিফিকেশন')}</span>
            </button>
          </div>
        </div>

        {/* Experience List */}
        {activeTab === 'experience' && (
          <div className="space-y-6 animate-in fade-in duration-200">
            {INITIAL_EXPERIENCE.map((exp) => (
              <div
                key={exp.id}
                className="p-7 rounded-3xl bg-white dark:bg-neutral-900/80 border border-neutral-200/80 dark:border-neutral-800 shadow-sm space-y-4"
              >
                <div className="flex flex-wrap items-start justify-between gap-3">
                  <div className="space-y-1">
                    <h3 className="text-xl font-bold text-neutral-950 dark:text-white">
                      {language === 'bn' ? exp.roleBn || exp.role : exp.role}
                    </h3>
                    <div className="text-sm font-semibold text-emerald-600 dark:text-emerald-400">
                      {language === 'bn' ? exp.companyBn || exp.company : exp.company}
                    </div>
                  </div>

                  <div className="flex flex-wrap items-center gap-2 text-xs font-mono text-neutral-500 dark:text-neutral-400">
                    <span className="flex items-center gap-1 bg-neutral-100 dark:bg-neutral-800 px-3 py-1 rounded-xl">
                      <Calendar className="w-3.5 h-3.5 text-emerald-500" />
                      {exp.period}
                    </span>
                    <span className="flex items-center gap-1 bg-neutral-100 dark:bg-neutral-800 px-3 py-1 rounded-xl">
                      <MapPin className="w-3.5 h-3.5 text-rose-500" />
                      {exp.location}
                    </span>
                    <span className="px-2.5 py-1 rounded-xl bg-emerald-500/10 text-emerald-600 dark:text-emerald-400 font-bold">
                      {exp.type}
                    </span>
                  </div>
                </div>

                {/* Responsibilities */}
                <div className="space-y-2 pt-2">
                  <div className="text-xs font-bold uppercase tracking-wider text-neutral-400 font-mono">
                    {t('Key Responsibilities', 'প্রধান দায়িত্বসমূহ')}
                  </div>
                  <ul className="space-y-1.5">
                    {exp.responsibilities.map((resp, rIdx) => (
                      <li key={rIdx} className="flex items-start gap-2.5 text-xs sm:text-sm text-neutral-700 dark:text-neutral-300">
                        <CheckCircle2 className="w-4 h-4 text-emerald-500 shrink-0 mt-0.5" />
                        <span>{resp}</span>
                      </li>
                    ))}
                  </ul>
                </div>

                {/* Achievements */}
                {exp.keyAchievements && exp.keyAchievements.length > 0 && (
                  <div className="p-4 rounded-2xl bg-emerald-500/5 dark:bg-emerald-500/10 border border-emerald-500/20 space-y-1.5">
                    <div className="text-xs font-bold text-emerald-600 dark:text-emerald-400 flex items-center gap-1.5">
                      <Sparkles className="w-3.5 h-3.5" />
                      <span>{t('Key Achievements & Impact', 'উল্লেখযোগ্য সাফল্য ও প্রভাব')}</span>
                    </div>
                    {exp.keyAchievements.map((ach, aIdx) => (
                      <p key={aIdx} className="text-xs text-neutral-700 dark:text-neutral-300">
                        • {ach}
                      </p>
                    ))}
                  </div>
                )}

                {/* Skills Tag */}
                <div className="flex flex-wrap gap-1.5 pt-2">
                  {exp.skills.map((skill, sIdx) => (
                    <span
                      key={sIdx}
                      className="text-[11px] font-mono px-2.5 py-1 rounded-xl bg-neutral-100 dark:bg-neutral-800 text-neutral-700 dark:text-neutral-300"
                    >
                      {skill}
                    </span>
                  ))}
                </div>
              </div>
            ))}
          </div>
        )}

        {/* Education List */}
        {activeTab === 'education' && (
          <div className="space-y-6 animate-in fade-in duration-200">
            {INITIAL_EDUCATION.map((edu) => (
              <div
                key={edu.id}
                className="p-7 rounded-3xl bg-white dark:bg-neutral-900/80 border border-neutral-200/80 dark:border-neutral-800 shadow-sm space-y-4"
              >
                <div className="flex flex-wrap items-start justify-between gap-3">
                  <div className="space-y-1">
                    <h3 className="text-xl font-bold text-neutral-950 dark:text-white">
                      {language === 'bn' ? edu.degreeBn || edu.degree : edu.degree}
                    </h3>
                    <div className="text-sm font-semibold text-indigo-600 dark:text-indigo-400">
                      {language === 'bn' ? edu.institutionBn || edu.institution : edu.institution}
                    </div>
                  </div>

                  <div className="flex items-center gap-1 bg-neutral-100 dark:bg-neutral-800 px-3 py-1 rounded-xl text-xs font-mono text-neutral-500 dark:text-neutral-400">
                    <Calendar className="w-3.5 h-3.5 text-indigo-500" />
                    <span>{edu.period}</span>
                  </div>
                </div>

                <div className="text-xs font-mono text-neutral-500 dark:text-neutral-400">
                  <span className="font-bold text-neutral-700 dark:text-neutral-300">{t('Major:', 'মূল বিষয়:')}</span> {edu.major}
                </div>

                {/* Achievements */}
                <div className="space-y-1.5 pt-1">
                  <div className="text-xs font-bold uppercase tracking-wider text-neutral-400 font-mono">
                    {t('Academic Highlights', 'শিক্ষাজীবনের অর্জন')}
                  </div>
                  <ul className="space-y-1">
                    {edu.achievements.map((ach, aIdx) => (
                      <li key={aIdx} className="flex items-start gap-2 text-xs sm:text-sm text-neutral-700 dark:text-neutral-300">
                        <CheckCircle2 className="w-3.5 h-3.5 text-emerald-500 shrink-0 mt-0.5" />
                        <span>{ach}</span>
                      </li>
                    ))}
                  </ul>
                </div>

                {/* Certificates */}
                {edu.certificates && edu.certificates.length > 0 && (
                  <div className="space-y-2 pt-2">
                    <div className="text-xs font-bold uppercase tracking-wider text-neutral-400 font-mono">
                      {t('Verified Certificates', 'যাচাইকৃত সার্টিফিকেট')}
                    </div>
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                      {edu.certificates.map((cert, cIdx) => (
                        <div
                          key={cIdx}
                          className="p-3 rounded-2xl bg-neutral-50 dark:bg-neutral-950 border border-neutral-200/70 dark:border-neutral-800 flex items-center justify-between"
                        >
                          <div>
                            <div className="text-xs font-bold text-neutral-900 dark:text-white">
                              {cert.title}
                            </div>
                            <div className="text-[11px] text-neutral-500">
                              {cert.issuer} • {cert.date}
                            </div>
                          </div>
                          <Award className="w-4 h-4 text-amber-500 shrink-0" />
                        </div>
                      ))}
                    </div>
                  </div>
                )}
              </div>
            ))}
          </div>
        )}

      </div>
    </section>
  );
};
