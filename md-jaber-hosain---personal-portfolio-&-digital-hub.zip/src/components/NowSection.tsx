import React from 'react';
import { useApp } from '../context/AppContext';
import { INITIAL_NOW_DATA } from '../data/initialData';
import {
  Activity,
  Calendar,
  Sparkles,
  BookOpen,
  CheckCircle2,
  Clock,
  Target,
  Flame,
  Layers,
  FlaskConical
} from 'lucide-react';

export const NowSection: React.FC = () => {
  const { language, t } = useApp();

  return (
    <section id="now" className="py-24 relative bg-neutral-100/40 dark:bg-neutral-900/30">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Header */}
        <div className="text-center max-w-3xl mx-auto mb-16 space-y-3">
          <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-emerald-500/10 border border-emerald-500/30 text-emerald-600 dark:text-emerald-400 text-xs font-semibold font-mono">
            <Activity className="w-3.5 h-3.5 animate-pulse" />
            <span>{t('Living Page • Real-Time Pulse', 'লাইভ পেজ • চলমান কর্মকাণ্ড')}</span>
          </div>
          <h2 className="text-3xl sm:text-5xl font-extrabold text-neutral-950 dark:text-white tracking-tight">
            {t('What I Am Doing Right Now', 'বর্তমানে আমার ব্যস্ততা ও লক্ষ্য')}
          </h2>
          <div className="flex items-center justify-center gap-2 text-xs font-mono text-neutral-500 dark:text-neutral-400">
            <Clock className="w-3.5 h-3.5 text-emerald-500" />
            <span>{t('Last updated:', 'সর্বশেষ আপডেট:')} {INITIAL_NOW_DATA.lastUpdated}</span>
          </div>
        </div>

        {/* Bento Grid Layout */}
        <div className="grid grid-cols-1 md:grid-cols-12 gap-8">
          
          {/* Active Focus & High Priorities (7 cols) */}
          <div className="md:col-span-7 p-8 rounded-3xl bg-white dark:bg-neutral-900/90 border border-neutral-200/80 dark:border-neutral-800 shadow-sm space-y-6">
            <div className="flex items-center gap-2 text-emerald-600 dark:text-emerald-400 font-bold text-lg">
              <Flame className="w-5 h-5" />
              <h3 className="text-neutral-950 dark:text-white">
                {t('Current High-Impact Focus', 'প্রধান ফোকাস ও গবেষণা')}
              </h3>
            </div>

            <div className="space-y-3">
              {(language === 'bn' && INITIAL_NOW_DATA.currentFocusBn ? INITIAL_NOW_DATA.currentFocusBn : INITIAL_NOW_DATA.currentFocus).map((focus, idx) => (
                <div
                  key={idx}
                  className="flex items-start gap-3 p-4 rounded-2xl bg-neutral-50 dark:bg-neutral-950 border border-neutral-200/60 dark:border-neutral-800"
                >
                  <span className="w-6 h-6 rounded-xl bg-emerald-500/15 text-emerald-600 dark:text-emerald-400 font-mono text-xs font-bold flex items-center justify-center shrink-0 mt-0.5">
                    0{idx + 1}
                  </span>
                  <p className="text-xs sm:text-sm text-neutral-800 dark:text-neutral-200 leading-relaxed font-medium">
                    {focus}
                  </p>
                </div>
              ))}
            </div>

            {/* Currently Reading Card */}
            <div className="p-5 rounded-2xl bg-gradient-to-r from-emerald-950/30 to-neutral-900 border border-emerald-500/20 text-white space-y-3">
              <div className="flex items-center justify-between text-xs font-mono text-emerald-400">
                <span className="flex items-center gap-1.5">
                  <BookOpen className="w-4 h-4" />
                  {t('Currently Reading', 'এখন যে বইটি পড়ছি')}
                </span>
                <span>{INITIAL_NOW_DATA.currentlyReading.progress}% Completed</span>
              </div>

              <div>
                <div className="text-sm font-bold text-white">
                  {INITIAL_NOW_DATA.currentlyReading.title}
                </div>
                <div className="text-xs text-neutral-400 font-mono">
                  by {INITIAL_NOW_DATA.currentlyReading.author}
                </div>
              </div>

              <div className="w-full bg-neutral-800 h-1.5 rounded-full overflow-hidden">
                <div
                  className="bg-emerald-400 h-full rounded-full transition-all duration-500"
                  style={{ width: `${INITIAL_NOW_DATA.currentlyReading.progress}%` }}
                />
              </div>
            </div>
          </div>

          {/* 30-Day Goals & Active Experiments (5 cols) */}
          <div className="md:col-span-5 space-y-6">
            
            {/* 30-Day Goals */}
            <div className="p-7 rounded-3xl bg-white dark:bg-neutral-900/90 border border-neutral-200/80 dark:border-neutral-800 shadow-sm space-y-4">
              <div className="flex items-center gap-2 text-indigo-500 font-bold text-base">
                <Target className="w-5 h-5" />
                <h3 className="text-neutral-950 dark:text-white">
                  {t('Next 30-Day Goals', 'পরবর্তী ৩০ দিনের লক্ষ্য')}
                </h3>
              </div>

              <div className="space-y-2.5">
                {(language === 'bn' && INITIAL_NOW_DATA.thirtyDayGoalsBn ? INITIAL_NOW_DATA.thirtyDayGoalsBn : INITIAL_NOW_DATA.thirtyDayGoals).map((goal, gIdx) => (
                  <div key={gIdx} className="flex items-start gap-2 text-xs text-neutral-700 dark:text-neutral-300">
                    <CheckCircle2 className="w-4 h-4 text-emerald-500 shrink-0 mt-0.5" />
                    <span>{goal}</span>
                  </div>
                ))}
              </div>
            </div>

            {/* Active Code Experiments */}
            <div className="p-7 rounded-3xl bg-white dark:bg-neutral-900/90 border border-neutral-200/80 dark:border-neutral-800 shadow-sm space-y-4">
              <div className="flex items-center gap-2 text-amber-500 font-bold text-base">
                <FlaskConical className="w-5 h-5" />
                <h3 className="text-neutral-950 dark:text-white">
                  {t('Active Experiments', 'চলমান ল্যাব এক্সপেরিমেন্ট')}
                </h3>
              </div>

              <div className="space-y-2">
                {INITIAL_NOW_DATA.experiments.map((exp, eIdx) => (
                  <div
                    key={eIdx}
                    className="p-3 rounded-2xl bg-neutral-50 dark:bg-neutral-950 border border-neutral-200/60 dark:border-neutral-800 text-xs text-neutral-700 dark:text-neutral-300 font-mono flex items-center gap-2"
                  >
                    <span className="w-1.5 h-1.5 rounded-full bg-amber-500 animate-ping" />
                    <span>{exp}</span>
                  </div>
                ))}
              </div>
            </div>

          </div>

        </div>

      </div>
    </section>
  );
};
