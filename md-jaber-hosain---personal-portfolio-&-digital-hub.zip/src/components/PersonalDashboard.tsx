import React from 'react';
import { useApp } from '../context/AppContext';
import {
  X,
  Activity,
  Layers,
  MessageSquare,
  Sparkles,
  Volume2,
  VolumeX,
  Sun,
  Moon,
  ShieldCheck,
  CreditCard,
  Mail,
  User,
  ArrowRight,
  TrendingUp,
  CheckCircle2
} from 'lucide-react';

export const PersonalDashboard: React.FC = () => {
  const {
    isAdminDrawerOpen,
    setAdminDrawerOpen,
    projects,
    visitorAdvices,
    guestbook,
    theme,
    setTheme,
    isPlayingAmbient,
    toggleAmbientAudio,
    setDigitalCardOpen,
    setAuthModalOpen,
    auth,
    logout,
    dashboardState,
    togglePersonalGoal,
    language,
    t
  } = useApp();

  if (!isAdminDrawerOpen) return null;

  return (
    <div
      className="fixed inset-0 z-50 overflow-y-auto bg-neutral-950/80 backdrop-blur-md flex items-center justify-center p-4 sm:p-6 animate-in fade-in duration-200"
      onClick={(e) => {
        if (e.target === e.currentTarget) setAdminDrawerOpen(false);
      }}
    >
      <div className="relative w-full max-w-2xl bg-white dark:bg-neutral-900 border border-neutral-200 dark:border-neutral-800 rounded-[2.5rem] shadow-2xl p-6 sm:p-8 space-y-6 max-h-[90vh] overflow-y-auto">
        
        {/* Top Bar */}
        <div className="flex items-center justify-between border-b border-neutral-100 dark:border-neutral-800 pb-4">
          <div className="flex items-center gap-2">
            <div className="p-2 rounded-xl bg-emerald-500/10 text-emerald-500">
              <Activity className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-lg font-bold text-neutral-950 dark:text-white">
                {t('Personal Dashboard & System Status', 'পার্সোনাল ড্যাশবোর্ড ও সিস্টেম স্ট্যাটাস')}
              </h2>
              <p className="text-xs text-neutral-400 font-mono">
                Md Jaber Hosain’s Live Digital HQ
              </p>
            </div>
          </div>

          <button
            onClick={() => setAdminDrawerOpen(false)}
            className="p-2 rounded-full hover:bg-neutral-100 dark:hover:bg-neutral-800 text-neutral-400 hover:text-neutral-900 dark:hover:text-white"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Live Metrics Grid */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
          <div className="p-4 rounded-2xl bg-neutral-50 dark:bg-neutral-950 border border-neutral-200/60 dark:border-neutral-800 text-center">
            <div className="text-2xl font-black text-emerald-500 font-heading">
              {projects.length}
            </div>
            <div className="text-[11px] font-bold text-neutral-700 dark:text-neutral-300">
              {t('Total Projects', 'মোট প্রজেক্ট')}
            </div>
          </div>

          <div className="p-4 rounded-2xl bg-neutral-50 dark:bg-neutral-950 border border-neutral-200/60 dark:border-neutral-800 text-center">
            <div className="text-2xl font-black text-indigo-500 font-heading">
              {visitorAdvices.length}
            </div>
            <div className="text-[11px] font-bold text-neutral-700 dark:text-neutral-300">
              {t('Visitor Advices', 'প্রাপ্ত পরামর্শ')}
            </div>
          </div>

          <div className="p-4 rounded-2xl bg-neutral-50 dark:bg-neutral-950 border border-neutral-200/60 dark:border-neutral-800 text-center">
            <div className="text-2xl font-black text-amber-500 font-heading">
              {guestbook.length}
            </div>
            <div className="text-[11px] font-bold text-neutral-700 dark:text-neutral-300">
              {t('Guestbook Signs', 'গেস্টবুক সাইন')}
            </div>
          </div>

          <div className="p-4 rounded-2xl bg-neutral-50 dark:bg-neutral-950 border border-neutral-200/60 dark:border-neutral-800 text-center">
            <div className="text-2xl font-black text-rose-500 font-heading">
              100%
            </div>
            <div className="text-[11px] font-bold text-neutral-700 dark:text-neutral-300">
              {t('System Health', 'সিস্টেম স্ট্যাটাস')}
            </div>
          </div>
        </div>

        {/* Current Focus & Personal Goals */}
        <div className="p-5 rounded-3xl bg-neutral-50 dark:bg-neutral-950 border border-neutral-200/80 dark:border-neutral-800 space-y-3">
          <div className="flex items-center justify-between">
            <span className="text-xs font-mono font-bold text-emerald-600 dark:text-emerald-400 uppercase tracking-wider">
              {t('Active Focus & Goals', 'বর্তমান লক্ষ্য ও ফোকাস')}
            </span>
            <span className="text-[10px] font-mono text-neutral-400">
              Status: {dashboardState.status}
            </span>
          </div>

          <p className="text-xs font-semibold text-neutral-800 dark:text-neutral-200">
            {dashboardState.currentFocus}
          </p>

          <div className="space-y-2 pt-2 border-t border-neutral-200/50 dark:border-neutral-800">
            {(dashboardState?.personalGoals || []).map((g, i) => (
              <div
                key={i}
                onClick={() => togglePersonalGoal(i)}
                className="flex items-center gap-2 text-xs text-neutral-700 dark:text-neutral-300 cursor-pointer hover:text-emerald-500 transition-colors"
              >
                <CheckCircle2
                  className={`w-4 h-4 ${
                    g.completed ? 'text-emerald-500 fill-emerald-500/20' : 'text-neutral-300 dark:text-neutral-700'
                  }`}
                />
                <span className={g.completed ? 'line-through text-neutral-400' : ''}>{g.goal}</span>
              </div>
            ))}
          </div>
        </div>

        {/* Quick Controls */}
        <div className="space-y-3">
          <div className="text-xs font-bold font-mono text-neutral-400 uppercase tracking-wider">
            {t('Quick Controls & Audio Engine', 'কন্ট্রোল ও সাউন্ড ইঞ্জিন')}
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            {/* Ambient Sound Toggle */}
            <div className="p-4 rounded-2xl bg-neutral-50 dark:bg-neutral-950 border border-neutral-200/60 dark:border-neutral-800 flex items-center justify-between">
              <div className="flex items-center gap-2.5">
                {isPlayingAmbient ? (
                  <Volume2 className="w-5 h-5 text-emerald-500 animate-pulse" />
                ) : (
                  <VolumeX className="w-5 h-5 text-neutral-400" />
                )}
                <div>
                  <div className="text-xs font-bold text-neutral-900 dark:text-white">
                    {t('Ambient Soundscape', 'অ্যাম্বিয়েন্ট সাউন্ড')}
                  </div>
                  <div className="text-[10px] text-neutral-400 font-mono">
                    {isPlayingAmbient ? 'Synthesizer Active' : 'Muted'}
                  </div>
                </div>
              </div>

              <button
                onClick={toggleAmbientAudio}
                className="px-3 py-1.5 rounded-xl bg-neutral-200 dark:bg-neutral-800 text-xs font-bold text-neutral-800 dark:text-white hover:bg-emerald-500 hover:text-neutral-950 transition-colors"
              >
                {isPlayingAmbient ? t('Pause', 'থামান') : t('Play', 'চালান')}
              </button>
            </div>

            {/* Theme Toggle */}
            <div className="p-4 rounded-2xl bg-neutral-50 dark:bg-neutral-950 border border-neutral-200/60 dark:border-neutral-800 flex items-center justify-between">
              <div className="flex items-center gap-2.5">
                {theme === 'dark' ? (
                  <Moon className="w-5 h-5 text-indigo-400" />
                ) : (
                  <Sun className="w-5 h-5 text-amber-500" />
                )}
                <div>
                  <div className="text-xs font-bold text-neutral-900 dark:text-white">
                    {t('Color Theme', 'কালার থিম')}
                  </div>
                  <div className="text-[10px] text-neutral-400 font-mono">
                    {theme.toUpperCase()}
                  </div>
                </div>
              </div>

              <button
                onClick={() => setTheme(theme === 'dark' ? 'light' : 'dark')}
                className="px-3 py-1.5 rounded-xl bg-neutral-200 dark:bg-neutral-800 text-xs font-bold text-neutral-800 dark:text-white hover:bg-neutral-300 dark:hover:bg-neutral-700 transition-colors"
              >
                {t('Switch', 'পরিবর্তন')}
              </button>
            </div>
          </div>
        </div>

        {/* User Session / Admin Access */}
        <div className="p-5 rounded-2xl bg-neutral-100 dark:bg-neutral-950 border border-neutral-200/80 dark:border-neutral-800 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-emerald-500/20 text-emerald-500 flex items-center justify-center font-bold">
              {auth.user ? auth.user.name.charAt(0) : <User className="w-5 h-5 text-neutral-400" />}
            </div>
            <div>
              <div className="text-xs font-bold text-neutral-900 dark:text-white">
                {auth.user ? auth.user.name : t('Guest Mode Active', 'গেস্ট মোড')}
              </div>
              <div className="text-[10px] text-neutral-400 font-mono">
                {auth.user ? `${auth.user.role.toUpperCase()} Account` : t('Sign in for privileged access', 'লগইন করুন')}
              </div>
            </div>
          </div>

          {!auth.isLoggedIn ? (
            <button
              onClick={() => {
                setAdminDrawerOpen(false);
                setAuthModalOpen(true);
              }}
              className="px-4 py-2 rounded-xl bg-emerald-500 text-neutral-950 font-bold text-xs hover:bg-emerald-400 transition-colors"
            >
              {t('Sign In / Register', 'সাইন ইন')}
            </button>
          ) : (
            <button
              onClick={() => {
                logout();
                setAdminDrawerOpen(false);
              }}
              className="px-3 py-1.5 rounded-xl bg-rose-500/10 text-rose-500 hover:bg-rose-500 hover:text-white text-xs font-bold transition-colors"
            >
              {t('Sign Out', 'লগআউট')}
            </button>
          )}
        </div>

      </div>
    </div>
  );
};
