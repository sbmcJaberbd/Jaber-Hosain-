import React from 'react';
import { useApp } from '../context/AppContext';
import {
  Sparkles,
  BookOpen,
  Wrench,
  Heart,
  Quote,
  Coffee,
  Camera,
  Layers,
  Compass,
  Cpu,
  Bookmark
} from 'lucide-react';

export const BeyondWorkSection: React.FC = () => {
  const { t } = useApp();

  const hobbies = [
    { title: 'Tech Reading & Research', icon: <BookOpen className="w-4 h-4 text-emerald-500" />, desc: 'Exploring systems architecture and cognitive science.' },
    { title: 'Typography & Calligraphy', icon: <Layers className="w-4 h-4 text-amber-500" />, desc: 'Studying Arabic and Bengali geometric letterforms.' },
    { title: 'Photography & Nature', icon: <Camera className="w-4 h-4 text-cyan-500" />, desc: 'Capturing serene rural landscapes and golden hour lights in Bangladesh.' },
    { title: 'Specialty Tea & Coffee', icon: <Coffee className="w-4 h-4 text-rose-500" />, desc: 'Fueling deep work sessions with fine artisanal brews.' }
  ];

  const favoriteBooks = [
    { title: 'Designing Data-Intensive Applications', author: 'Martin Kleppmann', tag: 'Architecture' },
    { title: 'Atomic Habits', author: 'James Clear', tag: 'Productivity' },
    { title: 'Refactoring UI', author: 'Adam Wathan & Steve Schoger', tag: 'Design' },
    { title: 'The Pragmatic Programmer', author: 'David Thomas & Andrew Hunt', tag: 'Mindset' }
  ];

  const favoriteTools = [
    { name: 'VS Code & Cursor', category: 'IDE' },
    { name: 'Figma', category: 'UI/UX' },
    { name: 'Ghostty & iTerm2', category: 'Terminal' },
    { name: 'Linear', category: 'Tracking' },
    { name: 'Raycast', category: 'Productivity' },
    { name: 'Docker', category: 'Containers' }
  ];

  return (
    <section id="beyond-work" className="py-20 relative">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Header */}
        <div className="text-center max-w-3xl mx-auto mb-16 space-y-3">
          <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-rose-500/10 border border-rose-500/30 text-rose-600 dark:text-rose-400 text-xs font-semibold font-mono">
            <Heart className="w-3.5 h-3.5" />
            <span>{t('Human Behind The Screen', 'কাজের বাইরে ব্যক্তিগত জগৎ')}</span>
          </div>
          <h2 className="text-3xl sm:text-5xl font-extrabold text-neutral-950 dark:text-white tracking-tight">
            {t('Beyond The Code', 'ব্যক্তিগত আগ্রহ, বই ও প্রিয় অনুষঙ্গ')}
          </h2>
          <p className="text-neutral-600 dark:text-neutral-400 text-base sm:text-lg">
            {t(
              'Passions, inspiring literature, daily tools, and the personal pursuits that shape my mindset.',
              'যেসব শখ, প্রিয় বই এবং চিন্তা আমার মনন ও কর্মশক্তিকে সমৃদ্ধ করে।'
            )}
          </p>
        </div>

        {/* 4-Bento Grid Layout */}
        <div className="grid grid-cols-1 md:grid-cols-12 gap-6">
          
          {/* Card 1: Hobbies & Passions (6 cols) */}
          <div className="md:col-span-6 p-7 rounded-3xl bg-neutral-100/70 dark:bg-neutral-900/60 border border-neutral-200/80 dark:border-neutral-800 backdrop-blur-md flex flex-col justify-between">
            <div>
              <div className="flex items-center gap-2 font-bold text-lg text-neutral-950 dark:text-white mb-4">
                <Compass className="w-5 h-5 text-emerald-500" />
                <span>{t('Hobbies & Activities', 'শখ ও সৃজনশীল ব্যস্ততা')}</span>
              </div>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3.5">
                {hobbies.map((h, i) => (
                  <div key={i} className="p-3.5 rounded-2xl bg-white dark:bg-neutral-950 border border-neutral-200/60 dark:border-neutral-800">
                    <div className="flex items-center gap-2 font-bold text-xs text-neutral-900 dark:text-white mb-1">
                      {h.icon}
                      <span>{h.title}</span>
                    </div>
                    <p className="text-[11px] text-neutral-500 dark:text-neutral-400">
                      {h.desc}
                    </p>
                  </div>
                ))}
              </div>
            </div>
          </div>

          {/* Card 2: Bookshelf (6 cols) */}
          <div className="md:col-span-6 p-7 rounded-3xl bg-neutral-100/70 dark:bg-neutral-900/60 border border-neutral-200/80 dark:border-neutral-800 backdrop-blur-md">
            <div className="flex items-center gap-2 font-bold text-lg text-neutral-950 dark:text-white mb-4">
              <Bookmark className="w-5 h-5 text-amber-500" />
              <span>{t('Influential Bookshelf', 'অনুপ্রেরণাদায়ী বইসমূহ')}</span>
            </div>
            <div className="space-y-2.5">
              {favoriteBooks.map((book, idx) => (
                <div key={idx} className="flex items-center justify-between p-3 rounded-2xl bg-white dark:bg-neutral-950 border border-neutral-200/60 dark:border-neutral-800">
                  <div>
                    <div className="text-xs font-bold text-neutral-900 dark:text-white">
                      {book.title}
                    </div>
                    <div className="text-[11px] text-neutral-500 dark:text-neutral-400">
                      by {book.author}
                    </div>
                  </div>
                  <span className="text-[10px] font-mono px-2 py-0.5 rounded-md bg-amber-500/10 text-amber-600 dark:text-amber-400 border border-amber-500/20">
                    {book.tag}
                  </span>
                </div>
              ))}
            </div>
          </div>

          {/* Card 3: Daily Tools (7 cols) */}
          <div className="md:col-span-7 p-7 rounded-3xl bg-neutral-100/70 dark:bg-neutral-900/60 border border-neutral-200/80 dark:border-neutral-800 backdrop-blur-md">
            <div className="flex items-center gap-2 font-bold text-lg text-neutral-950 dark:text-white mb-3">
              <Wrench className="w-5 h-5 text-cyan-500" />
              <span>{t('Everyday Digital Arsenal', 'প্রতিদিনের প্রিয় টুলস')}</span>
            </div>
            <p className="text-xs text-neutral-500 dark:text-neutral-400 mb-4">
              {t('Hardware and software curated for maximum clarity and velocity.', 'দ্রুত ও স্বাচ্ছন্দ্যে কাজ করার জন্য পছন্দের টুলস।')}
            </p>
            <div className="flex flex-wrap gap-2">
              {favoriteTools.map((tool, i) => (
                <span
                  key={i}
                  className="px-3 py-1.5 rounded-xl bg-white dark:bg-neutral-950 border border-neutral-200/80 dark:border-neutral-800 text-xs font-medium text-neutral-800 dark:text-neutral-200 flex items-center gap-1.5"
                >
                  <Cpu className="w-3.5 h-3.5 text-emerald-500" />
                  <span>{tool.name}</span>
                  <span className="text-[10px] text-neutral-400 font-mono">({tool.category})</span>
                </span>
              ))}
            </div>
          </div>

          {/* Card 4: Daily Quote (5 cols) */}
          <div className="md:col-span-5 p-7 rounded-3xl bg-gradient-to-br from-indigo-950/40 via-neutral-900 to-neutral-950 border border-indigo-500/30 text-white flex flex-col justify-between">
            <div>
              <div className="flex items-center gap-2 font-bold text-xs uppercase tracking-wider text-indigo-400 font-mono mb-2">
                <Quote className="w-4 h-4" />
                <span>{t('Favorite Words of Wisdom', 'প্রিয় উক্তি')}</span>
              </div>
              <p className="text-sm sm:text-base font-medium italic text-neutral-200 leading-relaxed mt-2">
                “Simplicity is prerequisite for reliability. When you build something, build it with patience and deep reverence for the craft.”
              </p>
            </div>
            <div className="pt-4 mt-4 border-t border-neutral-800/80 flex items-center justify-between text-xs text-neutral-400">
              <span>— Edsger W. Dijkstra</span>
              <Sparkles className="w-4 h-4 text-indigo-400" />
            </div>
          </div>

        </div>

      </div>
    </section>
  );
};
