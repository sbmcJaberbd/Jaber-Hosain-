import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { INITIAL_GARDEN_NOTES } from '../data/initialData';
import { GardenNote } from '../types';
import {
  Sprout,
  Search,
  Sparkles,
  BookOpen,
  Calendar,
  Clock,
  ArrowRight,
  X,
  Share2,
  Bookmark,
  Check
} from 'lucide-react';

export const DigitalGardenSection: React.FC = () => {
  const { activeNoteModal, openNoteModal, closeNoteModal, language, t } = useApp();
  const [selectedCategory, setSelectedCategory] = useState<string>('All');
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [copied, setCopied] = useState(false);

  const categories = ['All', 'Tutorials', 'Notes', 'Things I\'ve Learned', 'Ideas', 'Resources'];

  const getStageBadge = (stage: GardenNote['growthStage']) => {
    switch (stage) {
      case 'Evergreen':
        return (
          <span className="px-2.5 py-0.5 rounded-full text-[10px] font-mono font-bold bg-emerald-500/15 text-emerald-600 dark:text-emerald-400 border border-emerald-500/30 flex items-center gap-1">
            <span>🌲</span> Evergreen
          </span>
        );
      case 'Budding':
        return (
          <span className="px-2.5 py-0.5 rounded-full text-[10px] font-mono font-bold bg-amber-500/15 text-amber-600 dark:text-amber-400 border border-amber-500/30 flex items-center gap-1">
            <span>🌿</span> Budding
          </span>
        );
      default:
        return (
          <span className="px-2.5 py-0.5 rounded-full text-[10px] font-mono font-bold bg-cyan-500/15 text-cyan-600 dark:text-cyan-400 border border-cyan-500/30 flex items-center gap-1">
            <span>🌱</span> Sprout
          </span>
        );
    }
  };

  const filteredNotes = INITIAL_GARDEN_NOTES.filter((note) => {
    const catMatch = selectedCategory === 'All' || note.category === selectedCategory;
    const searchMatch =
      !searchQuery ||
      note.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      note.summary.toLowerCase().includes(searchQuery.toLowerCase()) ||
      note.tags.some((tag) => tag.toLowerCase().includes(searchQuery.toLowerCase()));
    return catMatch && searchMatch;
  });

  const handleShare = (note: GardenNote) => {
    navigator.clipboard.writeText(window.location.href);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <section id="garden" className="py-24 relative">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Header */}
        <div className="text-center max-w-3xl mx-auto mb-14 space-y-3">
          <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-emerald-500/10 border border-emerald-500/30 text-emerald-600 dark:text-emerald-400 text-xs font-semibold font-mono">
            <Sprout className="w-3.5 h-3.5" />
            <span>{t('Knowledge Repository', 'ডিজিটাল গার্ডেন ও নলেজ হাব')}</span>
          </div>
          <h2 className="text-3xl sm:text-5xl font-extrabold text-neutral-950 dark:text-white tracking-tight">
            {t('Digital Garden & Technical Notes', 'প্রযুক্তি চিন্তা ও শিক্ষণ নোট')}
          </h2>
          <p className="text-neutral-600 dark:text-neutral-400 text-base sm:text-lg">
            {t(
              'A living collection of technical tutorials, architectural patterns, and evolving thoughts.',
              'নিয়মিত সমৃদ্ধ হওয়া নোট, স্থাপত্য নির্দেশিকা এবং বাস্তব কোডিং অভিজ্ঞতা।'
            )}
          </p>
        </div>

        {/* Filter & Search Bar */}
        <div className="flex flex-col md:flex-row items-center justify-between gap-4 mb-10">
          <div className="flex items-center gap-1.5 overflow-x-auto w-full md:w-auto pb-2 md:pb-0 scrollbar-none">
            {categories.map((cat) => (
              <button
                key={cat}
                onClick={() => setSelectedCategory(cat)}
                className={`px-3.5 py-2 rounded-2xl text-xs font-semibold transition-all whitespace-nowrap ${
                  selectedCategory === cat
                    ? 'bg-neutral-950 text-white dark:bg-white dark:text-neutral-950 shadow-md'
                    : 'bg-neutral-100 dark:bg-neutral-900 text-neutral-600 dark:text-neutral-400 hover:text-neutral-950 dark:hover:text-white border border-neutral-200/60 dark:border-neutral-800'
                }`}
              >
                {cat}
              </button>
            ))}
          </div>

          <div className="relative w-full md:w-64">
            <Search className="w-4 h-4 text-neutral-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              placeholder={t('Search notes & tags...', 'নোট খুঁজুন...')}
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full pl-10 pr-4 py-2 rounded-2xl bg-neutral-100/70 dark:bg-neutral-900/70 border border-neutral-200 dark:border-neutral-800 text-xs text-neutral-900 dark:text-white placeholder-neutral-400 focus:outline-none focus:ring-2 focus:ring-emerald-500/50"
            />
          </div>
        </div>

        {/* Notes Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {filteredNotes.map((note) => (
            <div
              key={note.id}
              onClick={() => openNoteModal(note)}
              className="group p-6 rounded-3xl bg-white dark:bg-neutral-900/80 border border-neutral-200/80 dark:border-neutral-800 hover:border-emerald-500/50 dark:hover:border-emerald-500/40 shadow-sm hover:shadow-xl transition-all duration-300 flex flex-col justify-between space-y-4 cursor-pointer"
            >
              <div className="space-y-3">
                <div className="flex items-center justify-between">
                  <span className="text-[11px] font-mono text-emerald-600 dark:text-emerald-400 font-bold">
                    {note.category}
                  </span>
                  {getStageBadge(note.growthStage)}
                </div>

                <h3 className="text-base sm:text-lg font-bold text-neutral-950 dark:text-white group-hover:text-emerald-600 dark:group-hover:text-emerald-400 transition-colors">
                  {language === 'bn' ? note.titleBn || note.title : note.title}
                </h3>

                <p className="text-xs text-neutral-600 dark:text-neutral-400 line-clamp-3 leading-relaxed">
                  {language === 'bn' ? note.summaryBn || note.summary : note.summary}
                </p>
              </div>

              <div className="space-y-3 pt-2">
                <div className="flex flex-wrap gap-1.5">
                  {note.tags.map((tag, tIdx) => (
                    <span
                      key={tIdx}
                      className="text-[10px] font-mono px-2 py-0.5 rounded-lg bg-neutral-100 dark:bg-neutral-800 text-neutral-600 dark:text-neutral-400"
                    >
                      #{tag}
                    </span>
                  ))}
                </div>

                <div className="pt-3 border-t border-neutral-100 dark:border-neutral-800 flex items-center justify-between text-[11px] font-mono text-neutral-400">
                  <span className="flex items-center gap-1">
                    <Clock className="w-3 h-3" />
                    {note.readTime}
                  </span>
                  <span className="flex items-center gap-1 text-emerald-500 font-bold group-hover:translate-x-0.5 transition-transform">
                    {t('Read Note', 'নোট পড়ুন')}
                    <ArrowRight className="w-3 h-3" />
                  </span>
                </div>
              </div>
            </div>
          ))}
        </div>

      </div>

      {/* Note Reader Modal */}
      {activeNoteModal && (
        <div
          className="fixed inset-0 z-50 overflow-y-auto bg-neutral-950/80 backdrop-blur-md flex items-center justify-center p-4 sm:p-6 animate-in fade-in duration-200"
          onClick={(e) => {
            if (e.target === e.currentTarget) closeNoteModal();
          }}
        >
          <div className="relative w-full max-w-3xl bg-white dark:bg-neutral-900 border border-neutral-200 dark:border-neutral-800 rounded-[2rem] shadow-2xl p-6 sm:p-8 space-y-6 max-h-[85vh] overflow-y-auto">
            
            <div className="flex items-center justify-between border-b border-neutral-100 dark:border-neutral-800 pb-4">
              <div className="flex items-center gap-2">
                <span className="px-3 py-1 rounded-full text-xs font-mono font-bold bg-emerald-500/10 text-emerald-600 dark:text-emerald-400">
                  {activeNoteModal.category}
                </span>
                {getStageBadge(activeNoteModal.growthStage)}
              </div>

              <div className="flex items-center gap-2">
                <button
                  onClick={() => handleShare(activeNoteModal)}
                  className="p-2 rounded-full hover:bg-neutral-100 dark:hover:bg-neutral-800 text-neutral-500"
                  title="Share link"
                >
                  {copied ? <Check className="w-4 h-4 text-emerald-500" /> : <Share2 className="w-4 h-4" />}
                </button>
                <button
                  onClick={closeNoteModal}
                  className="p-2 rounded-full hover:bg-neutral-100 dark:hover:bg-neutral-800 text-neutral-500"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>
            </div>

            <div className="space-y-2">
              <h2 className="text-2xl sm:text-3xl font-extrabold text-neutral-950 dark:text-white">
                {language === 'bn' ? activeNoteModal.titleBn || activeNoteModal.title : activeNoteModal.title}
              </h2>
              <div className="flex items-center gap-3 text-xs font-mono text-neutral-400">
                <span>{t('Updated:', 'আপডেট:')} {activeNoteModal.updatedAt}</span>
                <span>•</span>
                <span>{activeNoteModal.readTime}</span>
              </div>
            </div>

            <div className="prose dark:prose-invert max-w-none text-sm leading-relaxed text-neutral-800 dark:text-neutral-200 whitespace-pre-line">
              {activeNoteModal.content}
            </div>

            <div className="flex flex-wrap gap-2 pt-4 border-t border-neutral-100 dark:border-neutral-800">
              {activeNoteModal.tags.map((tag, idx) => (
                <span
                  key={idx}
                  className="text-xs font-mono px-3 py-1 rounded-xl bg-neutral-100 dark:bg-neutral-800 text-neutral-700 dark:text-neutral-300"
                >
                  #{tag}
                </span>
              ))}
            </div>

          </div>
        </div>
      )}
    </section>
  );
};
