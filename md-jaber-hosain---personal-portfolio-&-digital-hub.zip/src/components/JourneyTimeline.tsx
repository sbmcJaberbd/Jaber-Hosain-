import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import {
  Milestone,
  Calendar,
  ChevronDown,
  ChevronUp,
  GraduationCap,
  Briefcase,
  Code,
  Trophy,
  Rocket,
  Compass
} from 'lucide-react';

interface MilestoneData {
  year: string;
  title: string;
  titleBn?: string;
  category: 'Education' | 'Career' | 'Project' | 'Achievement' | 'Future';
  subtitle: string;
  desc: string;
  tags: string[];
  icon: 'grad' | 'work' | 'code' | 'trophy' | 'rocket';
}

export const JourneyTimeline: React.FC = () => {
  const { language, t } = useApp();
  const [expandedIndex, setExpandedIndex] = useState<number | null>(0);

  const milestones: MilestoneData[] = [
    {
      year: '2026 — Present',
      title: 'Senior Frontend & Web Architecture Lead',
      titleBn: 'সিনিয়র ফ্রন্টএন্ড ও আর্কিটেকচার লিড',
      category: 'Career',
      subtitle: 'InnovateX Digital Solutions & Global Consulting',
      desc: 'Spearheading modern client-side architectures, real-time analytics hubs, and cross-platform design token systems. Dedicated to mentor-driven engineering and performance optimization.',
      tags: ['React 18', 'TypeScript', 'Tailwind CSS', 'GraphQL', 'Leadership'],
      icon: 'work'
    },
    {
      year: '2024 — 2025',
      title: 'Major Breakthroughs & Open Source Tooling',
      titleBn: 'ওপেন সোর্স উদ্যোগ ও ন্যাশনাল স্বীকৃতি',
      category: 'Achievement',
      subtitle: 'GitCraft CLI & National ICT UI/UX Award',
      desc: 'Created and launched GitCraft CLI, published developer productivity packages, and received first prize in human-centered UI/UX at the National Hackathon.',
      tags: ['GitCraft', 'CLI Tools', 'National Award', 'Hackathon'],
      icon: 'trophy'
    },
    {
      year: '2022 — 2024',
      title: 'Full-Stack Freelance Consultancy & Global Client Deployments',
      titleBn: 'ফুল-স্ট্যাক ফ্রিল্যান্স ও বৈশ্বিক ক্লায়েন্ট প্রজেক্ট',
      category: 'Career',
      subtitle: 'Independent Engineering & SaaS Solutions',
      desc: 'Built custom web applications for over 18 international clients, creating healthcare portals, e-commerce engines, and high-conversion landing pages with zero downtime.',
      tags: ['Node.js', 'Express', 'MongoDB', 'PostgreSQL', 'Stripe'],
      icon: 'code'
    },
    {
      year: '2020 — 2024',
      title: 'B.Sc. in Computer Science & Engineering',
      titleBn: 'কম্পিউটার সায়েন্সে স্নাতক ডিগ্রি অর্জন',
      category: 'Education',
      subtitle: 'Graduated with Honors & Led Coding Club',
      desc: 'Completed formal education in computer science, software engineering patterns, algorithmic complexity, database design, and distributed networks.',
      tags: ['Algorithms', 'Data Structures', 'DBMS', 'Software Engineering'],
      icon: 'grad'
    },
    {
      year: '2019 — 2020',
      title: 'The Spark: First Line of Code & Foundations',
      titleBn: 'কোডিংয়ের সূচনা ও প্রথম প্রজেক্ট',
      category: 'Project',
      subtitle: 'HTML, CSS, JavaScript & Endless Curiosity',
      desc: 'Wrote the very first web scripts, fell in love with interactive web experiences, and started building simple utilities and personal portfolios.',
      tags: ['HTML5', 'CSS3', 'JavaScript', 'First Steps'],
      icon: 'rocket'
    }
  ];

  const getIcon = (type: MilestoneData['icon']) => {
    switch (type) {
      case 'work': return <Briefcase className="w-5 h-5 text-emerald-500" />;
      case 'trophy': return <Trophy className="w-5 h-5 text-amber-500" />;
      case 'code': return <Code className="w-5 h-5 text-cyan-500" />;
      case 'grad': return <GraduationCap className="w-5 h-5 text-indigo-500" />;
      case 'rocket': return <Rocket className="w-5 h-5 text-rose-500" />;
      default: return <Milestone className="w-5 h-5 text-emerald-500" />;
    }
  };

  return (
    <section id="experience" className="py-24 relative bg-neutral-100/40 dark:bg-neutral-900/30">
      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Header */}
        <div className="text-center max-w-3xl mx-auto mb-16 space-y-3">
          <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-indigo-500/10 border border-indigo-500/30 text-indigo-600 dark:text-indigo-400 text-xs font-semibold font-mono">
            <Compass className="w-3.5 h-3.5" />
            <span>{t('Milestones & Growth', 'আমার পথচলা ও অভিজ্ঞতা')}</span>
          </div>
          <h2 className="text-3xl sm:text-5xl font-extrabold text-neutral-950 dark:text-white tracking-tight">
            {t('My Journey Timeline', 'ক্যারিয়ার ও শিক্ষাগত পথরেখা')}
          </h2>
          <p className="text-neutral-600 dark:text-neutral-400 text-base sm:text-lg">
            {t(
              'Key milestones, career stages, learning breakthroughs, and the journey so far.',
              'প্রতিটি ধাপের অর্জন, গুরুত্বপূর্ণ প্রজেক্ট এবং পেশাদার জীবনের বিবর্তন।'
            )}
          </p>
        </div>

        {/* Timeline Line & Items */}
        <div className="relative border-l-2 border-neutral-200 dark:border-neutral-800 ml-4 sm:ml-8 md:ml-12 pl-6 sm:pl-10 space-y-8">
          {milestones.map((item, idx) => {
            const isExpanded = expandedIndex === idx;

            return (
              <div key={idx} className="relative group">
                {/* Timeline Dot with Icon */}
                <div className="absolute -left-[37px] sm:-left-[53px] top-1.5 w-8 sm:w-10 h-8 sm:h-10 rounded-2xl bg-white dark:bg-neutral-900 border-2 border-neutral-300 dark:border-neutral-700 flex items-center justify-center shadow-md group-hover:border-emerald-500 transition-colors">
                  {getIcon(item.icon)}
                </div>

                {/* Milestone Content Card */}
                <div
                  onClick={() => setExpandedIndex(isExpanded ? null : idx)}
                  className={`p-6 rounded-3xl border transition-all duration-300 cursor-pointer ${
                    isExpanded
                      ? 'bg-white dark:bg-neutral-900 border-emerald-500/40 shadow-xl'
                      : 'bg-white/80 dark:bg-neutral-900/60 border-neutral-200/80 dark:border-neutral-800 hover:border-neutral-400 dark:hover:border-neutral-700'
                  }`}
                >
                  <div className="flex flex-wrap items-center justify-between gap-2 mb-2">
                    <div className="flex items-center gap-2">
                      <span className="px-2.5 py-0.5 rounded-full text-[11px] font-mono font-bold bg-neutral-100 dark:bg-neutral-800 text-neutral-700 dark:text-neutral-300">
                        {item.year}
                      </span>
                      <span className="text-xs font-semibold text-emerald-600 dark:text-emerald-400">
                        {item.category}
                      </span>
                    </div>

                    <button
                      className="text-neutral-400 hover:text-neutral-950 dark:hover:text-white"
                      title={isExpanded ? 'Collapse' : 'Expand'}
                    >
                      {isExpanded ? <ChevronUp className="w-5 h-5" /> : <ChevronDown className="w-5 h-5" />}
                    </button>
                  </div>

                  <h3 className="text-lg sm:text-xl font-bold text-neutral-950 dark:text-white group-hover:text-emerald-600 dark:group-hover:text-emerald-400 transition-colors">
                    {language === 'bn' ? item.titleBn || item.title : item.title}
                  </h3>
                  
                  <p className="text-xs font-medium text-neutral-500 dark:text-neutral-400 mt-0.5">
                    {item.subtitle}
                  </p>

                  {/* Expanded Details */}
                  {isExpanded && (
                    <div className="mt-4 pt-4 border-t border-neutral-100 dark:border-neutral-800 space-y-4 animate-in fade-in duration-200">
                      <p className="text-sm text-neutral-700 dark:text-neutral-300 leading-relaxed">
                        {item.desc}
                      </p>

                      <div className="flex flex-wrap gap-2 pt-1">
                        {item.tags.map((tag, tIdx) => (
                          <span
                            key={tIdx}
                            className="text-[11px] font-mono px-2.5 py-1 rounded-xl bg-neutral-100 dark:bg-neutral-800 text-neutral-700 dark:text-neutral-300 border border-neutral-200/50 dark:border-neutral-700/50"
                          >
                            #{tag}
                          </span>
                        ))}
                      </div>
                    </div>
                  )}
                </div>
              </div>
            );
          })}
        </div>

      </div>
    </section>
  );
};
