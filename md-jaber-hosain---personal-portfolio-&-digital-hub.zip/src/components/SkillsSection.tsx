import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { LEARNING_ROADMAP } from '../data/initialData';
import { SkillLevel } from '../types';
import {
  Code2,
  Server,
  Palette,
  Wrench,
  Sparkles,
  BookOpen,
  TrendingUp,
  FolderGit2,
  CheckCircle2,
  Calendar,
  Layers
} from 'lucide-react';

export const SkillsSection: React.FC = () => {
  const { skills, t } = useApp();
  const [activeCategory, setActiveCategory] = useState<string>('Frontend');

  const categories = [
    { id: 'Frontend', label: 'Frontend', labelBn: 'ফ্রন্টএন্ড', icon: <Code2 className="w-4 h-4" /> },
    { id: 'Backend', label: 'Backend', labelBn: 'ব্যাকএন্ড', icon: <Server className="w-4 h-4" /> },
    { id: 'UI/UX Design', label: 'UI/UX Design', labelBn: 'ইউআই/ইউএক্স', icon: <Palette className="w-4 h-4" /> },
    { id: 'Tools', label: 'Tools & DevOps', labelBn: 'টুলস ও ডেভঅপস', icon: <Wrench className="w-4 h-4" /> },
    { id: 'Other Skills', label: 'Other Skills', labelBn: 'অন্যান্য দক্ষতা', icon: <Layers className="w-4 h-4" /> }
  ];

  const getLevelBadge = (level: SkillLevel) => {
    switch (level) {
      case 'Expert':
        return (
          <span className="px-2.5 py-0.5 rounded-full text-[10px] font-mono font-bold bg-emerald-500/15 text-emerald-600 dark:text-emerald-400 border border-emerald-500/30">
            ★ Expert
          </span>
        );
      case 'Advanced':
        return (
          <span className="px-2.5 py-0.5 rounded-full text-[10px] font-mono font-bold bg-indigo-500/15 text-indigo-600 dark:text-indigo-400 border border-indigo-500/30">
            Advanced
          </span>
        );
      case 'Intermediate':
        return (
          <span className="px-2.5 py-0.5 rounded-full text-[10px] font-mono font-bold bg-cyan-500/15 text-cyan-600 dark:text-cyan-400 border border-cyan-500/30">
            Intermediate
          </span>
        );
      default:
        return (
          <span className="px-2.5 py-0.5 rounded-full text-[10px] font-mono font-bold bg-neutral-200 dark:bg-neutral-800 text-neutral-600 dark:text-neutral-400">
            Beginner
          </span>
        );
    }
  };

  const filteredSkills = skills.filter((s) => s.category === activeCategory);

  return (
    <section id="skills" className="py-24 relative bg-neutral-100/30 dark:bg-neutral-900/20">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Header */}
        <div className="text-center max-w-3xl mx-auto mb-16 space-y-3">
          <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-cyan-500/10 border border-cyan-500/30 text-cyan-600 dark:text-cyan-400 text-xs font-semibold font-mono">
            <Sparkles className="w-3.5 h-3.5" />
            <span>{t('Technical Mastery', 'প্রযুক্তিগত দক্ষতা ও ম্যাট্রিক্স')}</span>
          </div>
          <h2 className="text-3xl sm:text-5xl font-extrabold text-neutral-950 dark:text-white tracking-tight">
            {t('Intelligent Skill Matrix & Growth', 'দক্ষতার পূর্ণাঙ্গ বিবরণ ও রোডম্যাপ')}
          </h2>
          <p className="text-neutral-600 dark:text-neutral-400 text-base sm:text-lg">
            {t(
              'Categorized by depth, years of applied practice, shipped projects, and future learning horizons.',
              'কাজের অভিজ্ঞতা, বাস্তব প্রজেক্ট সংখ্যা এবং ভবিষ্যত শিখন লক্ষ্যের আলোকে সাজানো।'
            )}
          </p>
        </div>

        {/* Category Filter Tabs */}
        <div className="flex flex-wrap items-center justify-center gap-2.5 mb-12">
          {categories.map((cat) => (
            <button
              key={cat.id}
              id={`skills-tab-${cat.id.replace(/\s+/g, '-').toLowerCase()}`}
              onClick={() => setActiveCategory(cat.id)}
              className={`flex items-center gap-2 px-4 py-2.5 rounded-2xl text-xs font-bold transition-all ${
                activeCategory === cat.id
                  ? 'bg-neutral-950 text-white dark:bg-white dark:text-neutral-950 shadow-md scale-105'
                  : 'bg-white dark:bg-neutral-900 text-neutral-600 dark:text-neutral-400 hover:text-neutral-950 dark:hover:text-white border border-neutral-200 dark:border-neutral-800'
              }`}
            >
              {cat.icon}
              <span>{cat.label}</span>
            </button>
          ))}
        </div>

        {/* Active Skills Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6 mb-16">
          {filteredSkills.map((skill, idx) => (
            <div
              key={idx}
              className="p-5 rounded-3xl bg-white dark:bg-neutral-900/90 border border-neutral-200/80 dark:border-neutral-800 shadow-sm hover:shadow-md transition-all space-y-3"
            >
              <div className="flex items-start justify-between gap-2">
                <div className="space-y-1">
                  <div className="text-sm font-bold text-neutral-950 dark:text-white">
                    {skill.name}
                  </div>
                  <span className="text-[11px] font-mono text-neutral-400">
                    {skill.category}
                  </span>
                </div>
                {getLevelBadge(skill.level)}
              </div>

              <div className="grid grid-cols-2 gap-2 pt-2 border-t border-neutral-100 dark:border-neutral-800/80">
                <div className="p-2.5 rounded-xl bg-neutral-50 dark:bg-neutral-950/60 border border-neutral-200/50 dark:border-neutral-800">
                  <div className="text-[10px] font-mono text-neutral-400">
                    {t('Practice', 'অনুশীলন')}
                  </div>
                  <div className="text-xs font-bold text-neutral-900 dark:text-white mt-0.5">
                    {skill.years} {t('Years', 'বছর')}
                  </div>
                </div>

                <div className="p-2.5 rounded-xl bg-neutral-50 dark:bg-neutral-950/60 border border-neutral-200/50 dark:border-neutral-800">
                  <div className="text-[10px] font-mono text-neutral-400">
                    {t('Projects', 'প্রজেক্ট')}
                  </div>
                  <div className="text-xs font-bold text-emerald-600 dark:text-emerald-400 mt-0.5">
                    {skill.projectsCount}+ {t('Shipped', 'সম্পন্ন')}
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>

        {/* Bottom Split: Currently Learning & Future Learning Roadmap */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
          
          {/* Currently Learning (5 cols) */}
          <div className="lg:col-span-5 p-7 rounded-3xl bg-neutral-100/70 dark:bg-neutral-900/60 border border-neutral-200/80 dark:border-neutral-800 backdrop-blur-md space-y-4">
            <div className="flex items-center gap-2">
              <div className="p-2 rounded-xl bg-amber-500/10 text-amber-500 border border-amber-500/20">
                <BookOpen className="w-5 h-5" />
              </div>
              <div>
                <h3 className="text-base font-bold text-neutral-950 dark:text-white">
                  {t('Currently Learning', 'বর্তমানে যা শিখছি')}
                </h3>
                <p className="text-xs text-neutral-500 dark:text-neutral-400">
                  {t('Active daily deep-dives and research', 'দৈনিক অধ্যয়ন ও এক্সপেরিমেন্ট')}
                </p>
              </div>
            </div>

            <div className="space-y-3 pt-2">
              <div className="p-3.5 rounded-2xl bg-white dark:bg-neutral-950 border border-neutral-200/70 dark:border-neutral-800">
                <div className="flex items-center justify-between text-xs font-bold text-neutral-950 dark:text-white">
                  <span>Rust for Systems & Wasm</span>
                  <span className="text-[11px] font-mono text-amber-500">45% Progress</span>
                </div>
                <div className="w-full bg-neutral-100 dark:bg-neutral-800 h-1.5 rounded-full mt-2 overflow-hidden">
                  <div className="bg-amber-500 h-full rounded-full" style={{ width: '45%' }} />
                </div>
              </div>

              <div className="p-3.5 rounded-2xl bg-white dark:bg-neutral-950 border border-neutral-200/70 dark:border-neutral-800">
                <div className="flex items-center justify-between text-xs font-bold text-neutral-950 dark:text-white">
                  <span>Advanced WebGL & Three.js 3D</span>
                  <span className="text-[11px] font-mono text-cyan-500">60% Progress</span>
                </div>
                <div className="w-full bg-neutral-100 dark:bg-neutral-800 h-1.5 rounded-full mt-2 overflow-hidden">
                  <div className="bg-cyan-500 h-full rounded-full" style={{ width: '60%' }} />
                </div>
              </div>

              <div className="p-3.5 rounded-2xl bg-white dark:bg-neutral-950 border border-neutral-200/70 dark:border-neutral-800">
                <div className="flex items-center justify-between text-xs font-bold text-neutral-950 dark:text-white">
                  <span>PostgreSQL Query Optimization & Indexing</span>
                  <span className="text-[11px] font-mono text-emerald-500">80% Progress</span>
                </div>
                <div className="w-full bg-neutral-100 dark:bg-neutral-800 h-1.5 rounded-full mt-2 overflow-hidden">
                  <div className="bg-emerald-500 h-full rounded-full" style={{ width: '80%' }} />
                </div>
              </div>
            </div>
          </div>

          {/* Learning Roadmap (7 cols) */}
          <div className="lg:col-span-7 p-7 rounded-3xl bg-neutral-100/70 dark:bg-neutral-900/60 border border-neutral-200/80 dark:border-neutral-800 backdrop-blur-md space-y-4">
            <div className="flex items-center gap-2">
              <div className="p-2 rounded-xl bg-indigo-500/10 text-indigo-500 border border-indigo-500/20">
                <TrendingUp className="w-5 h-5" />
              </div>
              <div>
                <h3 className="text-base font-bold text-neutral-950 dark:text-white">
                  {t('Future Learning Roadmap', 'ভবিষ্যত প্রযুক্তি রোডম্যাপ')}
                </h3>
                <p className="text-xs text-neutral-500 dark:text-neutral-400">
                  {t('Target technologies for the next 12 months', 'পরবর্তী ১২ মাসের প্রযুক্তিগত লক্ষ্য')}
                </p>
              </div>
            </div>

            <div className="space-y-3 pt-2">
              {LEARNING_ROADMAP.map((item, rIdx) => (
                <div
                  key={rIdx}
                  className="p-4 rounded-2xl bg-white dark:bg-neutral-950 border border-neutral-200/70 dark:border-neutral-800 space-y-2"
                >
                  <div className="flex items-center justify-between">
                    <div className="text-xs font-bold text-neutral-950 dark:text-white">
                      {item.technology}
                    </div>
                    <div className="flex items-center gap-1 text-[11px] font-mono text-neutral-400">
                      <Calendar className="w-3 h-3" />
                      <span>{item.targetQuarter}</span>
                    </div>
                  </div>
                  <p className="text-xs text-neutral-600 dark:text-neutral-400">
                    {item.description}
                  </p>
                </div>
              ))}
            </div>
          </div>

        </div>

      </div>
    </section>
  );
};
