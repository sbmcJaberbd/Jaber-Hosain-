import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { PROFILE_INFO } from '../data/initialData';
import {
  Mail,
  Phone,
  MapPin,
  Send,
  CheckCircle2,
  Globe,
  Github,
  Linkedin,
  Twitter,
  Facebook,
  Youtube,
  Copy,
  Check,
  CreditCard
} from 'lucide-react';

export const ContactSection: React.FC = () => {
  const { setDigitalCardOpen, language, t } = useApp();

  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [subject, setSubject] = useState('');
  const [budget, setBudget] = useState('$1k - $5k');
  const [message, setMessage] = useState('');
  const [sentSuccess, setSentSuccess] = useState(false);
  const [copiedEmail, setCopiedEmail] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim() || !email.trim() || !message.trim()) return;

    setSentSuccess(true);
    setName('');
    setEmail('');
    setSubject('');
    setMessage('');
    setTimeout(() => setSentSuccess(false), 5000);
  };

  const copyEmail = () => {
    navigator.clipboard.writeText(PROFILE_INFO.email);
    setCopiedEmail(true);
    setTimeout(() => setCopiedEmail(false), 2000);
  };

  return (
    <section id="contact" className="py-24 relative bg-neutral-100/40 dark:bg-neutral-900/30">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Header */}
        <div className="text-center max-w-3xl mx-auto mb-16 space-y-3">
          <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-emerald-500/10 border border-emerald-500/30 text-emerald-600 dark:text-emerald-400 text-xs font-semibold font-mono">
            <Mail className="w-3.5 h-3.5" />
            <span>{t('Get In Touch', 'যোগাযোগ ও প্রজেক্ট আলোচনা')}</span>
          </div>
          <h2 className="text-3xl sm:text-5xl font-extrabold text-neutral-950 dark:text-white tracking-tight">
            {t('Let’s Build Something Remarkable', 'একসাথে নতুন কিছু শুরু করা যাক')}
          </h2>
          <p className="text-neutral-600 dark:text-neutral-400 text-base sm:text-lg">
            {t(
              'Have a project idea, contract opportunity, or engineering challenge? Drop a line and I’ll respond within 24 hours.',
              'নতুন প্রজেক্ট, কারিগরি পরামর্শ কিংবা যেকোনো আলোচনার জন্য সরাসরি বার্তা পাঠান।'
            )}
          </p>
        </div>

        {/* 2-Column Split: Direct Contact Info & Form */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-10">
          
          {/* Left Column: Direct Info & Social Hub (5 cols) */}
          <div className="lg:col-span-5 space-y-6">
            
            {/* Status Card */}
            <div className="p-7 rounded-3xl bg-white dark:bg-neutral-900/90 border border-neutral-200/80 dark:border-neutral-800 shadow-sm space-y-4">
              <div className="flex items-center gap-2">
                <span className="w-2.5 h-2.5 rounded-full bg-emerald-500 animate-ping" />
                <span className="text-xs font-mono font-bold text-emerald-600 dark:text-emerald-400 uppercase tracking-wider">
                  {t('Current Status', 'বর্তমান কাজের স্ট্যাটাস')}
                </span>
              </div>
              <p className="text-sm font-semibold text-neutral-900 dark:text-white">
                {t(PROFILE_INFO.availability, PROFILE_INFO.availabilityBn)}
              </p>

              <button
                onClick={() => setDigitalCardOpen(true)}
                className="w-full py-2.5 px-4 rounded-2xl bg-neutral-100 dark:bg-neutral-800 text-neutral-900 dark:text-white text-xs font-bold flex items-center justify-center gap-2 hover:bg-neutral-200 dark:hover:bg-neutral-700 transition-colors"
              >
                <CreditCard className="w-4 h-4 text-emerald-500" />
                <span>{t('View Digital Business Card', 'ডিজিটাল বিজনেস কার্ড দেখুন')}</span>
              </button>
            </div>

            {/* Direct Channels */}
            <div className="p-7 rounded-3xl bg-white dark:bg-neutral-900/90 border border-neutral-200/80 dark:border-neutral-800 shadow-sm space-y-4">
              <h3 className="text-base font-bold text-neutral-950 dark:text-white">
                {t('Direct Contact Information', 'সরাসরি যোগাযোগের ঠিকানা')}
              </h3>

              <div className="space-y-3">
                {/* Email with copy button */}
                <div className="flex items-center justify-between p-3 rounded-2xl bg-neutral-50 dark:bg-neutral-950 border border-neutral-200/60 dark:border-neutral-800">
                  <div className="flex items-center gap-3">
                    <div className="p-2 rounded-xl bg-emerald-500/10 text-emerald-500">
                      <Mail className="w-4 h-4" />
                    </div>
                    <div>
                      <div className="text-[10px] font-mono text-neutral-400">Email Address</div>
                      <div className="text-xs font-bold text-neutral-900 dark:text-white">{PROFILE_INFO.email}</div>
                    </div>
                  </div>
                  <button
                    onClick={copyEmail}
                    className="p-2 rounded-xl text-neutral-400 hover:text-emerald-500"
                    title="Copy Email"
                  >
                    {copiedEmail ? <Check className="w-4 h-4 text-emerald-500" /> : <Copy className="w-4 h-4" />}
                  </button>
                </div>

                {/* Phone */}
                <div className="flex items-center gap-3 p-3 rounded-2xl bg-neutral-50 dark:bg-neutral-950 border border-neutral-200/60 dark:border-neutral-800">
                  <div className="p-2 rounded-xl bg-indigo-500/10 text-indigo-500">
                    <Phone className="w-4 h-4" />
                  </div>
                  <div>
                    <div className="text-[10px] font-mono text-neutral-400">Phone & WhatsApp</div>
                    <div className="text-xs font-bold text-neutral-900 dark:text-white">{PROFILE_INFO.phone}</div>
                  </div>
                </div>

                {/* Location */}
                <div className="flex items-center gap-3 p-3 rounded-2xl bg-neutral-50 dark:bg-neutral-950 border border-neutral-200/60 dark:border-neutral-800">
                  <div className="p-2 rounded-xl bg-rose-500/10 text-rose-500">
                    <MapPin className="w-4 h-4" />
                  </div>
                  <div>
                    <div className="text-[10px] font-mono text-neutral-400">Location</div>
                    <div className="text-xs font-bold text-neutral-900 dark:text-white">{PROFILE_INFO.location}</div>
                  </div>
                </div>
              </div>
            </div>

            {/* Social Media Presence */}
            <div className="p-7 rounded-3xl bg-white dark:bg-neutral-900/90 border border-neutral-200/80 dark:border-neutral-800 shadow-sm space-y-4">
              <h3 className="text-base font-bold text-neutral-950 dark:text-white">
                {t('Connect on Social Platforms', 'সোশ্যাল মিডিয়ায় যুক্ত হোন')}
              </h3>

              <div className="grid grid-cols-3 gap-2">
                <a
                  href={PROFILE_INFO.socialLinks.github}
                  target="_blank"
                  rel="noreferrer"
                  className="p-3 rounded-2xl bg-neutral-50 dark:bg-neutral-950 border border-neutral-200/60 dark:border-neutral-800 flex flex-col items-center gap-1 hover:border-emerald-500 transition-colors"
                >
                  <Github className="w-5 h-5 text-neutral-800 dark:text-white" />
                  <span className="text-[10px] font-bold text-neutral-700 dark:text-neutral-300">GitHub</span>
                </a>

                <a
                  href={PROFILE_INFO.socialLinks.linkedin}
                  target="_blank"
                  rel="noreferrer"
                  className="p-3 rounded-2xl bg-neutral-50 dark:bg-neutral-950 border border-neutral-200/60 dark:border-neutral-800 flex flex-col items-center gap-1 hover:border-emerald-500 transition-colors"
                >
                  <Linkedin className="w-5 h-5 text-blue-500" />
                  <span className="text-[10px] font-bold text-neutral-700 dark:text-neutral-300">LinkedIn</span>
                </a>

                <a
                  href={PROFILE_INFO.socialLinks.twitter}
                  target="_blank"
                  rel="noreferrer"
                  className="p-3 rounded-2xl bg-neutral-50 dark:bg-neutral-950 border border-neutral-200/60 dark:border-neutral-800 flex flex-col items-center gap-1 hover:border-emerald-500 transition-colors"
                >
                  <Twitter className="w-5 h-5 text-sky-400" />
                  <span className="text-[10px] font-bold text-neutral-700 dark:text-neutral-300">Twitter / X</span>
                </a>

                <a
                  href={PROFILE_INFO.socialLinks.facebook}
                  target="_blank"
                  rel="noreferrer"
                  className="p-3 rounded-2xl bg-neutral-50 dark:bg-neutral-950 border border-neutral-200/60 dark:border-neutral-800 flex flex-col items-center gap-1 hover:border-emerald-500 transition-colors"
                >
                  <Facebook className="w-5 h-5 text-blue-600" />
                  <span className="text-[10px] font-bold text-neutral-700 dark:text-neutral-300">Facebook</span>
                </a>

                <a
                  href={PROFILE_INFO.socialLinks.youtube}
                  target="_blank"
                  rel="noreferrer"
                  className="p-3 rounded-2xl bg-neutral-50 dark:bg-neutral-950 border border-neutral-200/60 dark:border-neutral-800 flex flex-col items-center gap-1 hover:border-emerald-500 transition-colors"
                >
                  <Youtube className="w-5 h-5 text-rose-600" />
                  <span className="text-[10px] font-bold text-neutral-700 dark:text-neutral-300">YouTube</span>
                </a>

                <a
                  href={PROFILE_INFO.socialLinks.instagram}
                  target="_blank"
                  rel="noreferrer"
                  className="p-3 rounded-2xl bg-neutral-50 dark:bg-neutral-950 border border-neutral-200/60 dark:border-neutral-800 flex flex-col items-center gap-1 hover:border-emerald-500 transition-colors"
                >
                  <Globe className="w-5 h-5 text-pink-500" />
                  <span className="text-[10px] font-bold text-neutral-700 dark:text-neutral-300">Instagram</span>
                </a>
              </div>
            </div>

          </div>

          {/* Right Column: Contact Form (7 cols) */}
          <div className="lg:col-span-7 p-8 rounded-[2.5rem] bg-white dark:bg-neutral-900/90 border border-neutral-200/80 dark:border-neutral-800 shadow-xl space-y-6">
            <div className="space-y-1">
              <h3 className="text-2xl font-bold text-neutral-950 dark:text-white">
                {t('Send a Direct Message', 'বার্তা পাঠান')}
              </h3>
              <p className="text-xs text-neutral-500">
                {t('Fill out this form and I will respond to your inbox swiftly.', 'ফরমটি পূরণ করুন, আমি দ্রুত আপনার ইমেইলে যোগাযোগ করব।')}
              </p>
            </div>

            {sentSuccess && (
              <div className="p-4 rounded-2xl bg-emerald-500/15 border border-emerald-500/30 text-emerald-600 dark:text-emerald-400 text-xs flex items-center gap-2 animate-in fade-in">
                <CheckCircle2 className="w-5 h-5 shrink-0" />
                <span>{t('Thank you! Your message has been sent successfully. I will get back to you soon.', 'ধন্যবাদ! আপনার বার্তাটি পৌঁছেছে।')}</span>
              </div>
            )}

            <form onSubmit={handleSubmit} className="space-y-4">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-bold text-neutral-700 dark:text-neutral-300 mb-1">
                    {t('Your Name *', 'আপনার নাম *')}
                  </label>
                  <input
                    type="text"
                    required
                    placeholder="e.g. Arafat Hossain"
                    value={name}
                    onChange={(e) => setName(e.target.value)}
                    className="w-full px-4 py-2.5 rounded-2xl bg-neutral-50 dark:bg-neutral-950 border border-neutral-200 dark:border-neutral-800 text-xs text-neutral-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-emerald-500/50"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-neutral-700 dark:text-neutral-300 mb-1">
                    {t('Your Email *', 'আপনার ইমেইল *')}
                  </label>
                  <input
                    type="email"
                    required
                    placeholder="name@company.com"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    className="w-full px-4 py-2.5 rounded-2xl bg-neutral-50 dark:bg-neutral-950 border border-neutral-200 dark:border-neutral-800 text-xs text-neutral-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-emerald-500/50"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-bold text-neutral-700 dark:text-neutral-300 mb-1">
                    {t('Subject / Inquiry Type', 'বিষয়')}
                  </label>
                  <input
                    type="text"
                    placeholder="e.g. New Web Application Project"
                    value={subject}
                    onChange={(e) => setSubject(e.target.value)}
                    className="w-full px-4 py-2.5 rounded-2xl bg-neutral-50 dark:bg-neutral-950 border border-neutral-200 dark:border-neutral-800 text-xs text-neutral-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-emerald-500/50"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-neutral-700 dark:text-neutral-300 mb-1">
                    {t('Project Budget', 'আনুমানিক বাজেট')}
                  </label>
                  <select
                    value={budget}
                    onChange={(e) => setBudget(e.target.value)}
                    className="w-full px-4 py-2.5 rounded-2xl bg-neutral-50 dark:bg-neutral-950 border border-neutral-200 dark:border-neutral-800 text-xs text-neutral-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-emerald-500/50"
                  >
                    <option value="<$1k">&lt; $1,000</option>
                    <option value="$1k - $5k">$1,000 – $5,000</option>
                    <option value="$5k - $10k">$5,000 – $10,000</option>
                    <option value=">$10k">$10,000+</option>
                    <option value="Consultation">Hourly / Consultation</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="block text-xs font-bold text-neutral-700 dark:text-neutral-300 mb-1">
                  {t('Project Details & Message *', 'বিস্তারিত বার্তা *')}
                </label>
                <textarea
                  required
                  rows={5}
                  placeholder={t(
                    'Tell me about your goals, timeline, and key requirements...',
                    'আপনার প্রজেক্টের লক্ষ্য, সময়সীমা এবং গুরুত্বপূর্ণ প্রয়োজনীয় বিষয়সমূহ বিস্তারিত লিখুন...'
                  )}
                  value={message}
                  onChange={(e) => setMessage(e.target.value)}
                  className="w-full px-4 py-2.5 rounded-2xl bg-neutral-50 dark:bg-neutral-950 border border-neutral-200 dark:border-neutral-800 text-xs text-neutral-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-emerald-500/50 resize-none"
                />
              </div>

              <button
                type="submit"
                id="send-contact-btn"
                className="w-full py-3.5 px-6 rounded-2xl bg-emerald-500 hover:bg-emerald-400 text-neutral-950 font-bold text-xs flex items-center justify-center gap-2 shadow-lg shadow-emerald-500/20 transition-all"
              >
                <Send className="w-4 h-4" />
                <span>{t('Send Message Now', 'বার্তা পাঠান')}</span>
              </button>
            </form>
          </div>

        </div>

      </div>
    </section>
  );
};
