import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { PROFILE_INFO } from '../data/initialData';
import {
  ArrowUp,
  Mail,
  Send,
  CheckCircle2,
  Github,
  Linkedin,
  Twitter,
  Facebook,
  Youtube,
  Globe,
  CreditCard
} from 'lucide-react';

export const Footer: React.FC = () => {
  const { setDigitalCardOpen, language, t } = useApp();
  const [newsletterEmail, setNewsletterEmail] = useState('');
  const [subscribed, setSubscribed] = useState(false);

  const scrollToTop = () => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleSubscribe = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newsletterEmail.trim()) return;
    setSubscribed(true);
    setNewsletterEmail('');
    setTimeout(() => setSubscribed(false), 4000);
  };

  return (
    <footer className="border-t border-neutral-200/80 dark:border-neutral-800/80 bg-white dark:bg-neutral-950 pt-16 pb-12 transition-colors">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-12">
        
        {/* Top Grid */}
        <div className="grid grid-cols-1 md:grid-cols-12 gap-10">
          
          {/* Brand Col (5 cols) */}
          <div className="md:col-span-5 space-y-4">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-2xl bg-gradient-to-tr from-emerald-500 to-teal-400 flex items-center justify-center text-neutral-950 font-black font-heading text-lg shadow-md shadow-emerald-500/20">
                JH
              </div>
              <div>
                <h3 className="font-heading font-extrabold text-base text-neutral-950 dark:text-white tracking-tight">
                  {language === 'bn' ? PROFILE_INFO.nameBn : PROFILE_INFO.name}
                </h3>
                <p className="text-xs text-neutral-500 dark:text-neutral-400 font-mono">
                  {language === 'bn' ? PROFILE_INFO.titleBn : PROFILE_INFO.title}
                </p>
              </div>
            </div>

            <p className="text-xs text-neutral-600 dark:text-neutral-400 max-w-sm leading-relaxed">
              {t(
                'A craftsman-level digital presence bringing together software engineering rigor, user interface artistry, and continuous pursuit of wisdom.',
                'সফটওয়্যার ইঞ্জিনিয়ারিং, আধুনিক ডিজাইন এবং অবিরাম জ্ঞানার্জনের এক সার্বিক পোর্টফোলিও।'
              )}
            </p>

            {/* Social Icons */}
            <div className="flex items-center gap-2 pt-2">
              <a
                href={PROFILE_INFO.socialLinks.github}
                target="_blank"
                rel="noreferrer"
                className="p-2 rounded-xl bg-neutral-100 dark:bg-neutral-900 text-neutral-600 dark:text-neutral-400 hover:text-emerald-500 hover:bg-emerald-500/10 transition-colors"
                title="GitHub"
              >
                <Github className="w-4 h-4" />
              </a>
              <a
                href={PROFILE_INFO.socialLinks.linkedin}
                target="_blank"
                rel="noreferrer"
                className="p-2 rounded-xl bg-neutral-100 dark:bg-neutral-900 text-neutral-600 dark:text-neutral-400 hover:text-blue-500 hover:bg-blue-500/10 transition-colors"
                title="LinkedIn"
              >
                <Linkedin className="w-4 h-4" />
              </a>
              <a
                href={PROFILE_INFO.socialLinks.twitter}
                target="_blank"
                rel="noreferrer"
                className="p-2 rounded-xl bg-neutral-100 dark:bg-neutral-900 text-neutral-600 dark:text-neutral-400 hover:text-sky-400 hover:bg-sky-400/10 transition-colors"
                title="Twitter"
              >
                <Twitter className="w-4 h-4" />
              </a>
              <button
                onClick={() => setDigitalCardOpen(true)}
                className="px-3 py-1.5 rounded-xl bg-emerald-500/10 text-emerald-600 dark:text-emerald-400 text-xs font-mono font-bold hover:bg-emerald-500/20 transition-colors flex items-center gap-1.5"
              >
                <CreditCard className="w-3.5 h-3.5" />
                <span>vCard</span>
              </button>
            </div>
          </div>

          {/* Quick Navigation Links (3 cols) */}
          <div className="md:col-span-3 space-y-3">
            <h4 className="text-xs font-bold font-mono text-neutral-400 uppercase tracking-wider">
              {t('Explore Sections', 'নেভিগেশন লিংক')}
            </h4>
            <ul className="space-y-2 text-xs text-neutral-600 dark:text-neutral-400 font-medium">
              <li><a href="#about" className="hover:text-emerald-500 transition-colors">{t('About Biography', 'জীবনী ও দর্শন')}</a></li>
              <li><a href="#portfolio" className="hover:text-emerald-500 transition-colors">{t('Portfolio & Case Studies', 'পোর্টফোলিও ও প্রজেক্ট')}</a></li>
              <li><a href="#skills" className="hover:text-emerald-500 transition-colors">{t('Skills & Matrix', 'দক্ষতা ও রোডম্যাপ')}</a></li>
              <li><a href="#experience" className="hover:text-emerald-500 transition-colors">{t('Experience & Timeline', 'অভিজ্ঞতা ও ইতিহাস')}</a></li>
              <li><a href="#now" className="hover:text-emerald-500 transition-colors">{t('Now Page', 'নাও পেজ')}</a></li>
              <li><a href="#garden" className="hover:text-emerald-500 transition-colors">{t('Digital Garden', 'ডিজিটাল গার্ডেন')}</a></li>
              <li><a href="#advice-wall" className="hover:text-emerald-500 transition-colors font-bold text-emerald-600 dark:text-emerald-400">{t('Visitor Advice Wall (Sec 31)', 'পরামর্শ ও উপদেশ হাব')}</a></li>
              <li><a href="#guestbook" className="hover:text-emerald-500 transition-colors">{t('Sign Guestbook', 'গেস্টবুক')}</a></li>
            </ul>
          </div>

          {/* Newsletter Subscribe (4 cols) */}
          <div className="md:col-span-4 space-y-3">
            <h4 className="text-xs font-bold font-mono text-neutral-400 uppercase tracking-wider">
              {t('Technical Dispatch', 'নিউজলেটার')}
            </h4>
            <p className="text-xs text-neutral-600 dark:text-neutral-400">
              {t(
                'Receive occasional articles on architecture, modern React patterns, and creative engineering thoughts.',
                'নতুন আর্টিকেল এবং প্রযুক্তি ভাবনা সরাসরি আপনার ইমেইলে পেতে যুক্ত হোন।'
              )}
            </p>

            {subscribed && (
              <div className="p-3 rounded-2xl bg-emerald-500/15 text-emerald-600 dark:text-emerald-400 text-xs flex items-center gap-1.5">
                <CheckCircle2 className="w-4 h-4" />
                <span>{t('Subscribed! Thank you for joining.', 'যুক্ত হওয়ার জন্য ধন্যবাদ!')}</span>
              </div>
            )}

            <form onSubmit={handleSubscribe} className="flex gap-2">
              <input
                type="email"
                required
                placeholder="your.email@example.com"
                value={newsletterEmail}
                onChange={(e) => setNewsletterEmail(e.target.value)}
                className="flex-1 px-3.5 py-2.5 rounded-2xl bg-neutral-100 dark:bg-neutral-900 border border-neutral-200 dark:border-neutral-800 text-xs text-neutral-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-emerald-500/50"
              />
              <button
                type="submit"
                className="px-4 py-2.5 rounded-2xl bg-emerald-500 hover:bg-emerald-400 text-neutral-950 font-bold text-xs flex items-center gap-1 shadow-sm transition-all"
              >
                <Send className="w-3.5 h-3.5" />
              </button>
            </form>
          </div>

        </div>

        {/* Bottom Bar */}
        <div className="pt-8 border-t border-neutral-100 dark:border-neutral-900 flex flex-col sm:flex-row items-center justify-between gap-4 text-xs font-mono text-neutral-500 dark:text-neutral-400">
          <div className="flex items-center gap-1 text-center sm:text-left">
            <span>© {new Date().getFullYear()} Md Jaber Hosain. Built with precision & deep passion.</span>
          </div>

          <div className="flex items-center gap-4">
            <span>Dhaka, Bangladesh</span>
            <button
              onClick={scrollToTop}
              className="p-2.5 rounded-xl bg-neutral-100 dark:bg-neutral-900 text-neutral-700 dark:text-neutral-300 hover:bg-emerald-500 hover:text-neutral-950 transition-all flex items-center gap-1 text-xs font-bold"
              title="Back to Top"
            >
              <span>Top</span>
              <ArrowUp className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>

      </div>
    </footer>
  );
};
