import React from 'react';
import { useApp } from '../context/AppContext';
import { INITIAL_SERVICES } from '../data/initialData';
import {
  Sparkles,
  Code2,
  Palette,
  Gauge,
  ArrowRight,
  CheckCircle2,
  Layers,
  Send
} from 'lucide-react';

export const ServicesSection: React.FC = () => {
  const { language, t } = useApp();

  const iconMap: Record<string, React.ReactNode> = {
    Code2: <Code2 className="w-6 h-6 text-emerald-500" />,
    Sparkles: <Sparkles className="w-6 h-6 text-amber-500" />,
    Palette: <Palette className="w-6 h-6 text-indigo-500" />,
    Gauge: <Gauge className="w-6 h-6 text-cyan-500" />
  };

  const scrollToContact = () => {
    const el = document.getElementById('contact');
    if (el) el.scrollIntoView({ behavior: 'smooth' });
  };

  return (
    <section id="services" className="py-24 relative bg-neutral-100/40 dark:bg-neutral-900/30">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Header */}
        <div className="text-center max-w-3xl mx-auto mb-16 space-y-3">
          <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-emerald-500/10 border border-emerald-500/30 text-emerald-600 dark:text-emerald-400 text-xs font-semibold font-mono">
            <Layers className="w-3.5 h-3.5" />
            <span>{t('Professional Offerings', 'পেশাদার সেবাসমূহ')}</span>
          </div>
          <h2 className="text-3xl sm:text-5xl font-extrabold text-neutral-950 dark:text-white tracking-tight">
            {t('What I Build For Clients & Brands', 'ডিজিটাল সমাধান ও কারিগরি সেবা')}
          </h2>
          <p className="text-neutral-600 dark:text-neutral-400 text-base sm:text-lg">
            {t(
              'End-to-end engineering, refined interface architecture, and high-impact digital experiences.',
              'আইডিয়া থেকে শুরু করে পূর্ণাঙ্গ ওয়েবসাইট তৈরি, আধুনিকায়ন এবং পারফরম্যান্স অপ্টিমাইজেশন।'
            )}
          </p>
        </div>

        {/* Services Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          {INITIAL_SERVICES.map((service) => (
            <div
              key={service.id}
              className="p-8 rounded-3xl bg-white dark:bg-neutral-900/90 border border-neutral-200/80 dark:border-neutral-800 shadow-sm hover:shadow-xl transition-all duration-300 flex flex-col justify-between space-y-6"
            >
              <div className="space-y-4">
                <div className="flex items-center justify-between">
                  <div className="p-3 rounded-2xl bg-neutral-100 dark:bg-neutral-800">
                    {iconMap[service.icon] || <Code2 className="w-6 h-6 text-emerald-500" />}
                  </div>
                  {service.popular && (
                    <span className="px-3 py-1 rounded-full text-[11px] font-bold bg-emerald-500/15 text-emerald-600 dark:text-emerald-400 border border-emerald-500/30">
                      ★ High Demand
                    </span>
                  )}
                </div>

                <div className="space-y-2">
                  <h3 className="text-xl font-bold text-neutral-950 dark:text-white">
                    {language === 'bn' ? service.titleBn || service.title : service.title}
                  </h3>
                  <p className="text-sm text-neutral-600 dark:text-neutral-400 leading-relaxed">
                    {language === 'bn' ? service.shortDescBn || service.shortDesc : service.shortDesc}
                  </p>
                </div>

                {/* Process Steps */}
                <div className="space-y-2 pt-2">
                  <div className="text-xs font-mono font-bold uppercase tracking-wider text-neutral-400">
                    {t('Workflow Process', 'কাজের ধাপসমূহ')}
                  </div>
                  <div className="grid grid-cols-1 gap-1.5">
                    {service.process.map((step, idx) => (
                      <div key={idx} className="flex items-center gap-2 text-xs text-neutral-700 dark:text-neutral-300">
                        <span className="w-4 h-4 rounded-full bg-emerald-500/20 text-emerald-500 text-[10px] font-bold flex items-center justify-center shrink-0">
                          {idx + 1}
                        </span>
                        <span>{step}</span>
                      </div>
                    ))}
                  </div>
                </div>

                {/* Deliverables */}
                <div className="space-y-2 pt-2">
                  <div className="text-xs font-mono font-bold uppercase tracking-wider text-neutral-400">
                    {t('What You Receive', 'প্রাপ্তির তালিকা')}
                  </div>
                  <div className="grid grid-cols-1 gap-1.5">
                    {service.deliverables.map((del, dIdx) => (
                      <div key={dIdx} className="flex items-start gap-2 text-xs text-neutral-600 dark:text-neutral-400">
                        <CheckCircle2 className="w-3.5 h-3.5 text-emerald-500 shrink-0 mt-0.5" />
                        <span>{del}</span>
                      </div>
                    ))}
                  </div>
                </div>
              </div>

              {/* Action Button */}
              <div className="pt-4 border-t border-neutral-100 dark:border-neutral-800">
                <button
                  onClick={scrollToContact}
                  className="w-full py-3 px-4 rounded-2xl bg-neutral-100 dark:bg-neutral-800 hover:bg-emerald-500 hover:text-neutral-950 text-neutral-900 dark:text-white font-bold text-xs flex items-center justify-center gap-2 transition-all group"
                >
                  <Send className="w-3.5 h-3.5" />
                  <span>{t('Inquire About This Service', 'এই বিষয়ে আলোচনা করুন')}</span>
                  <ArrowRight className="w-3.5 h-3.5 group-hover:translate-x-1 transition-transform" />
                </button>
              </div>
            </div>
          ))}
        </div>

      </div>
    </section>
  );
};
