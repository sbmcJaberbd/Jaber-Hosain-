import React from 'react';
import { useApp } from '../context/AppContext';
import { PROFILE_INFO, CORE_VALUES } from '../data/initialData';
import {
  User,
  Sparkles,
  Target,
  Eye,
  ShieldCheck,
  Compass,
  BookOpen,
  CheckCircle2,
  HeartHandshake,
  Quote,
  Flame,
  Code2,
  Lightbulb,
  Heart
} from 'lucide-react';

export const AboutSection: React.FC = () => {
  const { language, t } = useApp();

  const iconMap: Record<string, React.ReactNode> = {
    ShieldCheck: <ShieldCheck className="w-5 h-5 text-emerald-500" />,
    Sparkles: <Sparkles className="w-5 h-5 text-amber-500" />,
    Compass: <Compass className="w-5 h-5 text-indigo-500" />,
    BookOpen: <BookOpen className="w-5 h-5 text-cyan-500" />,
    CheckCircle2: <CheckCircle2 className="w-5 h-5 text-emerald-400" />,
    HeartHandshake: <HeartHandshake className="w-5 h-5 text-rose-500" />
  };

  return (
    <section id="about" className="py-24 relative overflow-hidden">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto mb-16 space-y-3">
          <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-emerald-500/10 border border-emerald-500/30 text-emerald-600 dark:text-emerald-400 text-xs font-semibold font-mono">
            <User className="w-3.5 h-3.5" />
            <span>{t('Digital Biography', 'জীবন ও দর্শন')}</span>
          </div>
          <h2 className="text-3xl sm:text-5xl font-extrabold text-neutral-950 dark:text-white tracking-tight">
            {t('Who I Am & What Drives My Craft', 'আমার পরিচয় ও প্রেরণা')}
          </h2>
          <p className="text-neutral-600 dark:text-neutral-400 text-base sm:text-lg">
            {t(
              'A synthesis of software engineering, human-centered design, and an unwavering commitment to lifelong learning.',
              'সফটওয়্যার ইঞ্জিনিয়ারিং, আধুনিক ডিজাইন এবং অবিরাম জ্ঞানার্জনের এক অপূর্ব মেলবন্ধন।'
            )}
          </p>
        </div>

        {/* Top Story & Philosophy Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 mb-16">
          
          {/* Who I Am Narrative (7 Cols) */}
          <div className="lg:col-span-7 p-8 rounded-3xl bg-neutral-100/70 dark:bg-neutral-900/60 border border-neutral-200/80 dark:border-neutral-800 backdrop-blur-md space-y-5">
            <div className="flex items-center gap-3">
              <div className="p-2.5 rounded-2xl bg-emerald-500/10 text-emerald-500 border border-emerald-500/20">
                <Code2 className="w-6 h-6" />
              </div>
              <div>
                <h3 className="text-xl font-bold text-neutral-950 dark:text-white">
                  {t('The Journey of a Builder', 'একজন ডেভেলপারের গল্প')}
                </h3>
                <p className="text-xs text-neutral-500 dark:text-neutral-400 font-mono">
                  {t('Engineer • Designer • Lifelong Student', 'ইঞ্জিনিয়ার • ডিজাইনার • শিক্ষার্থী')}
                </p>
              </div>
            </div>

            <p className="text-neutral-700 dark:text-neutral-300 leading-relaxed">
              {t(PROFILE_INFO.bio, PROFILE_INFO.bioBn)}
            </p>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 pt-2">
              <div className="p-4 rounded-2xl bg-white dark:bg-neutral-950 border border-neutral-200/80 dark:border-neutral-800">
                <div className="flex items-center gap-2 font-bold text-sm text-neutral-950 dark:text-white mb-1">
                  <Flame className="w-4 h-4 text-amber-500" />
                  <span>{t('What I Love Building', 'যা তৈরি করতে পছন্দ করি')}</span>
                </div>
                <p className="text-xs text-neutral-600 dark:text-neutral-400">
                  {t(
                    'High-speed web platforms, polished design systems, accessible SaaS tools, and resilient APIs.',
                    'হাই-স্পিড ওয়েব প্ল্যাটফর্ম, আকর্ষণীয় ডিজাইন সিস্টেম এবং স্কেলেবল এপিআই।'
                  )}
                </p>
              </div>

              <div className="p-4 rounded-2xl bg-white dark:bg-neutral-950 border border-neutral-200/80 dark:border-neutral-800">
                <div className="flex items-center gap-2 font-bold text-sm text-neutral-950 dark:text-white mb-1">
                  <Lightbulb className="w-4 h-4 text-emerald-500" />
                  <span>{t('Problems I Solve', 'যে সমস্যা সমাধান করি')}</span>
                </div>
                <p className="text-xs text-neutral-600 dark:text-neutral-400">
                  {t(
                    'Eliminating sluggish user interfaces, untangling chaotic codebases, and boosting conversions.',
                    'ধীরগতির ইন্টারফেস দূর করা, কোড অপ্টিমাইজেশন এবং ব্যবহারকারীর অভিজ্ঞতা উন্নত করা।'
                  )}
                </p>
              </div>
            </div>
          </div>

          {/* Philosophy & Guiding Quote (5 Cols) */}
          <div className="lg:col-span-5 flex flex-col justify-between p-8 rounded-3xl bg-gradient-to-br from-emerald-950/30 via-neutral-900 to-neutral-950 border border-emerald-500/20 text-white relative overflow-hidden">
            <div className="absolute top-0 right-0 p-8 opacity-10">
              <Quote className="w-28 h-28 text-emerald-400" />
            </div>

            <div className="space-y-4 relative z-10">
              <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-emerald-500/20 text-emerald-400 border border-emerald-500/30 text-xs font-mono font-semibold">
                <Sparkles className="w-3.5 h-3.5" />
                <span>{t('My Philosophy', 'আমার মূল দর্শন')}</span>
              </div>
              <blockquote className="text-lg sm:text-xl font-medium leading-relaxed italic text-neutral-200">
                {t(PROFILE_INFO.philosophy, PROFILE_INFO.philosophyBn)}
              </blockquote>
            </div>

            <div className="pt-6 mt-6 border-t border-neutral-800 relative z-10 flex items-center justify-between">
              <div>
                <div className="font-bold text-sm text-white">
                  {language === 'bn' ? PROFILE_INFO.nameBn : PROFILE_INFO.name}
                </div>
                <div className="text-xs text-neutral-400 font-mono">
                  {t('Software Engineer & Creator', 'সফটওয়্যার ইঞ্জিনিয়ার ও ক্রিয়েটর')}
                </div>
              </div>
              <div className="w-10 h-10 rounded-full bg-emerald-500/20 border border-emerald-500/40 flex items-center justify-center text-emerald-400">
                <Heart className="w-4 h-4 fill-emerald-400/30" />
              </div>
            </div>
          </div>

        </div>

        {/* Mission & Vision Row */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8 mb-16">
          <div className="p-7 rounded-3xl bg-neutral-100/70 dark:bg-neutral-900/60 border border-neutral-200/80 dark:border-neutral-800 flex gap-4 items-start">
            <div className="p-3 rounded-2xl bg-emerald-500/10 text-emerald-500 border border-emerald-500/20 shrink-0">
              <Target className="w-6 h-6" />
            </div>
            <div className="space-y-2">
              <h4 className="text-lg font-bold text-neutral-950 dark:text-white">
                {t('My Mission', 'আমার লক্ষ্য ও মিশন')}
              </h4>
              <p className="text-sm text-neutral-600 dark:text-neutral-400 leading-relaxed">
                {t(PROFILE_INFO.mission, PROFILE_INFO.missionBn)}
              </p>
            </div>
          </div>

          <div className="p-7 rounded-3xl bg-neutral-100/70 dark:bg-neutral-900/60 border border-neutral-200/80 dark:border-neutral-800 flex gap-4 items-start">
            <div className="p-3 rounded-2xl bg-indigo-500/10 text-indigo-500 border border-indigo-500/20 shrink-0">
              <Eye className="w-6 h-6" />
            </div>
            <div className="space-y-2">
              <h4 className="text-lg font-bold text-neutral-950 dark:text-white">
                {t('My Vision', 'দীর্ঘমেয়াদী ভিশন')}
              </h4>
              <p className="text-sm text-neutral-600 dark:text-neutral-400 leading-relaxed">
                {t(PROFILE_INFO.vision, PROFILE_INFO.visionBn)}
              </p>
            </div>
          </div>
        </div>

        {/* Core Values Section */}
        <div className="space-y-6">
          <div className="text-center space-y-1">
            <h3 className="text-2xl font-bold text-neutral-950 dark:text-white">
              {t('Core Principles & Values', 'মূল মূল্যবোধ ও নীতিমালা')}
            </h3>
            <p className="text-xs font-mono text-neutral-500 dark:text-neutral-400">
              {t('The ethical pillars guiding every line of code I author', 'প্রতিটি কাজের পেছনের আদর্শিক ভিত্তি')}
            </p>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
            {CORE_VALUES.map((val, idx) => (
              <div
                key={idx}
                className="group p-6 rounded-3xl bg-white dark:bg-neutral-900/50 border border-neutral-200/80 dark:border-neutral-800 hover:border-emerald-500/50 dark:hover:border-emerald-500/40 transition-all duration-300 shadow-sm hover:shadow-lg"
              >
                <div className="flex items-center justify-between mb-4">
                  <div className="p-2.5 rounded-2xl bg-neutral-100 dark:bg-neutral-800 group-hover:scale-110 transition-transform">
                    {iconMap[val.icon] || <Sparkles className="w-5 h-5 text-emerald-500" />}
                  </div>
                  <span className="text-xs font-mono text-neutral-400">
                    0{idx + 1}
                  </span>
                </div>
                <h4 className="text-base font-bold text-neutral-950 dark:text-white group-hover:text-emerald-500 dark:group-hover:text-emerald-400 transition-colors">
                  {language === 'bn' ? val.titleBn : val.title}
                </h4>
                <p className="text-xs text-neutral-600 dark:text-neutral-400 mt-2 leading-relaxed">
                  {val.desc}
                </p>
              </div>
            ))}
          </div>
        </div>

      </div>
    </section>
  );
};
