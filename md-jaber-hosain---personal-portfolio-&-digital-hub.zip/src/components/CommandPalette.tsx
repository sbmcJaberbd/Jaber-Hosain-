import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import {
  Search,
  X,
  User,
  GraduationCap,
  Briefcase,
  Mail,
  Volume2,
  Moon,
  CreditCard,
  MessageSquare,
  Sprout,
  Activity,
  ArrowRight,
  BookOpen,
  Layers
} from 'lucide-react';

export const CommandPalette: React.FC = () => {
  const {
    isCommandPaletteOpen,
    setCommandPaletteOpen,
    theme,
    setTheme,
    toggleAmbientAudio,
    setDigitalCardOpen,
    setAdminDrawerOpen,
    setAuthModalOpen,
    t
  } = useApp();

  const [query, setQuery] = useState('');

  if (!isCommandPaletteOpen) return null;

  const scrollTo = (id: string) => {
    setCommandPaletteOpen(false);
    const el = document.getElementById(id);
    if (el) {
      el.scrollIntoView({ behavior: 'smooth' });
    }
  };

  const actions = [
    {
      id: 'about',
      label: 'About & Biography',
      labelBn: 'আমার পরিচয় ও দর্শন',
      icon: <User className="w-4 h-4 text-emerald-500" />,
      run: () => scrollTo('about')
    },
    {
      id: 'portfolio',
      label: 'View Portfolio & Projects',
      labelBn: 'প্রজেক্ট ও পোর্টফোলিও দেখুন',
      icon: <Briefcase className="w-4 h-4 text-indigo-500" />,
      run: () => scrollTo('portfolio')
    },
    {
      id: 'skills',
      label: 'Skill Matrix & Roadmap',
      labelBn: 'দক্ষতা ও রোডম্যাপ',
      icon: <Layers className="w-4 h-4 text-cyan-500" />,
      run: () => scrollTo('skills')
    },
    {
      id: 'experience',
      label: 'Experience & Milestones',
      labelBn: 'কাজের অভিজ্ঞতা ও ইতিহাস',
      icon: <GraduationCap className="w-4 h-4 text-amber-500" />,
      run: () => scrollTo('experience')
    },
    {
      id: 'now',
      label: 'Now Page (Active Focus)',
      labelBn: 'নাও পেজ (চলমান কাজ)',
      icon: <Activity className="w-4 h-4 text-emerald-500" />,
      run: () => scrollTo('now')
    },
    {
      id: 'garden',
      label: 'Digital Garden & Notes',
      labelBn: 'ডিজিটাল গার্ডেন ও নোট',
      icon: <Sprout className="w-4 h-4 text-emerald-400" />,
      run: () => scrollTo('garden')
    },
    {
      id: 'blog',
      label: 'Blog & Articles',
      labelBn: 'ব্লগ ও লেখালেখি',
      icon: <BookOpen className="w-4 h-4 text-indigo-400" />,
      run: () => scrollTo('blog')
    },
    {
      id: 'advice',
      label: 'Leave Advice for Jaber (Section 31)',
      labelBn: 'পরামর্শ প্রদান করুন (সেকশন ৩১)',
      icon: <MessageSquare className="w-4 h-4 text-rose-500" />,
      run: () => scrollTo('advice-wall')
    },
    {
      id: 'guestbook',
      label: 'Sign Guestbook',
      labelBn: 'গেস্টবুকে বার্তা লিখুন',
      icon: <MessageSquare className="w-4 h-4 text-amber-400" />,
      run: () => scrollTo('guestbook')
    },
    {
      id: 'contact',
      label: 'Contact & Inquire',
      labelBn: 'যোগাযোগ ও মেসেজ',
      icon: <Mail className="w-4 h-4 text-rose-400" />,
      run: () => scrollTo('contact')
    },
    {
      id: 'card',
      label: 'Open Digital Business Card',
      labelBn: 'ডিজিটাল বিজনেস কার্ড খুলুন',
      icon: <CreditCard className="w-4 h-4 text-emerald-500" />,
      run: () => {
        setCommandPaletteOpen(false);
        setDigitalCardOpen(true);
      }
    },
    {
      id: 'dashboard',
      label: 'Open Personal System Dashboard',
      labelBn: 'সিস্টেম ড্যাশবোর্ড খুলুন',
      icon: <Activity className="w-4 h-4 text-indigo-500" />,
      run: () => {
        setCommandPaletteOpen(false);
        setAdminDrawerOpen(true);
      }
    },
    {
      id: 'theme',
      label: 'Toggle Dark / Light Theme',
      labelBn: 'ডার্ক/লাইট থিম পরিবর্তন',
      icon: <Moon className="w-4 h-4 text-amber-400" />,
      run: () => {
        setCommandPaletteOpen(false);
        setTheme(theme === 'dark' ? 'light' : 'dark');
      }
    },
    {
      id: 'audio',
      label: 'Toggle Ambient Audio Soundscape',
      labelBn: 'অ্যাম্বিয়েন্ট সাউন্ড অন/অফ',
      icon: <Volume2 className="w-4 h-4 text-cyan-400" />,
      run: () => {
        setCommandPaletteOpen(false);
        toggleAmbientAudio();
      }
    },
    {
      id: 'auth',
      label: 'Account Sign In / Sign Up',
      labelBn: 'অ্যাকাউন্ট লগইন / সাইন আপ',
      icon: <User className="w-4 h-4 text-emerald-500" />,
      run: () => {
        setCommandPaletteOpen(false);
        setAuthModalOpen(true);
      }
    }
  ];

  const filtered = actions.filter(
    (a) =>
      a.label.toLowerCase().includes(query.toLowerCase()) ||
      (a.labelBn && a.labelBn.toLowerCase().includes(query.toLowerCase()))
  );

  return (
    <div
      className="fixed inset-0 z-50 overflow-y-auto bg-neutral-950/80 backdrop-blur-md flex items-start justify-center pt-20 p-4 animate-in fade-in duration-150"
      onClick={(e) => {
        if (e.target === e.currentTarget) setCommandPaletteOpen(false);
      }}
    >
      <div className="relative w-full max-w-xl bg-white dark:bg-neutral-900 border border-neutral-200 dark:border-neutral-800 rounded-[2rem] shadow-2xl overflow-hidden">
        
        {/* Search Input */}
        <div className="flex items-center px-5 py-4 border-b border-neutral-100 dark:border-neutral-800">
          <Search className="w-5 h-5 text-neutral-400 mr-3" />
          <input
            type="text"
            autoFocus
            placeholder={t('Type a command or search section...', 'কমান্ড বা সেকশন খুঁজুন...')}
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            className="w-full bg-transparent text-sm text-neutral-900 dark:text-white placeholder-neutral-400 focus:outline-none font-medium"
          />
          <button
            onClick={() => setCommandPaletteOpen(false)}
            className="p-1 rounded-lg text-neutral-400 hover:text-neutral-900 dark:hover:text-white"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Results List */}
        <div className="max-h-80 overflow-y-auto p-2 space-y-1">
          {filtered.length === 0 ? (
            <div className="p-6 text-center text-xs text-neutral-400 font-mono">
              {t('No matching commands found', 'কোনো কমান্ড পাওয়া যায়নি')}
            </div>
          ) : (
            filtered.map((item) => (
              <button
                key={item.id}
                onClick={item.run}
                className="w-full flex items-center justify-between p-3 rounded-xl hover:bg-neutral-100 dark:hover:bg-neutral-800 text-left transition-colors group"
              >
                <div className="flex items-center gap-3">
                  <div className="p-2 rounded-lg bg-neutral-50 dark:bg-neutral-950 border border-neutral-200/50 dark:border-neutral-800">
                    {item.icon}
                  </div>
                  <div>
                    <div className="text-xs font-bold text-neutral-900 dark:text-white">
                      {item.label}
                    </div>
                    {item.labelBn && (
                      <div className="text-[10px] text-neutral-400">
                        {item.labelBn}
                      </div>
                    )}
                  </div>
                </div>
                <ArrowRight className="w-3.5 h-3.5 text-neutral-400 group-hover:translate-x-1 transition-transform" />
              </button>
            ))
          )}
        </div>

        {/* Footer Hint */}
        <div className="px-5 py-2.5 bg-neutral-50 dark:bg-neutral-950 border-t border-neutral-100 dark:border-neutral-800 flex items-center justify-between text-[11px] font-mono text-neutral-400">
          <span>Md Jaber Hosain Navigation Suite</span>
          <span className="flex items-center gap-1">
            <kbd className="px-1.5 py-0.5 rounded bg-neutral-200 dark:bg-neutral-800 text-neutral-700 dark:text-neutral-300">ESC</kbd> to close
          </span>
        </div>

      </div>
    </div>
  );
};
