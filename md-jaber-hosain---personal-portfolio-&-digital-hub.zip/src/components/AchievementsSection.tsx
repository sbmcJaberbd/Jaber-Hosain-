import React from 'react';
import { useApp } from '../context/AppContext';
import { INITIAL_ACHIEVEMENTS } from '../data/initialData';
import {
  Trophy,
  Award,
  Calendar,
  Sparkles,
  CheckCircle,
  ExternalLink,
  ShieldAlert,
  Flame
} from 'lucide-react';

export const AchievementsSection: React.FC = () => {
  const { language, t } = useApp();

  return (
    <section id="achievements" className="py-24 relative">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Header */}
        <div className="text-center max-w-3xl mx-auto mb-16 space-y-3">
          <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-amber-500/10 border border-amber-500/30 text-amber-600 dark:text-amber-400 text-xs font-semibold font-mono">
            <Trophy className="w-3.5 h-3.5" />
            <span>{t('Recognition & Impact', 'অর্জন ও সম্মাননা')}</span>
          </div>
          <h2 className="text-3xl sm:text-5xl font-extrabold text-neutral-950 dark:text-white tracking-tight">
            {t('Honors, Certifications & Milestones', 'সার্টিফিকেশন ও উল্লেখযোগ্য সাফল্য')}
          </h2>
          <p className="text-neutral-600 dark:text-neutral-400 text-base sm:text-lg">
            {t(
              'Recognitions validating technical depth, creative design execution, and community contributions.',
              'প্রযুক্তিগত উৎকর্ষ ও কমিউনিটি অবদানের স্বীকৃতিস্বরূপ প্রাপ্ত সম্মাননা।'
            )}
          </p>
        </div>

        {/* Big Counter Showcase */}
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-5 mb-16">
          <div className="p-6 rounded-3xl bg-neutral-100/70 dark:bg-neutral-900/60 border border-neutral-200/80 dark:border-neutral-800 text-center space-y-2">
            <div className="text-4xl sm:text-5xl font-extrabold text-emerald-500 font-heading">
              25+
            </div>
            <div className="text-sm font-bold text-neutral-950 dark:text-white">
              {t('Projects Delivered', 'প্রজেক্ট ডেলিভারি')}
            </div>
            <p className="text-xs text-neutral-500">
              {t('Across web, SaaS & mobile domains', 'ওয়েব ও ক্লাউড প্ল্যাটফর্ম')}
            </p>
          </div>

          <div className="p-6 rounded-3xl bg-neutral-100/70 dark:bg-neutral-900/60 border border-neutral-200/80 dark:border-neutral-800 text-center space-y-2">
            <div className="text-4xl sm:text-5xl font-extrabold text-indigo-500 font-heading">
              100%
            </div>
            <div className="text-sm font-bold text-neutral-950 dark:text-white">
              {t('Client Satisfaction', 'ক্লায়েন্ট সন্তুষ্টি')}
            </div>
            <p className="text-xs text-neutral-500">
              {t('5-star rating on deliverables', 'সর্বোচ্চ রেটিং ও রিভিউ')}
            </p>
          </div>

          <div className="p-6 rounded-3xl bg-neutral-100/70 dark:bg-neutral-900/60 border border-neutral-200/80 dark:border-neutral-800 text-center space-y-2">
            <div className="text-4xl sm:text-5xl font-extrabold text-amber-500 font-heading">
              12+
            </div>
            <div className="text-sm font-bold text-neutral-950 dark:text-white">
              {t('Certifications Earned', 'সার্টিফিকেট অর্জন')}
            </div>
            <p className="text-xs text-neutral-500">
              {t('Meta, Coursera & Global Orgs', 'আন্তর্জাতিক প্রতিষ্ঠান থেকে')}
            </p>
          </div>

          <div className="p-6 rounded-3xl bg-neutral-100/70 dark:bg-neutral-900/60 border border-neutral-200/80 dark:border-neutral-800 text-center space-y-2">
            <div className="text-4xl sm:text-5xl font-extrabold text-rose-500 font-heading">
              18+
            </div>
            <div className="text-sm font-bold text-neutral-950 dark:text-white">
              {t('Tech Stacks Mastered', 'প্রযুক্তিতে পারদর্শিতা')}
            </div>
            <p className="text-xs text-neutral-500">
              {t('Frontend, backend & cloud tools', 'আধুনিক ডেভেলপার স্ট্যাক')}
            </p>
          </div>
        </div>

        {/* Achievement Cards */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {INITIAL_ACHIEVEMENTS.map((ach) => (
            <div
              key={ach.id}
              className="p-6 rounded-3xl bg-white dark:bg-neutral-900/80 border border-neutral-200/80 dark:border-neutral-800 shadow-sm flex items-start gap-4"
            >
              <div className="p-3 rounded-2xl bg-amber-500/10 text-amber-500 border border-amber-500/20 shrink-0">
                <Award className="w-6 h-6" />
              </div>

              <div className="space-y-2 flex-1">
                <div className="flex flex-wrap items-center justify-between gap-2">
                  <span className="text-xs font-mono font-semibold text-emerald-600 dark:text-emerald-400">
                    {ach.issuer}
                  </span>
                  <span className="text-[11px] font-mono text-neutral-400">
                    {ach.date}
                  </span>
                </div>

                <h3 className="text-base font-bold text-neutral-950 dark:text-white">
                  {language === 'bn' ? ach.titleBn || ach.title : ach.title}
                </h3>

                <p className="text-xs text-neutral-600 dark:text-neutral-400 leading-relaxed">
                  {ach.description}
                </p>

                {ach.badge && (
                  <div className="pt-1">
                    <span className="inline-block px-2.5 py-0.5 rounded-full text-[10px] font-mono font-bold bg-amber-500/10 text-amber-600 dark:text-amber-400 border border-amber-500/30">
                      {ach.badge}
                    </span>
                  </div>
                )}
              </div>
            </div>
          ))}
        </div>

      </div>
    </section>
  );
};
