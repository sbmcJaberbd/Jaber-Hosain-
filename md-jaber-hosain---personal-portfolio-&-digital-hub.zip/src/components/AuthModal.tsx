import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import {
  X,
  User,
  Lock,
  Mail,
  ArrowRight,
  CheckCircle2,
  LogOut,
  ShieldCheck
} from 'lucide-react';

export const AuthModal: React.FC = () => {
  const {
    isAuthModalOpen,
    setAuthModalOpen,
    auth,
    login,
    signup,
    logout,
    language,
    t
  } = useApp();

  const [mode, setMode] = useState<'signin' | 'signup'>('signin');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [name, setName] = useState('');
  const [successMsg, setSuccessMsg] = useState('');

  if (!isAuthModalOpen) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!email || !password) return;

    if (mode === 'signin') {
      login(email, undefined, name);
    } else {
      signup(name || 'Fellow Creator', email);
    }

    setSuccessMsg(t('Authentication successful!', 'সফলভাবে লগইন হয়েছে!'));
    setTimeout(() => {
      setSuccessMsg('');
      setAuthModalOpen(false);
    }, 1000);
  };

  const handleDemoVisitor = () => {
    login('visitor@community.org', 'Visitor', 'Guest Colleague');
    setAuthModalOpen(false);
  };

  const handleDemoAdmin = () => {
    login('sbmc.3925@gmail.com', 'Admin', 'MD JABER HOSAIN');
    setAuthModalOpen(false);
  };

  return (
    <div
      className="fixed inset-0 z-50 overflow-y-auto bg-neutral-950/80 backdrop-blur-md flex items-center justify-center p-4 animate-in fade-in duration-200"
      onClick={(e) => {
        if (e.target === e.currentTarget) setAuthModalOpen(false);
      }}
    >
      <div className="relative w-full max-w-md bg-white dark:bg-neutral-900 border border-neutral-200 dark:border-neutral-800 rounded-[2.5rem] shadow-2xl p-6 sm:p-8 space-y-6">
        
        {/* Header */}
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="p-2 rounded-xl bg-emerald-500/10 text-emerald-500">
              <User className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-lg font-bold text-neutral-950 dark:text-white">
                {auth.isLoggedIn
                  ? t('User Profile & Session', 'প্রোফাইল')
                  : mode === 'signin'
                  ? t('Sign In to Account', 'লগইন করুন')
                  : t('Create Visitor Account', 'নতুন অ্যাকাউন্ট')}
              </h2>
              <p className="text-xs text-neutral-400 font-mono">
                Md Jaber Hosain Portal
              </p>
            </div>
          </div>

          <button
            onClick={() => setAuthModalOpen(false)}
            className="p-2 rounded-full hover:bg-neutral-100 dark:hover:bg-neutral-800 text-neutral-400 hover:text-neutral-900 dark:hover:text-white"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* If user is already logged in */}
        {auth.isLoggedIn && auth.user ? (
          <div className="space-y-6">
            <div className="p-5 rounded-3xl bg-neutral-50 dark:bg-neutral-950 border border-neutral-200/80 dark:border-neutral-800 space-y-3">
              <div className="flex items-center gap-3">
                <div className="w-12 h-12 rounded-2xl bg-emerald-500/20 text-emerald-500 flex items-center justify-center font-bold text-lg">
                  {auth.user.name.charAt(0)}
                </div>
                <div>
                  <div className="font-bold text-sm text-neutral-950 dark:text-white">
                    {auth.user.name}
                  </div>
                  <div className="text-xs text-neutral-400 font-mono">
                    {auth.user.email}
                  </div>
                  <div className="text-[10px] font-mono font-bold text-emerald-500 mt-0.5">
                    ROLE: {auth.user.role.toUpperCase()}
                  </div>
                </div>
              </div>
            </div>

            <button
              onClick={() => {
                logout();
                setAuthModalOpen(false);
              }}
              className="w-full py-3 px-4 rounded-2xl bg-rose-500/10 hover:bg-rose-500 hover:text-white text-rose-600 dark:text-rose-400 font-bold text-xs flex items-center justify-center gap-2 transition-colors border border-rose-500/20"
            >
              <LogOut className="w-4 h-4" />
              <span>{t('Sign Out', 'লগ আউট করুন')}</span>
            </button>
          </div>
        ) : (
          <>
            {/* Tab switch */}
            <div className="flex p-1 rounded-2xl bg-neutral-100 dark:bg-neutral-800">
              <button
                type="button"
                onClick={() => setMode('signin')}
                className={`flex-1 py-2 text-xs font-bold rounded-xl transition-all ${
                  mode === 'signin'
                    ? 'bg-white dark:bg-neutral-900 text-neutral-950 dark:text-white shadow-sm'
                    : 'text-neutral-500 hover:text-neutral-950 dark:hover:text-white'
                }`}
              >
                {t('Sign In', 'লগইন')}
              </button>
              <button
                type="button"
                onClick={() => setMode('signup')}
                className={`flex-1 py-2 text-xs font-bold rounded-xl transition-all ${
                  mode === 'signup'
                    ? 'bg-white dark:bg-neutral-900 text-neutral-950 dark:text-white shadow-sm'
                    : 'text-neutral-500 hover:text-neutral-950 dark:hover:text-white'
                }`}
              >
                {t('Sign Up', 'রেজিস্ট্রেশন')}
              </button>
            </div>

            {successMsg && (
              <div className="p-3.5 rounded-2xl bg-emerald-500/15 border border-emerald-500/30 text-emerald-600 dark:text-emerald-400 text-xs flex items-center gap-2">
                <CheckCircle2 className="w-4 h-4" />
                <span>{successMsg}</span>
              </div>
            )}

            {/* Form */}
            <form onSubmit={handleSubmit} className="space-y-4">
              {mode === 'signup' && (
                <div>
                  <label className="block text-xs font-bold text-neutral-700 dark:text-neutral-300 mb-1">
                    {t('Full Name', 'পুরো নাম')}
                  </label>
                  <div className="relative">
                    <User className="w-4 h-4 text-neutral-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
                    <input
                      type="text"
                      required
                      placeholder="e.g. Md Jaber Hosain"
                      value={name}
                      onChange={(e) => setName(e.target.value)}
                      className="w-full pl-10 pr-4 py-2.5 rounded-2xl bg-neutral-50 dark:bg-neutral-950 border border-neutral-200 dark:border-neutral-800 text-xs text-neutral-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-emerald-500/50"
                    />
                  </div>
                </div>
              )}

              <div>
                <label className="block text-xs font-bold text-neutral-700 dark:text-neutral-300 mb-1">
                  {t('Email Address', 'ইমেইল অ্যাড্রেস')}
                </label>
                <div className="relative">
                  <Mail className="w-4 h-4 text-neutral-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
                  <input
                    type="email"
                    required
                    placeholder="name@example.com"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    className="w-full pl-10 pr-4 py-2.5 rounded-2xl bg-neutral-50 dark:bg-neutral-950 border border-neutral-200 dark:border-neutral-800 text-xs text-neutral-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-emerald-500/50"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-bold text-neutral-700 dark:text-neutral-300 mb-1">
                  {t('Password', 'পাসওয়ার্ড')}
                </label>
                <div className="relative">
                  <Lock className="w-4 h-4 text-neutral-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
                  <input
                    type="password"
                    required
                    placeholder="••••••••"
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    className="w-full pl-10 pr-4 py-2.5 rounded-2xl bg-neutral-50 dark:bg-neutral-950 border border-neutral-200 dark:border-neutral-800 text-xs text-neutral-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-emerald-500/50"
                  />
                </div>
              </div>

              <button
                type="submit"
                id="auth-submit-btn"
                className="w-full py-3 px-4 rounded-2xl bg-emerald-500 hover:bg-emerald-400 text-neutral-950 font-bold text-xs flex items-center justify-center gap-2 shadow-md transition-all"
              >
                <span>{mode === 'signin' ? t('Sign In', 'লগইন করুন') : t('Create Account', 'অ্যাকাউন্ট তৈরি করুন')}</span>
                <ArrowRight className="w-4 h-4" />
              </button>
            </form>

            {/* 1-Click Demo Buttons */}
            <div className="pt-2 border-t border-neutral-100 dark:border-neutral-800 space-y-2">
              <div className="text-[11px] font-mono text-center text-neutral-400">
                {t('Fast Demo 1-Click Access:', '১-ক্লিকে ডেমো প্রবেশ:')}
              </div>
              <div className="grid grid-cols-2 gap-2">
                <button
                  type="button"
                  onClick={handleDemoVisitor}
                  className="py-2 px-3 rounded-xl bg-neutral-100 dark:bg-neutral-800 text-[11px] font-bold text-neutral-800 dark:text-neutral-200 hover:bg-neutral-200 dark:hover:bg-neutral-700 transition-colors"
                >
                  {t('Demo Visitor', 'ভিজিটর ডেমো')}
                </button>
                <button
                  type="button"
                  onClick={handleDemoAdmin}
                  className="py-2 px-3 rounded-xl bg-emerald-500/10 border border-emerald-500/20 text-[11px] font-bold text-emerald-600 dark:text-emerald-400 hover:bg-emerald-500/20 transition-colors flex items-center justify-center gap-1"
                >
                  <ShieldCheck className="w-3.5 h-3.5" />
                  <span>{t('Admin (Jaber)', 'অ্যাডমিন ডেমো')}</span>
                </button>
              </div>
            </div>
          </>
        )}

      </div>
    </div>
  );
};
