import React from 'react';
import { useApp } from '../context/AppContext';
import {
  X,
  ExternalLink,
  Github,
  CheckCircle,
  AlertCircle,
  Layers,
  ArrowRight,
  Code2,
  Calendar,
  Sparkles
} from 'lucide-react';

export const CaseStudyModal: React.FC = () => {
  const { activeProjectModal, closeProjectModal, projects, openProjectModal, language, t } = useApp();

  if (!activeProjectModal) return null;

  const { title, titleBn, category, tags, year, liveUrl, githubUrl, caseStudy } = activeProjectModal;

  // Handle Next Project
  const currentIndex = projects.findIndex((p) => p.id === activeProjectModal.id);
  const nextProject = projects[(currentIndex + 1) % projects.length];

  return (
    <div
      id="case-study-modal-backdrop"
      className="fixed inset-0 z-50 overflow-y-auto bg-neutral-950/80 backdrop-blur-md flex items-center justify-center p-4 sm:p-6 md:p-10 animate-in fade-in duration-200"
      onClick={(e) => {
        if (e.target === e.currentTarget) closeProjectModal();
      }}
    >
      <div className="relative w-full max-w-4xl bg-white dark:bg-neutral-900 border border-neutral-200 dark:border-neutral-800 rounded-[2rem] shadow-2xl overflow-hidden my-auto max-h-[90vh] flex flex-col">
        
        {/* Modal Header Bar */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-neutral-200 dark:border-neutral-800 sticky top-0 bg-white/95 dark:bg-neutral-900/95 backdrop-blur-md z-20">
          <div className="flex items-center gap-2">
            <span className="px-3 py-1 rounded-full text-xs font-mono font-bold bg-emerald-500/10 text-emerald-600 dark:text-emerald-400 border border-emerald-500/20">
              {category}
            </span>
            <span className="text-xs text-neutral-400 font-mono flex items-center gap-1">
              <Calendar className="w-3.5 h-3.5" />
              {year}
            </span>
          </div>

          <button
            id="close-case-study-btn"
            onClick={closeProjectModal}
            className="p-2 rounded-full text-neutral-500 hover:text-neutral-900 dark:hover:text-white hover:bg-neutral-100 dark:hover:bg-neutral-800 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Scrollable Content Body */}
        <div className="overflow-y-auto p-6 sm:p-8 space-y-8">
          
          {/* Main Title & Action Links */}
          <div className="space-y-3">
            <h2 className="text-2xl sm:text-4xl font-extrabold text-neutral-950 dark:text-white tracking-tight">
              {language === 'bn' ? titleBn || title : title}
            </h2>

            <div className="flex flex-wrap items-center gap-3 pt-1">
              {liveUrl && (
                <a
                  href={liveUrl}
                  target="_blank"
                  rel="noreferrer"
                  className="px-4 py-2 rounded-xl bg-emerald-500 text-neutral-950 font-bold text-xs flex items-center gap-1.5 hover:bg-emerald-400 transition-colors shadow-sm"
                >
                  <ExternalLink className="w-3.5 h-3.5" />
                  <span>{t('Live Website / Demo', 'লাইভ ওয়েবসাইট')}</span>
                </a>
              )}

              {githubUrl && (
                <a
                  href={githubUrl}
                  target="_blank"
                  rel="noreferrer"
                  className="px-4 py-2 rounded-xl bg-neutral-100 dark:bg-neutral-800 text-neutral-900 dark:text-white font-semibold text-xs flex items-center gap-1.5 hover:bg-neutral-200 dark:hover:bg-neutral-700 transition-colors"
                >
                  <Github className="w-3.5 h-3.5" />
                  <span>{t('View Source Code', 'সোর্স কোড')}</span>
                </a>
              )}
            </div>
          </div>

          {/* Project Overview Banner */}
          <div className="p-6 rounded-3xl bg-neutral-100/70 dark:bg-neutral-800/50 border border-neutral-200/80 dark:border-neutral-700/60 space-y-2">
            <div className="text-xs font-mono font-bold uppercase tracking-wider text-emerald-600 dark:text-emerald-400 flex items-center gap-1.5">
              <Sparkles className="w-4 h-4" />
              <span>{t('Project Overview', 'প্রজেক্ট সারসংক্ষেপ')}</span>
            </div>
            <p className="text-sm sm:text-base text-neutral-800 dark:text-neutral-200 leading-relaxed">
              {language === 'bn' ? caseStudy.overviewBn || caseStudy.overview : caseStudy.overview}
            </p>
          </div>

          {/* Problem vs Solution Split */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {/* The Problem */}
            <div className="p-6 rounded-3xl bg-rose-500/5 dark:bg-rose-500/10 border border-rose-500/20 space-y-2">
              <div className="flex items-center gap-2 text-rose-600 dark:text-rose-400 font-bold text-sm">
                <AlertCircle className="w-4 h-4" />
                <span>{t('The Core Problem', 'মূল সমস্যা')}</span>
              </div>
              <p className="text-xs sm:text-sm text-neutral-700 dark:text-neutral-300 leading-relaxed">
                {language === 'bn' ? caseStudy.problemBn || caseStudy.problem : caseStudy.problem}
              </p>
            </div>

            {/* The Solution */}
            <div className="p-6 rounded-3xl bg-emerald-500/5 dark:bg-emerald-500/10 border border-emerald-500/20 space-y-2">
              <div className="flex items-center gap-2 text-emerald-600 dark:text-emerald-400 font-bold text-sm">
                <CheckCircle className="w-4 h-4" />
                <span>{t('The Engineering Solution', 'প্রযুক্তিগত সমাধান')}</span>
              </div>
              <p className="text-xs sm:text-sm text-neutral-700 dark:text-neutral-300 leading-relaxed">
                {language === 'bn' ? caseStudy.solutionBn || caseStudy.solution : caseStudy.solution}
              </p>
            </div>
          </div>

          {/* My Role & Technologies Used */}
          <div className="grid grid-cols-1 md:grid-cols-12 gap-6">
            <div className="md:col-span-6 p-6 rounded-3xl bg-white dark:bg-neutral-950 border border-neutral-200 dark:border-neutral-800 space-y-2">
              <div className="text-xs font-mono font-bold text-neutral-400 uppercase tracking-wider">
                {t('My Role & Responsibilities', 'আমার দায়িত্ব ও ভূমিকা')}
              </div>
              <p className="text-sm font-semibold text-neutral-900 dark:text-white">
                {caseStudy.myRole}
              </p>
            </div>

            <div className="md:col-span-6 p-6 rounded-3xl bg-white dark:bg-neutral-950 border border-neutral-200 dark:border-neutral-800 space-y-2">
              <div className="text-xs font-mono font-bold text-neutral-400 uppercase tracking-wider">
                {t('Technology Stack', 'ব্যবহৃত প্রযুক্তি')}
              </div>
              <div className="flex flex-wrap gap-1.5 pt-1">
                {(caseStudy?.technologies || []).map((tech, idx) => (
                  <span
                    key={idx}
                    className="text-xs font-mono px-2.5 py-1 rounded-xl bg-neutral-100 dark:bg-neutral-800 text-neutral-700 dark:text-neutral-300"
                  >
                    {tech}
                  </span>
                ))}
              </div>
            </div>
          </div>

          {/* Key Challenges */}
          {caseStudy?.challenges && caseStudy.challenges.length > 0 && (
            <div className="space-y-3">
              <h3 className="text-lg font-bold text-neutral-950 dark:text-white flex items-center gap-2">
                <Code2 className="w-5 h-5 text-indigo-500" />
                <span>{t('Key Technical Challenges', 'প্রধান কারিগরি চ্যালেঞ্জ')}</span>
              </h3>
              <div className="space-y-2">
                {(caseStudy.challenges || []).map((challenge, cIdx) => (
                  <div
                    key={cIdx}
                    className="flex items-start gap-2.5 p-3.5 rounded-2xl bg-neutral-50 dark:bg-neutral-950/60 border border-neutral-200/60 dark:border-neutral-800 text-xs sm:text-sm text-neutral-700 dark:text-neutral-300"
                  >
                    <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 mt-2 shrink-0" />
                    <span>{challenge}</span>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Step-by-Step Development Process */}
          {caseStudy?.processSteps && caseStudy.processSteps.length > 0 && (
            <div className="space-y-4">
              <h3 className="text-lg font-bold text-neutral-950 dark:text-white flex items-center gap-2">
                <Layers className="w-5 h-5 text-emerald-500" />
                <span>{t('Development Process', 'ডেভেলপমেন্ট প্রক্রিয়া')}</span>
              </h3>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                {(caseStudy.processSteps || []).map((step, sIdx) => (
                  <div
                    key={sIdx}
                    className="p-4 rounded-2xl bg-white dark:bg-neutral-950 border border-neutral-200 dark:border-neutral-800 space-y-1.5"
                  >
                    <div className="text-xs font-bold text-emerald-600 dark:text-emerald-400">
                      {step.title}
                    </div>
                    <p className="text-xs text-neutral-600 dark:text-neutral-400 leading-relaxed">
                      {step.desc}
                    </p>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Final Result */}
          {caseStudy?.finalResult && (
            <div className="p-6 rounded-3xl bg-emerald-950/30 border border-emerald-500/30 text-neutral-100 space-y-2">
              <div className="text-xs font-mono font-bold uppercase tracking-wider text-emerald-400">
                {t('Final Outcome & Impact', 'চূড়ান্ত ফলাফল ও প্রভাব')}
              </div>
              <p className="text-sm font-medium leading-relaxed">
                {language === 'bn' ? caseStudy.finalResultBn || caseStudy.finalResult : caseStudy.finalResult}
              </p>
            </div>
          )}

          {/* Project Screenshot Gallery */}
          {caseStudy?.gallery && caseStudy.gallery.length > 0 && (
            <div className="space-y-3">
              <h3 className="text-sm font-bold uppercase tracking-wider text-neutral-400 font-mono">
                {t('Project Screenshots', 'প্রজেক্টের স্ক্রিনশট')}
              </h3>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                {(caseStudy.gallery || []).map((img, gIdx) => (
                  <div key={gIdx} className="rounded-2xl overflow-hidden border border-neutral-200 dark:border-neutral-800 shadow-md">
                    <img src={img} alt={`Screenshot ${gIdx + 1}`} className="w-full h-48 object-cover hover:scale-105 transition-transform duration-300" />
                  </div>
                ))}
              </div>
            </div>
          )}

        </div>

        {/* Modal Footer Navigation */}
        <div className="px-6 py-4 border-t border-neutral-200 dark:border-neutral-800 flex items-center justify-between bg-neutral-50 dark:bg-neutral-950">
          <button
            onClick={closeProjectModal}
            className="px-4 py-2 rounded-xl text-xs font-semibold text-neutral-500 hover:text-neutral-950 dark:hover:text-white"
          >
            {t('Close', 'বন্ধ করুন')}
          </button>

          <button
            id="modal-next-project-btn"
            onClick={() => openProjectModal(nextProject)}
            className="px-5 py-2.5 rounded-xl bg-neutral-900 dark:bg-white text-white dark:text-neutral-950 text-xs font-bold flex items-center gap-2 hover:opacity-90 transition-opacity"
          >
            <span>{t('Next Project:', 'পরবর্তী প্রজেক্ট:')} {nextProject.title.slice(0, 18)}...</span>
            <ArrowRight className="w-4 h-4" />
          </button>
        </div>

      </div>
    </div>
  );
};
