export type Language = 'en' | 'bn';
export type Theme = 'dark' | 'light' | 'system';

export interface Project {
  id: string;
  title: string;
  titleBn?: string;
  category: 'Web Development' | 'UI/UX Design' | 'Client Projects' | 'Personal Projects' | 'Open Source' | 'Experimental Projects';
  shortDesc: string;
  shortDescBn?: string;
  image: string;
  tags: string[];
  year: string;
  featured: boolean;
  liveUrl?: string;
  githubUrl?: string;
  caseStudy: {
    overview: string;
    overviewBn?: string;
    problem: string;
    problemBn?: string;
    solution: string;
    solutionBn?: string;
    myRole: string;
    myRoleBn?: string;
    technologies: string[];
    challenges: string[];
    challengesBn?: string[];
    processSteps: { title: string; desc: string; titleBn?: string; descBn?: string }[];
    finalResult: string;
    finalResultBn?: string;
    gallery: string[];
  };
}

export type SkillLevel = 'Beginner' | 'Intermediate' | 'Advanced' | 'Expert';

export interface SkillItem {
  name: string;
  category: 'Frontend' | 'Backend' | 'UI/UX Design' | 'Tools' | 'Other Skills';
  level: SkillLevel;
  years: number;
  projectsCount: number;
  icon?: string;
  featured?: boolean;
}

export interface RoadmapItem {
  technology: string;
  category: string;
  targetQuarter: string;
  progress: number;
  description: string;
}

export interface ExperienceItem {
  id: string;
  role: string;
  roleBn?: string;
  company: string;
  companyBn?: string;
  period: string;
  location: string;
  type: 'Full-time' | 'Contract' | 'Freelance' | 'Remote';
  responsibilities: string[];
  responsibilitiesBn?: string[];
  keyAchievements: string[];
  keyAchievementsBn?: string[];
  skills: string[];
}

export interface EducationItem {
  id: string;
  degree: string;
  degreeBn?: string;
  institution: string;
  institutionBn?: string;
  period: string;
  major: string;
  achievements: string[];
  certificates: { title: string; issuer: string; date: string; verifyUrl?: string }[];
  activities?: string[];
}

export interface ServiceItem {
  id: string;
  title: string;
  titleBn?: string;
  shortDesc: string;
  shortDescBn?: string;
  icon: string;
  process: string[];
  processBn?: string[];
  deliverables: string[];
  deliverablesBn?: string[];
  popular?: boolean;
}

export interface AchievementItem {
  id: string;
  title: string;
  titleBn?: string;
  category: 'Certificate' | 'Award' | 'Milestone' | 'Competition' | 'Course';
  issuer: string;
  date: string;
  description: string;
  badge?: string;
}

export interface NowPageData {
  lastUpdated: string;
  currentFocus: string[];
  currentFocusBn?: string[];
  currentlyLearning: string[];
  currentlyReading: { title: string; author: string; progress: number };
  activeProjects: { name: string; description: string; status: 'In Progress' | 'Refining' | 'Researching' }[];
  thirtyDayGoals: string[];
  thirtyDayGoalsBn?: string[];
  experiments: string[];
}

export interface GardenNote {
  id: string;
  title: string;
  titleBn?: string;
  category: 'Notes' | 'Tutorials' | 'Ideas' | 'Things I\'ve Learned' | 'Resources' | 'Thoughts' | 'Experiments';
  tags: string[];
  updatedAt: string;
  readTime: string;
  summary: string;
  summaryBn?: string;
  content: string;
  growthStage: 'Sprout' | 'Budding' | 'Evergreen';
}

export interface BlogPost {
  id: string;
  title: string;
  titleBn?: string;
  coverImage: string;
  category: 'Web Development' | 'Design' | 'Technology' | 'Productivity' | 'Personal Growth' | 'Learning Journey';
  date: string;
  readTime: string;
  summary: string;
  summaryBn?: string;
  content: string;
  tags: string[];
  toc: { id: string; text: string }[];
  likes: number;
}

export interface TestimonialItem {
  id: string;
  name: string;
  position: string;
  organization: string;
  image: string;
  content: string;
  contentBn?: string;
  rating: number;
}

export interface GuestbookEntry {
  id: string;
  name: string;
  country?: string;
  location?: string;
  flag?: string;
  message: string;
  emoji?: string;
  avatar?: string;
  createdAt: string;
  approved: boolean;
  likes: number;
}

export type AdviceCategory =
  | 'Portfolio Improvement'
  | 'Career Advice'
  | 'Technology & Code'
  | 'Life & Motivation'
  | 'General Suggestion'
  | 'Personal Development'
  | 'Professional Career'
  | 'Website Improvement'
  | 'Portfolio Feedback'
  | 'Skill Development'
  | 'Business Idea'
  | 'General Advice'
  | 'Other';

export interface VisitorAdvice {
  id: string;
  fullName: string;
  email: string;
  subject: string;
  category: AdviceCategory;
  message: string;
  isPublicApprovedByVisitor: boolean; // Visitor's permission checkbox
  isApprovedByAdmin: boolean;        // Admin display approval for public wall
  isFeatured: boolean;               // Featured advice by Admin
  isRead: boolean;
  isImportant: boolean;
  createdAt: string;
  replyNote?: string;
}

export interface UserAuth {
  isLoggedIn: boolean;
  isAdmin: boolean;
  user: {
    name: string;
    email: string;
    avatar?: string;
    role: 'Admin' | 'Visitor';
  } | null;
}

export interface PersonalDashboardState {
  currentFocus: string;
  status: 'Available' | 'Busy' | 'Learning' | 'Building' | 'Taking a Break';
  currentlyListening: { title: string; artist: string; streamingLink?: string };
  readingList: { title: string; author: string; status: 'Reading' | 'Completed' | 'Queued' }[];
  personalGoals: { goal: string; category: string; completed: boolean }[];
  projectPipeline: { title: string; category: string; status: 'Planning' | 'In Progress' | 'Completed' | 'Paused'; progress: number }[];
  dailyQuote: { text: string; author: string };
}
