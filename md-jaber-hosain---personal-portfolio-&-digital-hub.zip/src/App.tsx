/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { AppProvider } from './context/AppContext';
import { Navbar } from './components/Navbar';
import { Hero } from './components/Hero';
import { AboutSection } from './components/AboutSection';
import { JourneyTimeline } from './components/JourneyTimeline';
import { BeyondWorkSection } from './components/BeyondWorkSection';
import { PortfolioSection } from './components/PortfolioSection';
import { SkillsSection } from './components/SkillsSection';
import { ExperienceEducationSection } from './components/ExperienceEducationSection';
import { ServicesSection } from './components/ServicesSection';
import { AchievementsSection } from './components/AchievementsSection';
import { NowSection } from './components/NowSection';
import { DigitalGardenSection } from './components/DigitalGardenSection';
import { BlogSection } from './components/BlogSection';
import { TestimonialsSection } from './components/TestimonialsSection';
import { VisitorAdviceSection } from './components/VisitorAdviceSection';
import { GuestbookSection } from './components/GuestbookSection';
import { ContactSection } from './components/ContactSection';
import { Footer } from './components/Footer';

// Interactive Global Modals
import { CaseStudyModal } from './components/CaseStudyModal';
import { BusinessCardModal } from './components/BusinessCardModal';
import { PersonalDashboard } from './components/PersonalDashboard';
import { CommandPalette } from './components/CommandPalette';
import { AuthModal } from './components/AuthModal';

const PortfolioApp: React.FC = () => {
  return (
    <div className="min-h-screen bg-white dark:bg-neutral-950 text-neutral-900 dark:text-neutral-100 font-sans selection:bg-emerald-500 selection:text-neutral-950 transition-colors duration-300">
      {/* Navigation Header */}
      <Navbar />

      {/* Main Content Sections */}
      <main id="main-content">
        <Hero />
        <AboutSection />
        <PortfolioSection />
        <SkillsSection />
        <JourneyTimeline />
        <ExperienceEducationSection />
        <ServicesSection />
        <AchievementsSection />
        <NowSection />
        <DigitalGardenSection />
        <BeyondWorkSection />
        <BlogSection />
        <TestimonialsSection />
        <VisitorAdviceSection />
        <GuestbookSection />
        <ContactSection />
      </main>

      {/* Global Footer */}
      <Footer />

      {/* Modals & Dialogs */}
      <CaseStudyModal />
      <BusinessCardModal />
      <PersonalDashboard />
      <CommandPalette />
      <AuthModal />
    </div>
  );
};

export default function App() {
  return (
    <AppProvider>
      <PortfolioApp />
    </AppProvider>
  );
}
