import React, { createContext, useContext, useState, useEffect } from 'react';
import {
  Language,
  Theme,
  Project,
  GardenNote,
  BlogPost,
  VisitorAdvice,
  GuestbookEntry,
  UserAuth,
  PersonalDashboardState,
  SkillItem
} from '../types';
import {
  PROFILE_INFO,
  INITIAL_PROJECTS,
  INITIAL_SKILLS,
  INITIAL_GARDEN_NOTES,
  INITIAL_BLOG_POSTS,
  INITIAL_GUESTBOOK,
  INITIAL_VISITOR_ADVICE,
  INITIAL_DASHBOARD_STATE
} from '../data/initialData';

interface AppContextType {
  language: Language;
  setLanguage: (lang: Language) => void;
  theme: Theme;
  setTheme: (theme: Theme) => void;
  resolvedTheme: 'dark' | 'light';
  
  // Auth & Admin
  auth: UserAuth;
  login: (email: string, role?: 'Admin' | 'Visitor', name?: string) => void;
  signup: (name: string, email: string) => void;
  logout: () => void;
  customAvatar: string;
  updateCustomAvatar: (avatarUrl: string) => void;
  
  // Modals & Active Items
  activeProjectModal: Project | null;
  openProjectModal: (project: Project) => void;
  closeProjectModal: () => void;
  
  activeBlogModal: BlogPost | null;
  openBlogModal: (post: BlogPost) => void;
  closeBlogModal: () => void;
  
  activeNoteModal: GardenNote | null;
  openNoteModal: (note: GardenNote) => void;
  closeNoteModal: () => void;

  isCommandPaletteOpen: boolean;
  setCommandPaletteOpen: (open: boolean) => void;
  
  isAuthModalOpen: boolean;
  setAuthModalOpen: (open: boolean) => void;
  
  isAdminDrawerOpen: boolean;
  setAdminDrawerOpen: (open: boolean) => void;

  isDigitalCardOpen: boolean;
  setDigitalCardOpen: (open: boolean) => void;

  // Audio Ambient Vibe Player
  isPlayingAmbient: boolean;
  toggleAmbientAudio: () => void;

  // Data & State Handlers
  projects: Project[];
  skills: SkillItem[];
  blogPosts: BlogPost[];
  likeBlogPost: (id: string) => void;
  
  guestbook: GuestbookEntry[];
  guestbookEntries: GuestbookEntry[];
  addGuestbookEntry: (entry: Omit<GuestbookEntry, 'id' | 'createdAt' | 'approved' | 'likes'>) => void;
  likeGuestbookEntry: (id: string) => void;
  deleteGuestbookEntry: (id: string) => void;
  
  visitorAdvices: VisitorAdvice[];
  addVisitorAdvice: (advice: Omit<VisitorAdvice, 'id' | 'createdAt' | 'isApprovedByAdmin' | 'isFeatured' | 'isRead' | 'isImportant'>) => void;
  toggleAdviceFeature: (id: string) => void;
  toggleAdvicePublicApproval: (id: string) => void;
  toggleAdviceImportant: (id: string) => void;
  toggleAdviceRead: (id: string) => void;
  deleteAdvice: (id: string) => void;
  
  dashboardState: PersonalDashboardState;
  updateStatus: (status: PersonalDashboardState['status']) => void;
  togglePersonalGoal: (index: number) => void;
  
  // Helper Translation Method
  t: (en: string, bn?: string) => string;
}

const AppContext = createContext<AppContextType | undefined>(undefined);

// Web Audio Ambient Tone Synthesizer
class AmbientSoundGenerator {
  private ctx: AudioContext | null = null;
  private isPlaying = false;
  private oscillators: OscillatorNode[] = [];
  private gainNode: GainNode | null = null;

  start() {
    try {
      const AudioCtx = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
      if (!this.ctx) {
        this.ctx = new AudioCtx();
      }
      if (this.ctx.state === 'suspended') {
        this.ctx.resume();
      }
      
      this.gainNode = this.ctx.createGain();
      this.gainNode.gain.setValueAtTime(0.04, this.ctx.currentTime);
      this.gainNode.connect(this.ctx.destination);

      // Relaxing ambient binaural chord (F# Maj7 chord: F#, A#, C#, E# / F)
      const freqs = [185.0, 233.08, 277.18, 349.23];
      this.oscillators = freqs.map((freq) => {
        const osc = this.ctx!.createOscillator();
        osc.type = 'sine';
        osc.frequency.setValueAtTime(freq, this.ctx!.currentTime);
        osc.connect(this.gainNode!);
        osc.start();
        return osc;
      });

      this.isPlaying = true;
    } catch {
      this.isPlaying = false;
    }
  }

  stop() {
    try {
      this.oscillators.forEach(osc => {
        try { osc.stop(); osc.disconnect(); } catch {}
      });
      this.oscillators = [];
      if (this.gainNode) {
        this.gainNode.disconnect();
        this.gainNode = null;
      }
      this.isPlaying = false;
    } catch {}
  }

  toggle(): boolean {
    if (this.isPlaying) {
      this.stop();
      return false;
    } else {
      this.start();
      return true;
    }
  }
}

const ambientSynth = new AmbientSoundGenerator();

export const AppProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  // Language state
  const [language, setLanguageState] = useState<Language>(() => {
    const saved = localStorage.getItem('mdjaber_lang') as Language;
    return saved === 'bn' ? 'bn' : 'en';
  });

  const setLanguage = (lang: Language) => {
    setLanguageState(lang);
    localStorage.setItem('mdjaber_lang', lang);
  };

  // Theme state
  const [theme, setThemeState] = useState<Theme>(() => {
    const saved = localStorage.getItem('mdjaber_theme') as Theme;
    return saved || 'dark';
  });

  const [resolvedTheme, setResolvedTheme] = useState<'dark' | 'light'>('dark');

  useEffect(() => {
    localStorage.setItem('mdjaber_theme', theme);
    if (theme === 'system') {
      const isDark = window.matchMedia('(prefers-color-scheme: dark)').matches;
      setResolvedTheme(isDark ? 'dark' : 'light');
    } else {
      setResolvedTheme(theme);
    }
  }, [theme]);

  useEffect(() => {
    const root = document.documentElement;
    if (resolvedTheme === 'dark') {
      root.classList.add('dark');
      root.classList.remove('light');
    } else {
      root.classList.add('light');
      root.classList.remove('dark');
    }
  }, [resolvedTheme]);

  // User Auth State
  const [auth, setAuth] = useState<UserAuth>(() => {
    const saved = localStorage.getItem('mdjaber_auth');
    if (saved) {
      try {
        return JSON.parse(saved);
      } catch {}
    }
    return { isLoggedIn: false, isAdmin: false, user: null };
  });

  const login = (email: string, role: 'Admin' | 'Visitor' = 'Visitor', name?: string) => {
    const isAdmin = role === 'Admin' || email.toLowerCase() === PROFILE_INFO.email.toLowerCase() || email.toLowerCase().includes('admin');
    const newAuth: UserAuth = {
      isLoggedIn: true,
      isAdmin,
      user: {
        name: name || (isAdmin ? PROFILE_INFO.name : email.split('@')[0]),
        email,
        role: isAdmin ? 'Admin' : 'Visitor',
        avatar: isAdmin ? PROFILE_INFO.avatar : undefined
      }
    };
    setAuth(newAuth);
    localStorage.setItem('mdjaber_auth', JSON.stringify(newAuth));
  };

  const signup = (name: string, email: string) => {
    login(email, 'Visitor', name);
  };

  const logout = () => {
    const cleared: UserAuth = { isLoggedIn: false, isAdmin: false, user: null };
    setAuth(cleared);
    localStorage.removeItem('mdjaber_auth');
  };

  // Custom Profile Avatar
  const [customAvatar, setCustomAvatar] = useState<string>(() => {
    return localStorage.getItem('mdjaber_avatar') || PROFILE_INFO.avatar;
  });

  const updateCustomAvatar = (avatarUrl: string) => {
    setCustomAvatar(avatarUrl);
    localStorage.setItem('mdjaber_avatar', avatarUrl);
  };

  // Modals & Navigation
  const [activeProjectModal, setActiveProjectModal] = useState<Project | null>(null);
  const [activeBlogModal, setActiveBlogModal] = useState<BlogPost | null>(null);
  const [activeNoteModal, setActiveNoteModal] = useState<GardenNote | null>(null);
  const [isCommandPaletteOpen, setCommandPaletteOpen] = useState(false);
  const [isAuthModalOpen, setAuthModalOpen] = useState(false);
  const [isAdminDrawerOpen, setAdminDrawerOpen] = useState(false);
  const [isDigitalCardOpen, setDigitalCardOpen] = useState(false);
  const [isPlayingAmbient, setIsPlayingAmbient] = useState(false);

  const openProjectModal = (p: Project) => setActiveProjectModal(p);
  const closeProjectModal = () => setActiveProjectModal(null);

  const openBlogModal = (b: BlogPost) => setActiveBlogModal(b);
  const closeBlogModal = () => setActiveBlogModal(null);

  const openNoteModal = (n: GardenNote) => setActiveNoteModal(n);
  const closeNoteModal = () => setActiveNoteModal(null);

  const toggleAmbientAudio = () => {
    const active = ambientSynth.toggle();
    setIsPlayingAmbient(active);
  };

  // Keyboard shortcut for Command Palette (Ctrl+K or Cmd+K)
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === 'k') {
        e.preventDefault();
        setCommandPaletteOpen(prev => !prev);
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, []);

  // Data Storage
  const [projects] = useState<Project[]>(INITIAL_PROJECTS);
  const [skills] = useState<SkillItem[]>(INITIAL_SKILLS);

  const [blogPosts, setBlogPosts] = useState<BlogPost[]>(() => {
    const saved = localStorage.getItem('mdjaber_blog');
    return saved ? JSON.parse(saved) : INITIAL_BLOG_POSTS;
  });

  const likeBlogPost = (id: string) => {
    setBlogPosts(prev => {
      const updated = prev.map(post => post.id === id ? { ...post, likes: post.likes + 1 } : post);
      localStorage.setItem('mdjaber_blog', JSON.stringify(updated));
      return updated;
    });
  };

  // Guestbook
  const [guestbook, setGuestbook] = useState<GuestbookEntry[]>(() => {
    const saved = localStorage.getItem('mdjaber_guestbook');
    return saved ? JSON.parse(saved) : INITIAL_GUESTBOOK;
  });

  const addGuestbookEntry = (entry: Omit<GuestbookEntry, 'id' | 'createdAt' | 'approved' | 'likes'>) => {
    const newEntry: GuestbookEntry = {
      ...entry,
      id: 'gb-' + Date.now(),
      createdAt: new Date().toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' }),
      approved: true,
      likes: 0
    };
    const updated = [newEntry, ...guestbook];
    setGuestbook(updated);
    localStorage.setItem('mdjaber_guestbook', JSON.stringify(updated));
  };

  const likeGuestbookEntry = (id: string) => {
    setGuestbook(prev => {
      const updated = prev.map(g => g.id === id ? { ...g, likes: g.likes + 1 } : g);
      localStorage.setItem('mdjaber_guestbook', JSON.stringify(updated));
      return updated;
    });
  };

  const deleteGuestbookEntry = (id: string) => {
    setGuestbook(prev => {
      const updated = prev.filter(g => g.id !== id);
      localStorage.setItem('mdjaber_guestbook', JSON.stringify(updated));
      return updated;
    });
  };

  // Visitor Advice Section 31
  const [visitorAdvices, setVisitorAdvices] = useState<VisitorAdvice[]>(() => {
    const saved = localStorage.getItem('mdjaber_advices');
    return saved ? JSON.parse(saved) : INITIAL_VISITOR_ADVICE;
  });

  const addVisitorAdvice = (advice: Omit<VisitorAdvice, 'id' | 'createdAt' | 'isApprovedByAdmin' | 'isFeatured' | 'isRead' | 'isImportant'>) => {
    const newAdvice: VisitorAdvice = {
      ...advice,
      id: 'adv-' + Date.now(),
      createdAt: new Date().toLocaleDateString('en-US', { month: 'long', day: 'numeric', year: 'numeric' }),
      isApprovedByAdmin: advice.isPublicApprovedByVisitor, // auto-approve if visitor agreed or keep ready
      isFeatured: false,
      isRead: false,
      isImportant: false
    };
    const updated = [newAdvice, ...visitorAdvices];
    setVisitorAdvices(updated);
    localStorage.setItem('mdjaber_advices', JSON.stringify(updated));
  };

  const toggleAdviceFeature = (id: string) => {
    setVisitorAdvices(prev => {
      const updated = prev.map(a => a.id === id ? { ...a, isFeatured: !a.isFeatured } : a);
      localStorage.setItem('mdjaber_advices', JSON.stringify(updated));
      return updated;
    });
  };

  const toggleAdvicePublicApproval = (id: string) => {
    setVisitorAdvices(prev => {
      const updated = prev.map(a => a.id === id ? { ...a, isApprovedByAdmin: !a.isApprovedByAdmin } : a);
      localStorage.setItem('mdjaber_advices', JSON.stringify(updated));
      return updated;
    });
  };

  const toggleAdviceImportant = (id: string) => {
    setVisitorAdvices(prev => {
      const updated = prev.map(a => a.id === id ? { ...a, isImportant: !a.isImportant } : a);
      localStorage.setItem('mdjaber_advices', JSON.stringify(updated));
      return updated;
    });
  };

  const toggleAdviceRead = (id: string) => {
    setVisitorAdvices(prev => {
      const updated = prev.map(a => a.id === id ? { ...a, isRead: !a.isRead } : a);
      localStorage.setItem('mdjaber_advices', JSON.stringify(updated));
      return updated;
    });
  };

  const deleteAdvice = (id: string) => {
    setVisitorAdvices(prev => {
      const updated = prev.filter(a => a.id !== id);
      localStorage.setItem('mdjaber_advices', JSON.stringify(updated));
      return updated;
    });
  };

  // Personal Dashboard State
  const [dashboardState, setDashboardState] = useState<PersonalDashboardState>(() => {
    const saved = localStorage.getItem('mdjaber_dashboard');
    return saved ? JSON.parse(saved) : INITIAL_DASHBOARD_STATE;
  });

  const updateStatus = (status: PersonalDashboardState['status']) => {
    setDashboardState(prev => {
      const updated = { ...prev, status };
      localStorage.setItem('mdjaber_dashboard', JSON.stringify(updated));
      return updated;
    });
  };

  const togglePersonalGoal = (index: number) => {
    setDashboardState(prev => {
      const updatedGoals = [...prev.personalGoals];
      updatedGoals[index] = { ...updatedGoals[index], completed: !updatedGoals[index].completed };
      const updated = { ...prev, personalGoals: updatedGoals };
      localStorage.setItem('mdjaber_dashboard', JSON.stringify(updated));
      return updated;
    });
  };

  // Helper translation
  const t = (en: string, bn?: string) => {
    if (language === 'bn' && bn) {
      return bn;
    }
    return en;
  };

  return (
    <AppContext.Provider
      value={{
        language,
        setLanguage,
        theme,
        setTheme: setThemeState,
        resolvedTheme,
        auth,
        login,
        signup,
        logout,
        customAvatar,
        updateCustomAvatar,
        activeProjectModal,
        openProjectModal,
        closeProjectModal,
        activeBlogModal,
        openBlogModal,
        closeBlogModal,
        activeNoteModal,
        openNoteModal,
        closeNoteModal,
        isCommandPaletteOpen,
        setCommandPaletteOpen,
        isAuthModalOpen,
        setAuthModalOpen,
        isAdminDrawerOpen,
        setAdminDrawerOpen,
        isDigitalCardOpen,
        setDigitalCardOpen,
        isPlayingAmbient,
        toggleAmbientAudio,
        projects,
        skills,
        blogPosts,
        likeBlogPost,
        guestbook,
        guestbookEntries: guestbook,
        addGuestbookEntry,
        likeGuestbookEntry,
        deleteGuestbookEntry,
        visitorAdvices,
        addVisitorAdvice,
        toggleAdviceFeature,
        toggleAdvicePublicApproval,
        toggleAdviceImportant,
        toggleAdviceRead,
        deleteAdvice,
        dashboardState,
        updateStatus,
        togglePersonalGoal,
        t
      }}
    >
      {children}
    </AppContext.Provider>
  );
};

export const useApp = () => {
  const context = useContext(AppContext);
  if (!context) {
    throw new Error('useApp must be used within an AppProvider');
  }
  return context;
};
